﻿namespace ProposalReportingSystem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            DevComponents.DotNetBar.Rendering.SuperTabColorTable superTabColorTable1 = new DevComponents.DotNetBar.Rendering.SuperTabColorTable();
            DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable superTabLinearGradientColorTable1 = new DevComponents.DotNetBar.Rendering.SuperTabLinearGradientColorTable();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            FarsiCalendarComponent.FarsiDate farsiDate1 = new FarsiCalendarComponent.FarsiDate();
            DevComponents.DotNetBar.Controls.ClockStyleData clockStyleData1 = new DevComponents.DotNetBar.Controls.ClockStyleData();
            DevComponents.DotNetBar.Controls.ColorData colorData1 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ColorData colorData2 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ColorData colorData3 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ClockHandStyleData clockHandStyleData1 = new DevComponents.DotNetBar.Controls.ClockHandStyleData();
            DevComponents.DotNetBar.Controls.ColorData colorData4 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ColorData colorData5 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ClockHandStyleData clockHandStyleData2 = new DevComponents.DotNetBar.Controls.ClockHandStyleData();
            DevComponents.DotNetBar.Controls.ColorData colorData6 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ClockHandStyleData clockHandStyleData3 = new DevComponents.DotNetBar.Controls.ClockHandStyleData();
            DevComponents.DotNetBar.Controls.ColorData colorData7 = new DevComponents.DotNetBar.Controls.ColorData();
            DevComponents.DotNetBar.Controls.ColorData colorData8 = new DevComponents.DotNetBar.Controls.ColorData();
            this.home_tab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabItem9 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel9 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.mainPage = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel11 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.logPanel = new System.Windows.Forms.Panel();
            this.logNavigationPanel = new System.Windows.Forms.Panel();
            this.logNavigationCurrentPageTxtbx = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.logNavigationNextPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem10 = new DevComponents.DotNetBar.SuperTabItem();
            this.logNavigationLastPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem16 = new DevComponents.DotNetBar.SuperTabItem();
            this.logNavigationPreviousPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem22 = new DevComponents.DotNetBar.SuperTabItem();
            this.logNavigationFirstPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem28 = new DevComponents.DotNetBar.SuperTabItem();
            this.logNavigationReturnBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem34 = new DevComponents.DotNetBar.SuperTabItem();
            this.logDgv = new System.Windows.Forms.DataGridView();
            this.sysLogTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel10 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.aboutUsPanel = new System.Windows.Forms.Panel();
            this.aboutUsGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.aboutUsAlirezaLbl = new System.Windows.Forms.Label();
            this.aboutUsNimaLbl = new System.Windows.Forms.Label();
            this.aboutUsHoseinLbl = new System.Windows.Forms.Label();
            this.aboutUsPeymanLbl = new System.Windows.Forms.Label();
            this.AboutUsArshinLbl = new System.Windows.Forms.Label();
            this.aboutUsTitleLbl = new System.Windows.Forms.Label();
            this.aboutUsTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel7 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.personalSettingPanel = new System.Windows.Forms.Panel();
            this.personalSettingThemeGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.appSettingBackgroundChangeGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.appSettingBackgroundColorLbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.appSettingBackgroundChangeLbl = new System.Windows.Forms.Label();
            this.personalSettingPasswordGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.personalSettingOldPasswordChb = new System.Windows.Forms.CheckBox();
            this.personalSettingNewPasswordChb = new System.Windows.Forms.CheckBox();
            this.personalSettingRepeatPasswordChb = new System.Windows.Forms.CheckBox();
            this.personalSettingRepeatPasswordTxtbx = new System.Windows.Forms.TextBox();
            this.personalSettingNewPasswordTxtbx = new System.Windows.Forms.TextBox();
            this.personalSettingOldPasswordTxtbx = new System.Windows.Forms.TextBox();
            this.confirmNewPasswordLbl = new System.Windows.Forms.Label();
            this.newPasswordLbl = new System.Windows.Forms.Label();
            this.currentPasswordLbl = new System.Windows.Forms.Label();
            this.personalSettingRegisterBtn = new DevComponents.DotNetBar.ButtonX();
            this.personalSettingClearBtn = new DevComponents.DotNetBar.ButtonX();
            this.personalSettingsTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel6 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.appSettingPanel = new System.Windows.Forms.Panel();
            this.appSettingShowGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.appSettingNavigationPanel = new System.Windows.Forms.Panel();
            this.appSettingNavigationCurrentPageTxtbx = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.appSettingNavigationNextPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem32 = new DevComponents.DotNetBar.SuperTabItem();
            this.appSettingNavigationLastPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem33 = new DevComponents.DotNetBar.SuperTabItem();
            this.appSettingNavigationPreviousPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem35 = new DevComponents.DotNetBar.SuperTabItem();
            this.appSettingNavigationFirstPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem36 = new DevComponents.DotNetBar.SuperTabItem();
            this.appSettingNavigationReturnBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem37 = new DevComponents.DotNetBar.SuperTabItem();
            this.appSettingShowDv = new System.Windows.Forms.DataGridView();
            this.appSettingGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.appSettingEdegreeLbl = new System.Windows.Forms.Label();
            this.appSettingEdegreeTxtbx = new System.Windows.Forms.TextBox();
            this.appSettingEdegreeRbtn = new System.Windows.Forms.RadioButton();
            this.appSettingBackBtn = new DevComponents.DotNetBar.ButtonX();
            this.appSettingEgroupLbl = new System.Windows.Forms.Label();
            this.appSettingFacultyLbl = new System.Windows.Forms.Label();
            this.appSettingFacultyTxtbx = new System.Windows.Forms.TextBox();
            this.appSettingEgroupTxtbx = new System.Windows.Forms.TextBox();
            this.appSettingFacultyRbtn = new System.Windows.Forms.RadioButton();
            this.appSettingEgroupRbtn = new System.Windows.Forms.RadioButton();
            this.appSettingStatusLbl = new System.Windows.Forms.Label();
            this.aapSettingCoLbl = new System.Windows.Forms.Label();
            this.appSettingProTypeLbl = new System.Windows.Forms.Label();
            this.appSettingRegTypeLbl = new System.Windows.Forms.Label();
            this.appSettingPropertyLbl = new System.Windows.Forms.Label();
            this.appSettingProcedureTypeLbl = new System.Windows.Forms.Label();
            this.appSettingStatusTxtbx = new System.Windows.Forms.TextBox();
            this.appSettingPropertyTxtbx = new System.Windows.Forms.TextBox();
            this.appSettingStatusRbtn = new System.Windows.Forms.RadioButton();
            this.appSettingProTypeTxtbx = new System.Windows.Forms.TextBox();
            this.appSettingPropertyRbtn = new System.Windows.Forms.RadioButton();
            this.appSettingCoTxtbx = new System.Windows.Forms.TextBox();
            this.appSettingProTypeRbtn = new System.Windows.Forms.RadioButton();
            this.appSettingRegTypeTxtbx = new System.Windows.Forms.TextBox();
            this.appSettingCoRbtn = new System.Windows.Forms.RadioButton();
            this.appSettingProcedureTypeRbtn = new System.Windows.Forms.RadioButton();
            this.appSettingRegTypeRbtn = new System.Windows.Forms.RadioButton();
            this.appSettingProcedureTypeTxtbx = new System.Windows.Forms.TextBox();
            this.appSettingDeleteBtn = new DevComponents.DotNetBar.ButtonX();
            this.appSettingEditBtn = new DevComponents.DotNetBar.ButtonX();
            this.appSettingAddBtn = new DevComponents.DotNetBar.ButtonX();
            this.appSettingsTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel4 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.manageUserPanel = new System.Windows.Forms.Panel();
            this.manageUserManageGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.menageUserAccessLevelGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.manageUserManageTypeCb = new System.Windows.Forms.CheckBox();
            this.manageUserManageTeacherCb = new System.Windows.Forms.CheckBox();
            this.manageUserDeleteUserCb = new System.Windows.Forms.CheckBox();
            this.manageUserEditUserCb = new System.Windows.Forms.CheckBox();
            this.manageUserAddUserCb = new System.Windows.Forms.CheckBox();
            this.manageUserDeleteProCb = new System.Windows.Forms.CheckBox();
            this.manageUserEditProCb = new System.Windows.Forms.CheckBox();
            this.manageUserAddProCb = new System.Windows.Forms.CheckBox();
            this.manageUserPersonalInfoGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.manageUserShowPasswordChb = new System.Windows.Forms.CheckBox();
            this.manageUserTellLb = new System.Windows.Forms.Label();
            this.manageUserEmailLb = new System.Windows.Forms.Label();
            this.manageUserPasswordLb = new System.Windows.Forms.Label();
            this.manageUserNcodLb = new System.Windows.Forms.Label();
            this.manageUserLnameLb = new System.Windows.Forms.Label();
            this.manageUserFnameLb = new System.Windows.Forms.Label();
            this.manageUserTelTxtbx = new System.Windows.Forms.TextBox();
            this.manageUserEmailTxtbx = new System.Windows.Forms.TextBox();
            this.manageUserPasswordTxtbx = new System.Windows.Forms.TextBox();
            this.manageUserNcodeTxtbx = new System.Windows.Forms.TextBox();
            this.manageUserLnameTxtbx = new System.Windows.Forms.TextBox();
            this.manageUserFnameTxtbx = new System.Windows.Forms.TextBox();
            this.manageUserShowAllBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageUserClearBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageUserDeleteBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageUserEditBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageUserAddBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageUserShowGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.manageUserNavigationPanel = new System.Windows.Forms.Panel();
            this.manageUserNavigationCurrentPageTxtbx = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.manageUserNavigationNextPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem26 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageUserNavigationLastPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem27 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageUserNavigationPreviousPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem29 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageUserNavigationFirstPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem30 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageUserNavigationReturnBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem31 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageUserShowDgv = new System.Windows.Forms.DataGridView();
            this.manageUserTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel12 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.manageTeacherPanel = new System.Windows.Forms.Panel();
            this.teacherManageShowGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.manageTeacherNavigationPanel = new System.Windows.Forms.Panel();
            this.manageTeacherNavigationCurrentPageTxtbx = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.manageTeacherNavigationNextPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem20 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageTeacherNavigationLastPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem21 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageTeacherNavigationPreviousPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem23 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageTeacherNavigationFirstPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem24 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageTeacherNavigationReturnBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem25 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageTeacherShowDgv = new System.Windows.Forms.DataGridView();
            this.manageTeacherInfoGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.manageTeacherSearchBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageTeacherShowAllBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageTeacherExecutorTel2Txtbx = new System.Windows.Forms.TextBox();
            this.manageTeacherExecutorMobileTxtbx = new System.Windows.Forms.TextBox();
            this.manageTeacherExecutorEmailTxtbx = new System.Windows.Forms.TextBox();
            this.manageTeacherExecutorTelTxtbx = new System.Windows.Forms.TextBox();
            this.manageTeacherExecutorTel2Lbl = new System.Windows.Forms.Label();
            this.manageTeacherExecutorEgroupCb = new System.Windows.Forms.ComboBox();
            this.manageTeacherExecutorFacultyCb = new System.Windows.Forms.ComboBox();
            this.manageTeacherLnameTxtbx = new System.Windows.Forms.TextBox();
            this.manageTeacherExecutorNcodeTxtbx = new System.Windows.Forms.TextBox();
            this.manageTeacherFnameTxtbx = new System.Windows.Forms.TextBox();
            this.manageTeacherExecutorEDegCb = new System.Windows.Forms.ComboBox();
            this.manageTeacherFnameLbl = new System.Windows.Forms.Label();
            this.manageTeacherExecutorNcodeLbl = new System.Windows.Forms.Label();
            this.manageTeacherLnameLbl = new System.Windows.Forms.Label();
            this.manageTeacherExecutorMobileLbl = new System.Windows.Forms.Label();
            this.manageTeacherExecutorEmailLbl = new System.Windows.Forms.Label();
            this.manageTeacherExecutorEDegLbl = new System.Windows.Forms.Label();
            this.manageTeacherExecutorEGroupLbl = new System.Windows.Forms.Label();
            this.manageTeacherExecutorFacultyLbl = new System.Windows.Forms.Label();
            this.manageTeacherExecutorTelLbl = new System.Windows.Forms.Label();
            this.manageTeacherClearBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageTeacherDeleteBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageTeacherEditBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageTeacherAddBtn = new DevComponents.DotNetBar.ButtonX();
            this.manageTeacherTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel5 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.editProposalPanel = new System.Windows.Forms.Panel();
            this.editProposalEditGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.editProposalShowAllBtn = new DevComponents.DotNetBar.ButtonX();
            this.editProposalDurationLbl = new System.Windows.Forms.Label();
            this.editProposalSearchBtn = new DevComponents.DotNetBar.ButtonX();
            this.editProposalDeleteBtn = new DevComponents.DotNetBar.ButtonX();
            this.editProposalExecutorEGroupCb = new System.Windows.Forms.ComboBox();
            this.editProposalExecutorFacultyCb = new System.Windows.Forms.ComboBox();
            this.editProposalStartdateTimeInput = new FarsiCalendarComponent.FarsiDatePicker();
            this.editProposalFileLinkLbl = new System.Windows.Forms.LinkLabel();
            this.editProposalFileLbl = new System.Windows.Forms.Label();
            this.editProposalOrganizationNumberCb = new System.Windows.Forms.ComboBox();
            this.editProposalStatusCb = new System.Windows.Forms.ComboBox();
            this.editProposalOrganizationNameCb = new System.Windows.Forms.ComboBox();
            this.editProposalTypeCb = new System.Windows.Forms.ComboBox();
            this.editProposalRegisterTypeCb = new System.Windows.Forms.ComboBox();
            this.editProposalPropertyTypeCb = new System.Windows.Forms.ComboBox();
            this.editProposalProcedureTypeCb = new System.Windows.Forms.ComboBox();
            this.editProposalExecutorEDegCb = new System.Windows.Forms.ComboBox();
            this.editProposalExecutorMobileTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalExecutorMobileLbl = new System.Windows.Forms.Label();
            this.editProposalExecutorEmailLbl = new System.Windows.Forms.Label();
            this.editProposalExecutorEDegLbl = new System.Windows.Forms.Label();
            this.editProposalExecutorEmailTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalExecutorEGroupLbl = new System.Windows.Forms.Label();
            this.editProposalExecutorFacultyLbl = new System.Windows.Forms.Label();
            this.editProposalExecutorTel2Lbl = new System.Windows.Forms.Label();
            this.editProposalExecutorTel2Txtbx = new System.Windows.Forms.TextBox();
            this.editProposalExecutorTel1Lbl = new System.Windows.Forms.Label();
            this.editProposalExecutorTel1Txtbx = new System.Windows.Forms.TextBox();
            this.editProposalExecutorLNameLbl = new System.Windows.Forms.Label();
            this.editProposalExecutorLNameTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalExecutorFNameLbl = new System.Windows.Forms.Label();
            this.editProposalExecutorFNameTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalValueTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalValueLbl = new System.Windows.Forms.Label();
            this.editProposalOrganizationLbl = new System.Windows.Forms.Label();
            this.editProposalStatusLbl = new System.Windows.Forms.Label();
            this.editProposalTypeLbl = new System.Windows.Forms.Label();
            this.editProposalRegisterTypeLbl = new System.Windows.Forms.Label();
            this.editProposalPropertyTypeLbl = new System.Windows.Forms.Label();
            this.editProposalProcedureTypeLbl = new System.Windows.Forms.Label();
            this.editProposalDurationTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalStartdateLbl = new System.Windows.Forms.Label();
            this.editProposalCoexecutorLbl = new System.Windows.Forms.Label();
            this.editProposalCoexecutorTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalExecutor2Lbl = new System.Windows.Forms.Label();
            this.editProposalExecutorNcodeLbl = new System.Windows.Forms.Label();
            this.editProposalKeywordsLbl = new System.Windows.Forms.Label();
            this.editProposalEnglishTitleLbl = new System.Windows.Forms.Label();
            this.editProposalPersianTitleLbl = new System.Windows.Forms.Label();
            this.editProposalExecutor2Txtbx = new System.Windows.Forms.TextBox();
            this.editProposalExecutorNcodeTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalKeywordsTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalEnglishTitleTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalPersianTitleTxtbx = new System.Windows.Forms.TextBox();
            this.editProposalRegisterBtn = new DevComponents.DotNetBar.ButtonX();
            this.logTab = new DevComponents.DotNetBar.SuperTabItem();
            this.editProposalClearBtn = new DevComponents.DotNetBar.ButtonX();
            this.editProposalShowGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.manageProposalNavigationPanel = new System.Windows.Forms.Panel();
            this.manageProposalNavigationCurrentPageTxtbx = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.manageProposalNavigationNextPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem6 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageProposalNavigationLastPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem5 = new DevComponents.DotNetBar.SuperTabItem();
            this.buttonX4 = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem4 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageProposalNavigationPreviousPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem3 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageProposalNavigationFirstPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem2 = new DevComponents.DotNetBar.SuperTabItem();
            this.manageProposalNavigationReturnBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem1 = new DevComponents.DotNetBar.SuperTabItem();
            this.editProposalShowDgv = new System.Windows.Forms.DataGridView();
            this.manageProposalTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel3 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.searchProposalPanel = new System.Windows.Forms.Panel();
            this.searchProposalShowGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.searchProposalNavigationPanel = new System.Windows.Forms.Panel();
            this.searchProposalNavigationCurrentPageTxtbx = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.searchProposalNavigationNextPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem14 = new DevComponents.DotNetBar.SuperTabItem();
            this.searchProposalNavigationLastPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem15 = new DevComponents.DotNetBar.SuperTabItem();
            this.searchProposalNavigationPreviousPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem17 = new DevComponents.DotNetBar.SuperTabItem();
            this.searchProposalNavigationFirstPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem18 = new DevComponents.DotNetBar.SuperTabItem();
            this.searchProposalNavigationReturnBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem19 = new DevComponents.DotNetBar.SuperTabItem();
            this.searchProposalShowDgv = new System.Windows.Forms.DataGridView();
            this.searchProposalSearchGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.searchProposalShowAllBtn = new DevComponents.DotNetBar.ButtonX();
            this.searchProposalStartDateToTimeInput = new FarsiCalendarComponent.FarsiDatePicker();
            this.searchProposalExecutorEGroupCb = new System.Windows.Forms.ComboBox();
            this.searchProposalExecutorFacultyCb = new System.Windows.Forms.ComboBox();
            this.searchProposalStartDateToChbx = new System.Windows.Forms.CheckBox();
            this.searchProposalStartDateFromChbx = new System.Windows.Forms.CheckBox();
            this.searchProposalStartDateFromTimeInput = new FarsiCalendarComponent.FarsiDatePicker();
            this.searchProposalValueToTxtbx = new System.Windows.Forms.TextBox();
            this.searchProposalValueToLbl = new System.Windows.Forms.Label();
            this.searchProposalStartDateToLbl = new System.Windows.Forms.Label();
            this.searchProposalOrganizationNumberCb = new System.Windows.Forms.ComboBox();
            this.searchProposalStatusCb = new System.Windows.Forms.ComboBox();
            this.searchProposalOrganizationNameCb = new System.Windows.Forms.ComboBox();
            this.searchProposalTypeCb = new System.Windows.Forms.ComboBox();
            this.searchProposalRegisterTypeCb = new System.Windows.Forms.ComboBox();
            this.searchProposalPropertyTypeCb = new System.Windows.Forms.ComboBox();
            this.searchProposalProcedureTypeCb = new System.Windows.Forms.ComboBox();
            this.searchProposalExecutorMobileTxtbx = new System.Windows.Forms.TextBox();
            this.searchProposalExecutorMobileLbl = new System.Windows.Forms.Label();
            this.searchProposalExecutorEGroupLbl = new System.Windows.Forms.Label();
            this.searchProposalExecutorFacultyLbl = new System.Windows.Forms.Label();
            this.searchProposalExecutorLNameLbl = new System.Windows.Forms.Label();
            this.searchProposalExecutorLNameTxtbx = new System.Windows.Forms.TextBox();
            this.searchProposalExecutorFNameLbl = new System.Windows.Forms.Label();
            this.searchProposalExecutorFNameTxtbx = new System.Windows.Forms.TextBox();
            this.searchProposalValueFromTxtbx = new System.Windows.Forms.TextBox();
            this.searchProposalValueFromLbl = new System.Windows.Forms.Label();
            this.searchProposalOrganizationLbl = new System.Windows.Forms.Label();
            this.searchProposalStatusLbl = new System.Windows.Forms.Label();
            this.searchProposalTypeLbl = new System.Windows.Forms.Label();
            this.searchProposalRegisterTypeLbl = new System.Windows.Forms.Label();
            this.searchProposalPropertyTypeLbl = new System.Windows.Forms.Label();
            this.searchProposalProcedureTypeLbl = new System.Windows.Forms.Label();
            this.searchProposalStartDateFromLbl = new System.Windows.Forms.Label();
            this.searchProposalExecutorNCodeLbl = new System.Windows.Forms.Label();
            this.searchProposalEnglishTitleLbl = new System.Windows.Forms.Label();
            this.searchProposalPersianTitleLbl = new System.Windows.Forms.Label();
            this.searchProposalExecutorNCodeTxtbx = new System.Windows.Forms.TextBox();
            this.searchProposalEnglishTitleTxtbx = new System.Windows.Forms.TextBox();
            this.searchProposalPersianTitleTxtbx = new System.Windows.Forms.TextBox();
            this.searchProposalSearchBtn = new DevComponents.DotNetBar.ButtonX();
            this.searchProposalClearBtn = new DevComponents.DotNetBar.ButtonX();
            this.searchProposalExecutorInfoGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.searchProposalProposalInfoGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.searchProposalTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel2 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.addProposalPanel = new System.Windows.Forms.Panel();
            this.addProposalShowGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.addProposalNavigationPanel = new System.Windows.Forms.Panel();
            this.addProposalNavigationCurrentPageTxtbx = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.addProposalNavigationNextPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem7 = new DevComponents.DotNetBar.SuperTabItem();
            this.addProposalNavigationLastPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem8 = new DevComponents.DotNetBar.SuperTabItem();
            this.addProposalNavigationPreviousPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem11 = new DevComponents.DotNetBar.SuperTabItem();
            this.addProposalNavigationFirstPageBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem12 = new DevComponents.DotNetBar.SuperTabItem();
            this.addProposalNavigationReturnBtn = new DevComponents.DotNetBar.ButtonX();
            this.superTabItem13 = new DevComponents.DotNetBar.SuperTabItem();
            this.addProposalShowDgv = new System.Windows.Forms.DataGridView();
            this.addProposalAddGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.addProposalEnglishTitleTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalShowAllBtn = new DevComponents.DotNetBar.ButtonX();
            this.addProposalSearchBtn = new DevComponents.DotNetBar.ButtonX();
            this.addProposalExecutorEGroupCb = new System.Windows.Forms.ComboBox();
            this.addProposalExecutorFacultyCb = new System.Windows.Forms.ComboBox();
            this.addProposalStartdateTimeInput = new FarsiCalendarComponent.FarsiDatePicker();
            this.addProposalFileLinkLbl = new System.Windows.Forms.LinkLabel();
            this.addProposalFileLbl = new System.Windows.Forms.Label();
            this.addProposalOrganizationNumberCb = new System.Windows.Forms.ComboBox();
            this.addProposalStatusCb = new System.Windows.Forms.ComboBox();
            this.addProposalOrganizationNameCb = new System.Windows.Forms.ComboBox();
            this.addProposalProposalTypeCb = new System.Windows.Forms.ComboBox();
            this.addProposalRegisterTypeCb = new System.Windows.Forms.ComboBox();
            this.addProposalPropertyTypeCb = new System.Windows.Forms.ComboBox();
            this.addProposalProcedureTypeCb = new System.Windows.Forms.ComboBox();
            this.addProposalExecutorEDegCb = new System.Windows.Forms.ComboBox();
            this.addProposalExecutorMobileTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalExecutorMobileLbl = new System.Windows.Forms.Label();
            this.addProposalExecutorEmailLbl = new System.Windows.Forms.Label();
            this.addProposalExecutorEDegLbl = new System.Windows.Forms.Label();
            this.addProposalExecutorEmailTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalExecutorEGroupLbl = new System.Windows.Forms.Label();
            this.addProposalExecutorFacultyLbl = new System.Windows.Forms.Label();
            this.addProposalExecutorTel2Lbl = new System.Windows.Forms.Label();
            this.addProposalExecutorTel2Txtbx = new System.Windows.Forms.TextBox();
            this.addProposalExecutorTel1Lbl = new System.Windows.Forms.Label();
            this.addProposalExecutorTel1Txtbx = new System.Windows.Forms.TextBox();
            this.addProposalExecutorLNameLbl = new System.Windows.Forms.Label();
            this.addProposalExecutorLNameTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalExecutorFNameLbl = new System.Windows.Forms.Label();
            this.addProposalExecutorFNameTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalValueTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalValueLbl = new System.Windows.Forms.Label();
            this.addProposalOrganizationLbl = new System.Windows.Forms.Label();
            this.addProposalStatusLbl = new System.Windows.Forms.Label();
            this.addProposalTypeLbl = new System.Windows.Forms.Label();
            this.addProposalRegisterTypeLbl = new System.Windows.Forms.Label();
            this.addProposalPropertyTypeLbl = new System.Windows.Forms.Label();
            this.addProposalProcedureTypeLbl = new System.Windows.Forms.Label();
            this.addProposalDurationTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalDurationLbl = new System.Windows.Forms.Label();
            this.addProposalStartdateLbl = new System.Windows.Forms.Label();
            this.addProposalCoexecutorLbl = new System.Windows.Forms.Label();
            this.addProposalCoexecutorTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalExecutor2Lbl = new System.Windows.Forms.Label();
            this.addProposalExecutorNcodeLbl = new System.Windows.Forms.Label();
            this.addProposalKeywordsLbl = new System.Windows.Forms.Label();
            this.addProposalEnglishTitleLbl = new System.Windows.Forms.Label();
            this.addProposalPersianTitleLbl = new System.Windows.Forms.Label();
            this.addProposalExecutor2Txtbx = new System.Windows.Forms.TextBox();
            this.addProposalExecutorNcodeTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalKeywordsTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalPersianTitleTxtbx = new System.Windows.Forms.TextBox();
            this.addProposalClearBtn = new DevComponents.DotNetBar.ButtonX();
            this.addProposalRegisterBtn = new DevComponents.DotNetBar.ButtonX();
            this.addProposalTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel1 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.homePanel = new System.Windows.Forms.Panel();
            this.homeTimeDateGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.monthCalendar1 = new FarsiCalendarComponent.FarsiCalendarControl();
            this.analogClockControl1 = new DevComponents.DotNetBar.Controls.AnalogClockControl();
            this.homeAapInfoGp = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.homeEBSLbl = new System.Windows.Forms.Label();
            this.homeWelcomeLbl = new System.Windows.Forms.Label();
            this.homeUserNameLbl = new System.Windows.Forms.Label();
            this.homeUserProfileLbl = new System.Windows.Forms.Label();
            this.homeAppNameLbl = new System.Windows.Forms.Label();
            this.homeTab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel13 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.exitTab = new DevComponents.DotNetBar.SuperTabItem();
            this.log = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel8 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.wait_timer = new System.Windows.Forms.Timer(this.components);
            this.waitBw = new System.ComponentModel.BackgroundWorker();
            this.iconMenuPanel = new System.Windows.Forms.Panel();
            this.menuSlideRb = new System.Windows.Forms.RadioButton();
            this.menuDetailRb = new System.Windows.Forms.RadioButton();
            this.menuIconRb = new System.Windows.Forms.RadioButton();
            this.menuExitBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuSysLogBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuAboutUsBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuPersonalSettingBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuAppSettingBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuManageUserBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuManageTeacherBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuManageProposalBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuSearchProposalBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuAddProposalBtn = new DevComponents.DotNetBar.ButtonX();
            this.menuHomeBtn = new DevComponents.DotNetBar.ButtonX();
            this.appSettingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.logBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.teacherBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.addProposalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.editProposalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.searchProposalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.balloonTip1 = new DevComponents.DotNetBar.BalloonTip();
            this.superTabControlPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mainPage)).BeginInit();
            this.mainPage.SuspendLayout();
            this.superTabControlPanel11.SuspendLayout();
            this.logPanel.SuspendLayout();
            this.logNavigationPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logDgv)).BeginInit();
            this.superTabControlPanel10.SuspendLayout();
            this.aboutUsPanel.SuspendLayout();
            this.aboutUsGp.SuspendLayout();
            this.superTabControlPanel7.SuspendLayout();
            this.personalSettingPanel.SuspendLayout();
            this.personalSettingThemeGp.SuspendLayout();
            this.appSettingBackgroundChangeGp.SuspendLayout();
            this.personalSettingPasswordGp.SuspendLayout();
            this.superTabControlPanel6.SuspendLayout();
            this.appSettingPanel.SuspendLayout();
            this.appSettingShowGp.SuspendLayout();
            this.appSettingNavigationPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appSettingShowDv)).BeginInit();
            this.appSettingGp.SuspendLayout();
            this.superTabControlPanel4.SuspendLayout();
            this.manageUserPanel.SuspendLayout();
            this.manageUserManageGp.SuspendLayout();
            this.menageUserAccessLevelGp.SuspendLayout();
            this.manageUserPersonalInfoGp.SuspendLayout();
            this.manageUserShowGp.SuspendLayout();
            this.manageUserNavigationPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.manageUserShowDgv)).BeginInit();
            this.superTabControlPanel12.SuspendLayout();
            this.manageTeacherPanel.SuspendLayout();
            this.teacherManageShowGp.SuspendLayout();
            this.manageTeacherNavigationPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.manageTeacherShowDgv)).BeginInit();
            this.manageTeacherInfoGp.SuspendLayout();
            this.superTabControlPanel5.SuspendLayout();
            this.editProposalPanel.SuspendLayout();
            this.editProposalEditGp.SuspendLayout();
            this.editProposalShowGp.SuspendLayout();
            this.manageProposalNavigationPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.editProposalShowDgv)).BeginInit();
            this.superTabControlPanel3.SuspendLayout();
            this.searchProposalPanel.SuspendLayout();
            this.searchProposalShowGp.SuspendLayout();
            this.searchProposalNavigationPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.searchProposalShowDgv)).BeginInit();
            this.searchProposalSearchGp.SuspendLayout();
            this.superTabControlPanel2.SuspendLayout();
            this.addProposalPanel.SuspendLayout();
            this.addProposalShowGp.SuspendLayout();
            this.addProposalNavigationPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.addProposalShowDgv)).BeginInit();
            this.addProposalAddGp.SuspendLayout();
            this.superTabControlPanel1.SuspendLayout();
            this.homePanel.SuspendLayout();
            this.homeTimeDateGp.SuspendLayout();
            this.homeAapInfoGp.SuspendLayout();
            this.iconMenuPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appSettingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addProposalBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.editProposalBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchProposalBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // home_tab
            // 
            this.home_tab.GlobalItem = false;
            this.home_tab.Icon = ((System.Drawing.Icon)(resources.GetObject("home_tab.Icon")));
            this.home_tab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.home_tab.Name = "home_tab";
            this.home_tab.Text = "صفحه اصلی";
            // 
            // superTabItem9
            // 
            this.superTabItem9.AttachedControl = this.superTabControlPanel9;
            this.superTabItem9.GlobalItem = false;
            this.superTabItem9.Icon = ((System.Drawing.Icon)(resources.GetObject("superTabItem9.Icon")));
            this.superTabItem9.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem9.Name = "superTabItem9";
            this.superTabItem9.Text = "مشاهده و جست ";
            // 
            // superTabControlPanel9
            // 
            this.superTabControlPanel9.Controls.Add(this.labelX5);
            this.superTabControlPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel9.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel9.Name = "superTabControlPanel9";
            this.superTabControlPanel9.Size = new System.Drawing.Size(765, 673);
            this.superTabControlPanel9.TabIndex = 3;
            this.superTabControlPanel9.TabItem = this.superTabItem9;
            // 
            // labelX5
            // 
            this.labelX5.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelX5.Location = new System.Drawing.Point(0, 0);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(765, 673);
            this.labelX5.TabIndex = 7;
            this.labelX5.Text = "This space intentionally left blank.";
            this.labelX5.TextAlignment = System.Drawing.StringAlignment.Center;
            // 
            // mainPage
            // 
            this.mainPage.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            // 
            // 
            // 
            this.mainPage.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.mainPage.ControlBox.MenuBox.Name = "";
            this.mainPage.ControlBox.Name = "";
            this.mainPage.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.mainPage.ControlBox.MenuBox,
            this.mainPage.ControlBox.CloseBox});
            this.mainPage.Controls.Add(this.superTabControlPanel6);
            this.mainPage.Controls.Add(this.superTabControlPanel5);
            this.mainPage.Controls.Add(this.superTabControlPanel1);
            this.mainPage.Controls.Add(this.superTabControlPanel3);
            this.mainPage.Controls.Add(this.superTabControlPanel7);
            this.mainPage.Controls.Add(this.superTabControlPanel4);
            this.mainPage.Controls.Add(this.superTabControlPanel12);
            this.mainPage.Controls.Add(this.superTabControlPanel11);
            this.mainPage.Controls.Add(this.superTabControlPanel10);
            this.mainPage.Controls.Add(this.superTabControlPanel2);
            this.mainPage.Controls.Add(this.superTabControlPanel13);
            this.mainPage.Font = new System.Drawing.Font("B Yekan+", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.mainPage.Location = new System.Drawing.Point(0, 11);
            this.mainPage.Name = "mainPage";
            this.mainPage.ReorderTabsEnabled = false;
            this.mainPage.SelectedTabFont = new System.Drawing.Font("B Elham", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)), true);
            this.mainPage.SelectedTabIndex = 0;
            this.mainPage.Size = new System.Drawing.Size(1006, 706);
            this.mainPage.TabAlignment = DevComponents.DotNetBar.eTabStripAlignment.Right;
            this.mainPage.TabFont = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.mainPage.TabHorizontalSpacing = 0;
            this.mainPage.TabIndex = 0;
            this.mainPage.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.homeTab,
            this.addProposalTab,
            this.searchProposalTab,
            this.manageProposalTab,
            this.manageTeacherTab,
            this.manageUserTab,
            this.appSettingsTab,
            this.personalSettingsTab,
            this.aboutUsTab,
            this.sysLogTab,
            this.exitTab});
            superTabLinearGradientColorTable1.AdaptiveGradient = true;
            superTabColorTable1.Background = superTabLinearGradientColorTable1;
            this.mainPage.TabStripColor = superTabColorTable1;
            this.mainPage.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.VisualStudio2008Document;
            this.mainPage.TabsVisible = false;
            this.mainPage.TabVerticalSpacing = 0;
            this.mainPage.TextAlignment = DevComponents.DotNetBar.eItemAlignment.Center;
            // 
            // superTabControlPanel11
            // 
            this.superTabControlPanel11.Controls.Add(this.logPanel);
            this.superTabControlPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel11.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel11.Margin = new System.Windows.Forms.Padding(2);
            this.superTabControlPanel11.Name = "superTabControlPanel11";
            this.superTabControlPanel11.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel11.TabIndex = 1;
            this.superTabControlPanel11.TabItem = this.sysLogTab;
            // 
            // logPanel
            // 
            this.logPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.logPanel.Controls.Add(this.logNavigationPanel);
            this.logPanel.Controls.Add(this.logDgv);
            this.logPanel.Location = new System.Drawing.Point(2, 2);
            this.logPanel.Margin = new System.Windows.Forms.Padding(2);
            this.logPanel.Name = "logPanel";
            this.logPanel.Size = new System.Drawing.Size(898, 586);
            this.logPanel.TabIndex = 2;
            this.logPanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // logNavigationPanel
            // 
            this.logNavigationPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logNavigationPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.logNavigationPanel.Controls.Add(this.logNavigationCurrentPageTxtbx);
            this.logNavigationPanel.Controls.Add(this.logNavigationNextPageBtn);
            this.logNavigationPanel.Controls.Add(this.logNavigationLastPageBtn);
            this.logNavigationPanel.Controls.Add(this.logNavigationPreviousPageBtn);
            this.logNavigationPanel.Controls.Add(this.logNavigationFirstPageBtn);
            this.logNavigationPanel.Controls.Add(this.logNavigationReturnBtn);
            this.logNavigationPanel.Location = new System.Drawing.Point(147, 420);
            this.logNavigationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.logNavigationPanel.Name = "logNavigationPanel";
            this.logNavigationPanel.Size = new System.Drawing.Size(615, 33);
            this.logNavigationPanel.TabIndex = 5;
            // 
            // logNavigationCurrentPageTxtbx
            // 
            // 
            // 
            // 
            this.logNavigationCurrentPageTxtbx.Border.Class = "TextBoxBorder";
            this.logNavigationCurrentPageTxtbx.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.logNavigationCurrentPageTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.logNavigationCurrentPageTxtbx.Location = new System.Drawing.Point(271, 3);
            this.logNavigationCurrentPageTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.logNavigationCurrentPageTxtbx.MaxLength = 5;
            this.logNavigationCurrentPageTxtbx.Multiline = true;
            this.logNavigationCurrentPageTxtbx.Name = "logNavigationCurrentPageTxtbx";
            this.logNavigationCurrentPageTxtbx.PreventEnterBeep = true;
            this.logNavigationCurrentPageTxtbx.Size = new System.Drawing.Size(74, 24);
            this.logNavigationCurrentPageTxtbx.TabIndex = 34;
            this.logNavigationCurrentPageTxtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.logNavigationCurrentPageTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.logNavigationCurrentPageTxtbx_KeyPress);
            // 
            // logNavigationNextPageBtn
            // 
            this.logNavigationNextPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.logNavigationNextPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.logNavigationNextPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.logNavigationNextPageBtn.Location = new System.Drawing.Point(349, 3);
            this.logNavigationNextPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.logNavigationNextPageBtn.Name = "logNavigationNextPageBtn";
            this.logNavigationNextPageBtn.Size = new System.Drawing.Size(82, 24);
            this.logNavigationNextPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.logNavigationNextPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem10});
            this.logNavigationNextPageBtn.SubItemsExpandWidth = 0;
            this.logNavigationNextPageBtn.TabIndex = 33;
            this.logNavigationNextPageBtn.Text = "صفحه بعد";
            this.logNavigationNextPageBtn.Click += new System.EventHandler(this.logNavigationNextPageBtn_Click);
            // 
            // superTabItem10
            // 
            this.superTabItem10.GlobalItem = false;
            this.superTabItem10.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem10.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem10.Name = "superTabItem10";
            this.superTabItem10.Text = "لاگ";
            // 
            // logNavigationLastPageBtn
            // 
            this.logNavigationLastPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.logNavigationLastPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.logNavigationLastPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.logNavigationLastPageBtn.Location = new System.Drawing.Point(436, 3);
            this.logNavigationLastPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.logNavigationLastPageBtn.Name = "logNavigationLastPageBtn";
            this.logNavigationLastPageBtn.Size = new System.Drawing.Size(82, 24);
            this.logNavigationLastPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.logNavigationLastPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem16});
            this.logNavigationLastPageBtn.SubItemsExpandWidth = 0;
            this.logNavigationLastPageBtn.TabIndex = 32;
            this.logNavigationLastPageBtn.Text = "صفحه آخر";
            this.logNavigationLastPageBtn.Click += new System.EventHandler(this.logNavigationLastPageBtn_Click);
            // 
            // superTabItem16
            // 
            this.superTabItem16.GlobalItem = false;
            this.superTabItem16.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem16.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem16.Name = "superTabItem16";
            this.superTabItem16.Text = "لاگ";
            // 
            // logNavigationPreviousPageBtn
            // 
            this.logNavigationPreviousPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.logNavigationPreviousPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.logNavigationPreviousPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.logNavigationPreviousPageBtn.Location = new System.Drawing.Point(184, 3);
            this.logNavigationPreviousPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.logNavigationPreviousPageBtn.Name = "logNavigationPreviousPageBtn";
            this.logNavigationPreviousPageBtn.Size = new System.Drawing.Size(82, 24);
            this.logNavigationPreviousPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.logNavigationPreviousPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem22});
            this.logNavigationPreviousPageBtn.SubItemsExpandWidth = 0;
            this.logNavigationPreviousPageBtn.TabIndex = 30;
            this.logNavigationPreviousPageBtn.Text = "صفحه قبل";
            this.logNavigationPreviousPageBtn.Click += new System.EventHandler(this.logNavigationPreviousPageBtn_Click);
            // 
            // superTabItem22
            // 
            this.superTabItem22.GlobalItem = false;
            this.superTabItem22.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem22.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem22.Name = "superTabItem22";
            this.superTabItem22.Text = "لاگ";
            // 
            // logNavigationFirstPageBtn
            // 
            this.logNavigationFirstPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.logNavigationFirstPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.logNavigationFirstPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.logNavigationFirstPageBtn.Location = new System.Drawing.Point(97, 3);
            this.logNavigationFirstPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.logNavigationFirstPageBtn.Name = "logNavigationFirstPageBtn";
            this.logNavigationFirstPageBtn.Size = new System.Drawing.Size(82, 24);
            this.logNavigationFirstPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.logNavigationFirstPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem28});
            this.logNavigationFirstPageBtn.SubItemsExpandWidth = 0;
            this.logNavigationFirstPageBtn.TabIndex = 29;
            this.logNavigationFirstPageBtn.Text = "صفحه اول";
            this.logNavigationFirstPageBtn.Click += new System.EventHandler(this.logNavigationFirstPageBtn_Click);
            // 
            // superTabItem28
            // 
            this.superTabItem28.GlobalItem = false;
            this.superTabItem28.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem28.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem28.Name = "superTabItem28";
            this.superTabItem28.Text = "لاگ";
            // 
            // logNavigationReturnBtn
            // 
            this.logNavigationReturnBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.logNavigationReturnBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.logNavigationReturnBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.logNavigationReturnBtn.Location = new System.Drawing.Point(10, 3);
            this.logNavigationReturnBtn.Margin = new System.Windows.Forms.Padding(2);
            this.logNavigationReturnBtn.Name = "logNavigationReturnBtn";
            this.logNavigationReturnBtn.Size = new System.Drawing.Size(82, 24);
            this.logNavigationReturnBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.logNavigationReturnBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem34});
            this.logNavigationReturnBtn.SubItemsExpandWidth = 0;
            this.logNavigationReturnBtn.TabIndex = 28;
            this.logNavigationReturnBtn.Text = "بازگشت";
            // 
            // superTabItem34
            // 
            this.superTabItem34.GlobalItem = false;
            this.superTabItem34.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem34.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem34.Name = "superTabItem34";
            this.superTabItem34.Text = "لاگ";
            // 
            // logDgv
            // 
            this.logDgv.AllowUserToAddRows = false;
            this.logDgv.AllowUserToDeleteRows = false;
            this.logDgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.logDgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.logDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.logDgv.Location = new System.Drawing.Point(14, 15);
            this.logDgv.Margin = new System.Windows.Forms.Padding(2);
            this.logDgv.MultiSelect = false;
            this.logDgv.Name = "logDgv";
            this.logDgv.ReadOnly = true;
            this.logDgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("B Yekan+", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(226)))), ((int)(((byte)(171)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.logDgv.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.logDgv.RowTemplate.Height = 24;
            this.logDgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.logDgv.Size = new System.Drawing.Size(830, 397);
            this.logDgv.TabIndex = 1;
            this.logDgv.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // sysLogTab
            // 
            this.sysLogTab.AttachedControl = this.superTabControlPanel11;
            this.sysLogTab.GlobalItem = false;
            this.sysLogTab.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.sysLogTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.sysLogTab.Name = "sysLogTab";
            this.sysLogTab.Text = "SystemLog";
            this.sysLogTab.Tooltip = "Log of system";
            this.sysLogTab.Visible = false;
            this.sysLogTab.Click += new System.EventHandler(this.sysLogTab_Click);
            this.sysLogTab.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // superTabControlPanel10
            // 
            this.superTabControlPanel10.Controls.Add(this.aboutUsPanel);
            this.superTabControlPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel10.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel10.Margin = new System.Windows.Forms.Padding(2);
            this.superTabControlPanel10.Name = "superTabControlPanel10";
            this.superTabControlPanel10.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel10.TabIndex = 0;
            this.superTabControlPanel10.TabItem = this.aboutUsTab;
            // 
            // aboutUsPanel
            // 
            this.aboutUsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.aboutUsPanel.Controls.Add(this.aboutUsGp);
            this.aboutUsPanel.Location = new System.Drawing.Point(2, 8);
            this.aboutUsPanel.Margin = new System.Windows.Forms.Padding(2);
            this.aboutUsPanel.Name = "aboutUsPanel";
            this.aboutUsPanel.Size = new System.Drawing.Size(876, 594);
            this.aboutUsPanel.TabIndex = 2;
            this.aboutUsPanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // aboutUsGp
            // 
            this.aboutUsGp.BackColor = System.Drawing.Color.Transparent;
            this.aboutUsGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.aboutUsGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.aboutUsGp.Controls.Add(this.aboutUsAlirezaLbl);
            this.aboutUsGp.Controls.Add(this.aboutUsNimaLbl);
            this.aboutUsGp.Controls.Add(this.aboutUsHoseinLbl);
            this.aboutUsGp.Controls.Add(this.aboutUsPeymanLbl);
            this.aboutUsGp.Controls.Add(this.AboutUsArshinLbl);
            this.aboutUsGp.Controls.Add(this.aboutUsTitleLbl);
            this.aboutUsGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.aboutUsGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.aboutUsGp.Location = new System.Drawing.Point(143, 124);
            this.aboutUsGp.Name = "aboutUsGp";
            this.aboutUsGp.Size = new System.Drawing.Size(615, 263);
            // 
            // 
            // 
            this.aboutUsGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.aboutUsGp.Style.BackColorGradientAngle = 90;
            this.aboutUsGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.aboutUsGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.aboutUsGp.Style.BorderBottomWidth = 2;
            this.aboutUsGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.aboutUsGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.aboutUsGp.Style.BorderLeftWidth = 2;
            this.aboutUsGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.aboutUsGp.Style.BorderRightWidth = 2;
            this.aboutUsGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.aboutUsGp.Style.BorderTopWidth = 2;
            this.aboutUsGp.Style.CornerDiameter = 10;
            this.aboutUsGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.aboutUsGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.aboutUsGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.aboutUsGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.aboutUsGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.aboutUsGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.aboutUsGp.TabIndex = 1;
            this.aboutUsGp.Text = "درباره ما";
            this.aboutUsGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // aboutUsAlirezaLbl
            // 
            this.aboutUsAlirezaLbl.BackColor = System.Drawing.Color.Transparent;
            this.aboutUsAlirezaLbl.Location = new System.Drawing.Point(501, 201);
            this.aboutUsAlirezaLbl.Name = "aboutUsAlirezaLbl";
            this.aboutUsAlirezaLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.aboutUsAlirezaLbl.Size = new System.Drawing.Size(76, 20);
            this.aboutUsAlirezaLbl.TabIndex = 5;
            this.aboutUsAlirezaLbl.Text = "علیرضا سلطانی";
            this.aboutUsAlirezaLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // aboutUsNimaLbl
            // 
            this.aboutUsNimaLbl.BackColor = System.Drawing.Color.Transparent;
            this.aboutUsNimaLbl.Location = new System.Drawing.Point(523, 162);
            this.aboutUsNimaLbl.Name = "aboutUsNimaLbl";
            this.aboutUsNimaLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.aboutUsNimaLbl.Size = new System.Drawing.Size(56, 20);
            this.aboutUsNimaLbl.TabIndex = 4;
            this.aboutUsNimaLbl.Text = "نیما کاظمی";
            this.aboutUsNimaLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // aboutUsHoseinLbl
            // 
            this.aboutUsHoseinLbl.BackColor = System.Drawing.Color.Transparent;
            this.aboutUsHoseinLbl.Location = new System.Drawing.Point(466, 124);
            this.aboutUsHoseinLbl.Name = "aboutUsHoseinLbl";
            this.aboutUsHoseinLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.aboutUsHoseinLbl.Size = new System.Drawing.Size(111, 20);
            this.aboutUsHoseinLbl.TabIndex = 3;
            this.aboutUsHoseinLbl.Text = "سید حسین سیدی نژاد";
            this.aboutUsHoseinLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // aboutUsPeymanLbl
            // 
            this.aboutUsPeymanLbl.BackColor = System.Drawing.Color.Transparent;
            this.aboutUsPeymanLbl.Location = new System.Drawing.Point(513, 90);
            this.aboutUsPeymanLbl.Name = "aboutUsPeymanLbl";
            this.aboutUsPeymanLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.aboutUsPeymanLbl.Size = new System.Drawing.Size(66, 20);
            this.aboutUsPeymanLbl.TabIndex = 2;
            this.aboutUsPeymanLbl.Text = "پیمان قبیتی ";
            this.aboutUsPeymanLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AboutUsArshinLbl
            // 
            this.AboutUsArshinLbl.BackColor = System.Drawing.Color.Transparent;
            this.AboutUsArshinLbl.Font = new System.Drawing.Font("B Yekan+", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.AboutUsArshinLbl.Location = new System.Drawing.Point(489, 48);
            this.AboutUsArshinLbl.Name = "AboutUsArshinLbl";
            this.AboutUsArshinLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.AboutUsArshinLbl.Size = new System.Drawing.Size(94, 22);
            this.AboutUsArshinLbl.TabIndex = 1;
            this.AboutUsArshinLbl.Text = "مهندس رضازاده";
            this.AboutUsArshinLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // aboutUsTitleLbl
            // 
            this.aboutUsTitleLbl.Font = new System.Drawing.Font("B Yekan+", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.aboutUsTitleLbl.Location = new System.Drawing.Point(352, 0);
            this.aboutUsTitleLbl.Name = "aboutUsTitleLbl";
            this.aboutUsTitleLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.aboutUsTitleLbl.Size = new System.Drawing.Size(238, 28);
            this.aboutUsTitleLbl.TabIndex = 0;
            this.aboutUsTitleLbl.Text = "طراحی و توسعه نرم افزار:";
            // 
            // aboutUsTab
            // 
            this.aboutUsTab.AttachedControl = this.superTabControlPanel10;
            this.aboutUsTab.GlobalItem = false;
            this.aboutUsTab.Image = global::ProposalReportingSystem.Properties.Resources.about_us;
            this.aboutUsTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.aboutUsTab.Name = "aboutUsTab";
            this.aboutUsTab.Text = "درباره ما";
            // 
            // superTabControlPanel7
            // 
            this.superTabControlPanel7.Controls.Add(this.personalSettingPanel);
            this.superTabControlPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel7.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel7.Name = "superTabControlPanel7";
            this.superTabControlPanel7.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel7.TabIndex = 0;
            this.superTabControlPanel7.TabItem = this.personalSettingsTab;
            // 
            // personalSettingPanel
            // 
            this.personalSettingPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.personalSettingPanel.Controls.Add(this.personalSettingThemeGp);
            this.personalSettingPanel.Controls.Add(this.personalSettingPasswordGp);
            this.personalSettingPanel.Location = new System.Drawing.Point(-1, 0);
            this.personalSettingPanel.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingPanel.Name = "personalSettingPanel";
            this.personalSettingPanel.Size = new System.Drawing.Size(889, 666);
            this.personalSettingPanel.TabIndex = 1;
            this.personalSettingPanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // personalSettingThemeGp
            // 
            this.personalSettingThemeGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.personalSettingThemeGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.personalSettingThemeGp.Controls.Add(this.appSettingBackgroundChangeGp);
            this.personalSettingThemeGp.Controls.Add(this.appSettingBackgroundChangeLbl);
            this.personalSettingThemeGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.personalSettingThemeGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.personalSettingThemeGp.Location = new System.Drawing.Point(20, 278);
            this.personalSettingThemeGp.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingThemeGp.Name = "personalSettingThemeGp";
            this.personalSettingThemeGp.Size = new System.Drawing.Size(848, 285);
            // 
            // 
            // 
            this.personalSettingThemeGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.personalSettingThemeGp.Style.BackColorGradientAngle = 90;
            this.personalSettingThemeGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.personalSettingThemeGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.personalSettingThemeGp.Style.BorderBottomWidth = 2;
            this.personalSettingThemeGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.personalSettingThemeGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.personalSettingThemeGp.Style.BorderLeftWidth = 2;
            this.personalSettingThemeGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.personalSettingThemeGp.Style.BorderRightWidth = 2;
            this.personalSettingThemeGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.personalSettingThemeGp.Style.BorderTopWidth = 2;
            this.personalSettingThemeGp.Style.CornerDiameter = 10;
            this.personalSettingThemeGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.personalSettingThemeGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.personalSettingThemeGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.personalSettingThemeGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.personalSettingThemeGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.personalSettingThemeGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.personalSettingThemeGp.TabIndex = 1;
            this.personalSettingThemeGp.Text = "تغییر نمای ظاهری";
            this.personalSettingThemeGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingBackgroundChangeGp
            // 
            this.appSettingBackgroundChangeGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.appSettingBackgroundChangeGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.appSettingBackgroundChangeGp.Controls.Add(this.label1);
            this.appSettingBackgroundChangeGp.Controls.Add(this.appSettingBackgroundColorLbl);
            this.appSettingBackgroundChangeGp.Controls.Add(this.label2);
            this.appSettingBackgroundChangeGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.appSettingBackgroundChangeGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingBackgroundChangeGp.Location = new System.Drawing.Point(362, 68);
            this.appSettingBackgroundChangeGp.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingBackgroundChangeGp.Name = "appSettingBackgroundChangeGp";
            this.appSettingBackgroundChangeGp.Size = new System.Drawing.Size(134, 139);
            // 
            // 
            // 
            this.appSettingBackgroundChangeGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.appSettingBackgroundChangeGp.Style.BackColorGradientAngle = 90;
            this.appSettingBackgroundChangeGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.appSettingBackgroundChangeGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingBackgroundChangeGp.Style.BorderBottomWidth = 2;
            this.appSettingBackgroundChangeGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.appSettingBackgroundChangeGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingBackgroundChangeGp.Style.BorderLeftWidth = 2;
            this.appSettingBackgroundChangeGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingBackgroundChangeGp.Style.BorderRightWidth = 2;
            this.appSettingBackgroundChangeGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingBackgroundChangeGp.Style.BorderTopWidth = 2;
            this.appSettingBackgroundChangeGp.Style.CornerDiameter = 10;
            this.appSettingBackgroundChangeGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.appSettingBackgroundChangeGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.appSettingBackgroundChangeGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.appSettingBackgroundChangeGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.appSettingBackgroundChangeGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.appSettingBackgroundChangeGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.appSettingBackgroundChangeGp.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(581, 106);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 106);
            this.label1.TabIndex = 16;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // appSettingBackgroundColorLbl
            // 
            this.appSettingBackgroundColorLbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.appSettingBackgroundColorLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.appSettingBackgroundColorLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingBackgroundColorLbl.Location = new System.Drawing.Point(14, 12);
            this.appSettingBackgroundColorLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.appSettingBackgroundColorLbl.Name = "appSettingBackgroundColorLbl";
            this.appSettingBackgroundColorLbl.Size = new System.Drawing.Size(98, 106);
            this.appSettingBackgroundColorLbl.TabIndex = 16;
            this.appSettingBackgroundColorLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.appSettingBackgroundColorLbl.Click += new System.EventHandler(this.appSettingBackgroundColorLbl_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(616, 22);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "تغییر رنگ پس زمینه";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // appSettingBackgroundChangeLbl
            // 
            this.appSettingBackgroundChangeLbl.BackColor = System.Drawing.Color.Transparent;
            this.appSettingBackgroundChangeLbl.Font = new System.Drawing.Font("B Yekan+", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingBackgroundChangeLbl.Location = new System.Drawing.Point(355, 30);
            this.appSettingBackgroundChangeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.appSettingBackgroundChangeLbl.Name = "appSettingBackgroundChangeLbl";
            this.appSettingBackgroundChangeLbl.Size = new System.Drawing.Size(148, 20);
            this.appSettingBackgroundChangeLbl.TabIndex = 15;
            this.appSettingBackgroundChangeLbl.Text = "تغییر رنگ پس زمینه";
            this.appSettingBackgroundChangeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // personalSettingPasswordGp
            // 
            this.personalSettingPasswordGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.personalSettingPasswordGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.personalSettingPasswordGp.Controls.Add(this.personalSettingOldPasswordChb);
            this.personalSettingPasswordGp.Controls.Add(this.personalSettingNewPasswordChb);
            this.personalSettingPasswordGp.Controls.Add(this.personalSettingRepeatPasswordChb);
            this.personalSettingPasswordGp.Controls.Add(this.personalSettingRepeatPasswordTxtbx);
            this.personalSettingPasswordGp.Controls.Add(this.personalSettingNewPasswordTxtbx);
            this.personalSettingPasswordGp.Controls.Add(this.personalSettingOldPasswordTxtbx);
            this.personalSettingPasswordGp.Controls.Add(this.confirmNewPasswordLbl);
            this.personalSettingPasswordGp.Controls.Add(this.newPasswordLbl);
            this.personalSettingPasswordGp.Controls.Add(this.currentPasswordLbl);
            this.personalSettingPasswordGp.Controls.Add(this.personalSettingRegisterBtn);
            this.personalSettingPasswordGp.Controls.Add(this.personalSettingClearBtn);
            this.personalSettingPasswordGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.personalSettingPasswordGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.personalSettingPasswordGp.Location = new System.Drawing.Point(20, 10);
            this.personalSettingPasswordGp.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingPasswordGp.Name = "personalSettingPasswordGp";
            this.personalSettingPasswordGp.Size = new System.Drawing.Size(848, 241);
            // 
            // 
            // 
            this.personalSettingPasswordGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.personalSettingPasswordGp.Style.BackColorGradientAngle = 90;
            this.personalSettingPasswordGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.personalSettingPasswordGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.personalSettingPasswordGp.Style.BorderBottomWidth = 2;
            this.personalSettingPasswordGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.personalSettingPasswordGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.personalSettingPasswordGp.Style.BorderLeftWidth = 2;
            this.personalSettingPasswordGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.personalSettingPasswordGp.Style.BorderRightWidth = 2;
            this.personalSettingPasswordGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.personalSettingPasswordGp.Style.BorderTopWidth = 2;
            this.personalSettingPasswordGp.Style.CornerDiameter = 10;
            this.personalSettingPasswordGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.personalSettingPasswordGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.personalSettingPasswordGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.personalSettingPasswordGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.personalSettingPasswordGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.personalSettingPasswordGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.personalSettingPasswordGp.TabIndex = 0;
            this.personalSettingPasswordGp.Text = "تغییر رمز عبور";
            this.personalSettingPasswordGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // personalSettingOldPasswordChb
            // 
            this.personalSettingOldPasswordChb.BackColor = System.Drawing.Color.Transparent;
            this.personalSettingOldPasswordChb.Location = new System.Drawing.Point(474, 35);
            this.personalSettingOldPasswordChb.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingOldPasswordChb.Name = "personalSettingOldPasswordChb";
            this.personalSettingOldPasswordChb.Size = new System.Drawing.Size(22, 24);
            this.personalSettingOldPasswordChb.TabIndex = 37;
            this.personalSettingOldPasswordChb.UseVisualStyleBackColor = false;
            this.personalSettingOldPasswordChb.MouseDown += new System.Windows.Forms.MouseEventHandler(this.personalSettingOldPassChb_MouseDown);
            this.personalSettingOldPasswordChb.MouseUp += new System.Windows.Forms.MouseEventHandler(this.personalSettingOldPassChb_MouseUp);
            // 
            // personalSettingNewPasswordChb
            // 
            this.personalSettingNewPasswordChb.BackColor = System.Drawing.Color.Transparent;
            this.personalSettingNewPasswordChb.Location = new System.Drawing.Point(474, 66);
            this.personalSettingNewPasswordChb.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingNewPasswordChb.Name = "personalSettingNewPasswordChb";
            this.personalSettingNewPasswordChb.Size = new System.Drawing.Size(22, 20);
            this.personalSettingNewPasswordChb.TabIndex = 36;
            this.personalSettingNewPasswordChb.UseVisualStyleBackColor = false;
            this.personalSettingNewPasswordChb.MouseDown += new System.Windows.Forms.MouseEventHandler(this.personalSettingNewPassChb_MouseDown);
            this.personalSettingNewPasswordChb.MouseUp += new System.Windows.Forms.MouseEventHandler(this.personalSettingNewPassChb_MouseUp);
            // 
            // personalSettingRepeatPasswordChb
            // 
            this.personalSettingRepeatPasswordChb.BackColor = System.Drawing.Color.Transparent;
            this.personalSettingRepeatPasswordChb.Location = new System.Drawing.Point(474, 93);
            this.personalSettingRepeatPasswordChb.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingRepeatPasswordChb.Name = "personalSettingRepeatPasswordChb";
            this.personalSettingRepeatPasswordChb.Size = new System.Drawing.Size(22, 20);
            this.personalSettingRepeatPasswordChb.TabIndex = 35;
            this.personalSettingRepeatPasswordChb.UseVisualStyleBackColor = false;
            this.personalSettingRepeatPasswordChb.MouseDown += new System.Windows.Forms.MouseEventHandler(this.personalSettingRepeatPassChb_MouseDown);
            this.personalSettingRepeatPasswordChb.MouseUp += new System.Windows.Forms.MouseEventHandler(this.personalSettingRepeatPassChb_MouseUp);
            // 
            // personalSettingRepeatPasswordTxtbx
            // 
            this.personalSettingRepeatPasswordTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.personalSettingRepeatPasswordTxtbx.Location = new System.Drawing.Point(253, 92);
            this.personalSettingRepeatPasswordTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingRepeatPasswordTxtbx.MaxLength = 12;
            this.personalSettingRepeatPasswordTxtbx.Name = "personalSettingRepeatPasswordTxtbx";
            this.personalSettingRepeatPasswordTxtbx.PasswordChar = '●';
            this.personalSettingRepeatPasswordTxtbx.Size = new System.Drawing.Size(217, 25);
            this.personalSettingRepeatPasswordTxtbx.TabIndex = 11;
            // 
            // personalSettingNewPasswordTxtbx
            // 
            this.personalSettingNewPasswordTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.personalSettingNewPasswordTxtbx.Location = new System.Drawing.Point(253, 63);
            this.personalSettingNewPasswordTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingNewPasswordTxtbx.MaxLength = 12;
            this.personalSettingNewPasswordTxtbx.Name = "personalSettingNewPasswordTxtbx";
            this.personalSettingNewPasswordTxtbx.PasswordChar = '●';
            this.personalSettingNewPasswordTxtbx.Size = new System.Drawing.Size(217, 25);
            this.personalSettingNewPasswordTxtbx.TabIndex = 10;
            // 
            // personalSettingOldPasswordTxtbx
            // 
            this.personalSettingOldPasswordTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.personalSettingOldPasswordTxtbx.Location = new System.Drawing.Point(253, 35);
            this.personalSettingOldPasswordTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingOldPasswordTxtbx.MaxLength = 12;
            this.personalSettingOldPasswordTxtbx.Name = "personalSettingOldPasswordTxtbx";
            this.personalSettingOldPasswordTxtbx.PasswordChar = '●';
            this.personalSettingOldPasswordTxtbx.Size = new System.Drawing.Size(217, 25);
            this.personalSettingOldPasswordTxtbx.TabIndex = 9;
            // 
            // confirmNewPasswordLbl
            // 
            this.confirmNewPasswordLbl.BackColor = System.Drawing.Color.Transparent;
            this.confirmNewPasswordLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.confirmNewPasswordLbl.Location = new System.Drawing.Point(516, 94);
            this.confirmNewPasswordLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.confirmNewPasswordLbl.Name = "confirmNewPasswordLbl";
            this.confirmNewPasswordLbl.Size = new System.Drawing.Size(106, 20);
            this.confirmNewPasswordLbl.TabIndex = 14;
            this.confirmNewPasswordLbl.Text = "تکرار رمز جدید";
            this.confirmNewPasswordLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // newPasswordLbl
            // 
            this.newPasswordLbl.BackColor = System.Drawing.Color.Transparent;
            this.newPasswordLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.newPasswordLbl.Location = new System.Drawing.Point(516, 64);
            this.newPasswordLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.newPasswordLbl.Name = "newPasswordLbl";
            this.newPasswordLbl.Size = new System.Drawing.Size(107, 20);
            this.newPasswordLbl.TabIndex = 13;
            this.newPasswordLbl.Text = "رمز جدید";
            this.newPasswordLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // currentPasswordLbl
            // 
            this.currentPasswordLbl.BackColor = System.Drawing.Color.Transparent;
            this.currentPasswordLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.currentPasswordLbl.Location = new System.Drawing.Point(516, 37);
            this.currentPasswordLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.currentPasswordLbl.Name = "currentPasswordLbl";
            this.currentPasswordLbl.Size = new System.Drawing.Size(106, 22);
            this.currentPasswordLbl.TabIndex = 12;
            this.currentPasswordLbl.Text = "رمز فعلی";
            this.currentPasswordLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // personalSettingRegisterBtn
            // 
            this.personalSettingRegisterBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.personalSettingRegisterBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.personalSettingRegisterBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.personalSettingRegisterBtn.Location = new System.Drawing.Point(253, 136);
            this.personalSettingRegisterBtn.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingRegisterBtn.Name = "personalSettingRegisterBtn";
            this.personalSettingRegisterBtn.Size = new System.Drawing.Size(94, 30);
            this.personalSettingRegisterBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.personalSettingRegisterBtn.TabIndex = 34;
            this.personalSettingRegisterBtn.Text = "ثبت تغییرات";
            this.personalSettingRegisterBtn.Click += new System.EventHandler(this.personalSettingRegisterBtn_Click);
            // 
            // personalSettingClearBtn
            // 
            this.personalSettingClearBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.personalSettingClearBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.personalSettingClearBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.personalSettingClearBtn.Location = new System.Drawing.Point(375, 136);
            this.personalSettingClearBtn.Margin = new System.Windows.Forms.Padding(2);
            this.personalSettingClearBtn.Name = "personalSettingClearBtn";
            this.personalSettingClearBtn.Size = new System.Drawing.Size(94, 30);
            this.personalSettingClearBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.personalSettingClearBtn.TabIndex = 33;
            this.personalSettingClearBtn.Text = "پاک کردن";
            this.personalSettingClearBtn.Click += new System.EventHandler(this.personalSettingClearBtn_Click);
            // 
            // personalSettingsTab
            // 
            this.personalSettingsTab.AttachedControl = this.superTabControlPanel7;
            this.personalSettingsTab.GlobalItem = false;
            this.personalSettingsTab.Image = global::ProposalReportingSystem.Properties.Resources.user__1_;
            this.personalSettingsTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.personalSettingsTab.Name = "personalSettingsTab";
            this.personalSettingsTab.Text = "تنظیمات شخصی";
            // 
            // superTabControlPanel6
            // 
            this.superTabControlPanel6.Controls.Add(this.appSettingPanel);
            this.superTabControlPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel6.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel6.Name = "superTabControlPanel6";
            this.superTabControlPanel6.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel6.TabIndex = 0;
            this.superTabControlPanel6.TabItem = this.appSettingsTab;
            // 
            // appSettingPanel
            // 
            this.appSettingPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.appSettingPanel.Controls.Add(this.appSettingShowGp);
            this.appSettingPanel.Controls.Add(this.appSettingGp);
            this.appSettingPanel.Location = new System.Drawing.Point(1, 2);
            this.appSettingPanel.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingPanel.Name = "appSettingPanel";
            this.appSettingPanel.Size = new System.Drawing.Size(885, 654);
            this.appSettingPanel.TabIndex = 1;
            this.appSettingPanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingShowGp
            // 
            this.appSettingShowGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.appSettingShowGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.appSettingShowGp.Controls.Add(this.appSettingNavigationPanel);
            this.appSettingShowGp.Controls.Add(this.appSettingShowDv);
            this.appSettingShowGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.appSettingShowGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingShowGp.Location = new System.Drawing.Point(12, 321);
            this.appSettingShowGp.Name = "appSettingShowGp";
            this.appSettingShowGp.Size = new System.Drawing.Size(855, 270);
            // 
            // 
            // 
            this.appSettingShowGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.appSettingShowGp.Style.BackColorGradientAngle = 90;
            this.appSettingShowGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.appSettingShowGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingShowGp.Style.BorderBottomWidth = 2;
            this.appSettingShowGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.appSettingShowGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingShowGp.Style.BorderLeftWidth = 2;
            this.appSettingShowGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingShowGp.Style.BorderRightWidth = 2;
            this.appSettingShowGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingShowGp.Style.BorderTopWidth = 2;
            this.appSettingShowGp.Style.CornerDiameter = 10;
            this.appSettingShowGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.appSettingShowGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.appSettingShowGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.appSettingShowGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.appSettingShowGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.appSettingShowGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.appSettingShowGp.TabIndex = 3;
            this.appSettingShowGp.Text = "نمایش اطلاعات";
            this.appSettingShowGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingNavigationPanel
            // 
            this.appSettingNavigationPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.appSettingNavigationPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.appSettingNavigationPanel.Controls.Add(this.appSettingNavigationCurrentPageTxtbx);
            this.appSettingNavigationPanel.Controls.Add(this.appSettingNavigationNextPageBtn);
            this.appSettingNavigationPanel.Controls.Add(this.appSettingNavigationLastPageBtn);
            this.appSettingNavigationPanel.Controls.Add(this.appSettingNavigationPreviousPageBtn);
            this.appSettingNavigationPanel.Controls.Add(this.appSettingNavigationFirstPageBtn);
            this.appSettingNavigationPanel.Controls.Add(this.appSettingNavigationReturnBtn);
            this.appSettingNavigationPanel.Location = new System.Drawing.Point(110, 138);
            this.appSettingNavigationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingNavigationPanel.Name = "appSettingNavigationPanel";
            this.appSettingNavigationPanel.Size = new System.Drawing.Size(615, 33);
            this.appSettingNavigationPanel.TabIndex = 4;
            // 
            // appSettingNavigationCurrentPageTxtbx
            // 
            // 
            // 
            // 
            this.appSettingNavigationCurrentPageTxtbx.Border.Class = "TextBoxBorder";
            this.appSettingNavigationCurrentPageTxtbx.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.appSettingNavigationCurrentPageTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingNavigationCurrentPageTxtbx.Location = new System.Drawing.Point(271, 3);
            this.appSettingNavigationCurrentPageTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingNavigationCurrentPageTxtbx.MaxLength = 5;
            this.appSettingNavigationCurrentPageTxtbx.Multiline = true;
            this.appSettingNavigationCurrentPageTxtbx.Name = "appSettingNavigationCurrentPageTxtbx";
            this.appSettingNavigationCurrentPageTxtbx.PreventEnterBeep = true;
            this.appSettingNavigationCurrentPageTxtbx.Size = new System.Drawing.Size(74, 24);
            this.appSettingNavigationCurrentPageTxtbx.TabIndex = 34;
            this.appSettingNavigationCurrentPageTxtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // appSettingNavigationNextPageBtn
            // 
            this.appSettingNavigationNextPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.appSettingNavigationNextPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.appSettingNavigationNextPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingNavigationNextPageBtn.Location = new System.Drawing.Point(349, 3);
            this.appSettingNavigationNextPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingNavigationNextPageBtn.Name = "appSettingNavigationNextPageBtn";
            this.appSettingNavigationNextPageBtn.Size = new System.Drawing.Size(82, 24);
            this.appSettingNavigationNextPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.appSettingNavigationNextPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem32});
            this.appSettingNavigationNextPageBtn.SubItemsExpandWidth = 0;
            this.appSettingNavigationNextPageBtn.TabIndex = 33;
            this.appSettingNavigationNextPageBtn.Text = "صفحه بعد";
            // 
            // superTabItem32
            // 
            this.superTabItem32.GlobalItem = false;
            this.superTabItem32.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem32.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem32.Name = "superTabItem32";
            this.superTabItem32.Text = "لاگ";
            // 
            // appSettingNavigationLastPageBtn
            // 
            this.appSettingNavigationLastPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.appSettingNavigationLastPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.appSettingNavigationLastPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingNavigationLastPageBtn.Location = new System.Drawing.Point(436, 3);
            this.appSettingNavigationLastPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingNavigationLastPageBtn.Name = "appSettingNavigationLastPageBtn";
            this.appSettingNavigationLastPageBtn.Size = new System.Drawing.Size(82, 24);
            this.appSettingNavigationLastPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.appSettingNavigationLastPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem33});
            this.appSettingNavigationLastPageBtn.SubItemsExpandWidth = 0;
            this.appSettingNavigationLastPageBtn.TabIndex = 32;
            this.appSettingNavigationLastPageBtn.Text = "صفحه آخر";
            // 
            // superTabItem33
            // 
            this.superTabItem33.GlobalItem = false;
            this.superTabItem33.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem33.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem33.Name = "superTabItem33";
            this.superTabItem33.Text = "لاگ";
            // 
            // appSettingNavigationPreviousPageBtn
            // 
            this.appSettingNavigationPreviousPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.appSettingNavigationPreviousPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.appSettingNavigationPreviousPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingNavigationPreviousPageBtn.Location = new System.Drawing.Point(184, 3);
            this.appSettingNavigationPreviousPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingNavigationPreviousPageBtn.Name = "appSettingNavigationPreviousPageBtn";
            this.appSettingNavigationPreviousPageBtn.Size = new System.Drawing.Size(82, 24);
            this.appSettingNavigationPreviousPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.appSettingNavigationPreviousPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem35});
            this.appSettingNavigationPreviousPageBtn.SubItemsExpandWidth = 0;
            this.appSettingNavigationPreviousPageBtn.TabIndex = 30;
            this.appSettingNavigationPreviousPageBtn.Text = "صفحه قبل";
            // 
            // superTabItem35
            // 
            this.superTabItem35.GlobalItem = false;
            this.superTabItem35.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem35.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem35.Name = "superTabItem35";
            this.superTabItem35.Text = "لاگ";
            // 
            // appSettingNavigationFirstPageBtn
            // 
            this.appSettingNavigationFirstPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.appSettingNavigationFirstPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.appSettingNavigationFirstPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingNavigationFirstPageBtn.Location = new System.Drawing.Point(97, 3);
            this.appSettingNavigationFirstPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingNavigationFirstPageBtn.Name = "appSettingNavigationFirstPageBtn";
            this.appSettingNavigationFirstPageBtn.Size = new System.Drawing.Size(82, 24);
            this.appSettingNavigationFirstPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.appSettingNavigationFirstPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem36});
            this.appSettingNavigationFirstPageBtn.SubItemsExpandWidth = 0;
            this.appSettingNavigationFirstPageBtn.TabIndex = 29;
            this.appSettingNavigationFirstPageBtn.Text = "صفحه اول";
            // 
            // superTabItem36
            // 
            this.superTabItem36.GlobalItem = false;
            this.superTabItem36.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem36.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem36.Name = "superTabItem36";
            this.superTabItem36.Text = "لاگ";
            // 
            // appSettingNavigationReturnBtn
            // 
            this.appSettingNavigationReturnBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.appSettingNavigationReturnBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.appSettingNavigationReturnBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingNavigationReturnBtn.Location = new System.Drawing.Point(10, 3);
            this.appSettingNavigationReturnBtn.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingNavigationReturnBtn.Name = "appSettingNavigationReturnBtn";
            this.appSettingNavigationReturnBtn.Size = new System.Drawing.Size(82, 24);
            this.appSettingNavigationReturnBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.appSettingNavigationReturnBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem37});
            this.appSettingNavigationReturnBtn.SubItemsExpandWidth = 0;
            this.appSettingNavigationReturnBtn.TabIndex = 28;
            this.appSettingNavigationReturnBtn.Text = "بازگشت";
            // 
            // superTabItem37
            // 
            this.superTabItem37.GlobalItem = false;
            this.superTabItem37.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem37.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem37.Name = "superTabItem37";
            this.superTabItem37.Text = "لاگ";
            // 
            // appSettingShowDv
            // 
            this.appSettingShowDv.AllowUserToAddRows = false;
            this.appSettingShowDv.AllowUserToDeleteRows = false;
            this.appSettingShowDv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.appSettingShowDv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.appSettingShowDv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.appSettingShowDv.Location = new System.Drawing.Point(10, 1);
            this.appSettingShowDv.Margin = new System.Windows.Forms.Padding(2);
            this.appSettingShowDv.MultiSelect = false;
            this.appSettingShowDv.Name = "appSettingShowDv";
            this.appSettingShowDv.ReadOnly = true;
            this.appSettingShowDv.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingShowDv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.appSettingShowDv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(1);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(226)))), ((int)(((byte)(171)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.appSettingShowDv.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.appSettingShowDv.RowTemplate.Height = 24;
            this.appSettingShowDv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.appSettingShowDv.Size = new System.Drawing.Size(823, 124);
            this.appSettingShowDv.TabIndex = 2;
            this.appSettingShowDv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.appSettingShowDv_CellClick);
            this.appSettingShowDv.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.appSettingShowDv_CellDoubleClick);
            this.appSettingShowDv.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingGp
            // 
            this.appSettingGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.appSettingGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.appSettingGp.Controls.Add(this.appSettingEdegreeLbl);
            this.appSettingGp.Controls.Add(this.appSettingEdegreeTxtbx);
            this.appSettingGp.Controls.Add(this.appSettingEdegreeRbtn);
            this.appSettingGp.Controls.Add(this.appSettingBackBtn);
            this.appSettingGp.Controls.Add(this.appSettingEgroupLbl);
            this.appSettingGp.Controls.Add(this.appSettingFacultyLbl);
            this.appSettingGp.Controls.Add(this.appSettingFacultyTxtbx);
            this.appSettingGp.Controls.Add(this.appSettingEgroupTxtbx);
            this.appSettingGp.Controls.Add(this.appSettingFacultyRbtn);
            this.appSettingGp.Controls.Add(this.appSettingEgroupRbtn);
            this.appSettingGp.Controls.Add(this.appSettingStatusLbl);
            this.appSettingGp.Controls.Add(this.aapSettingCoLbl);
            this.appSettingGp.Controls.Add(this.appSettingProTypeLbl);
            this.appSettingGp.Controls.Add(this.appSettingRegTypeLbl);
            this.appSettingGp.Controls.Add(this.appSettingPropertyLbl);
            this.appSettingGp.Controls.Add(this.appSettingProcedureTypeLbl);
            this.appSettingGp.Controls.Add(this.appSettingStatusTxtbx);
            this.appSettingGp.Controls.Add(this.appSettingPropertyTxtbx);
            this.appSettingGp.Controls.Add(this.appSettingStatusRbtn);
            this.appSettingGp.Controls.Add(this.appSettingProTypeTxtbx);
            this.appSettingGp.Controls.Add(this.appSettingPropertyRbtn);
            this.appSettingGp.Controls.Add(this.appSettingCoTxtbx);
            this.appSettingGp.Controls.Add(this.appSettingProTypeRbtn);
            this.appSettingGp.Controls.Add(this.appSettingRegTypeTxtbx);
            this.appSettingGp.Controls.Add(this.appSettingCoRbtn);
            this.appSettingGp.Controls.Add(this.appSettingProcedureTypeRbtn);
            this.appSettingGp.Controls.Add(this.appSettingRegTypeRbtn);
            this.appSettingGp.Controls.Add(this.appSettingProcedureTypeTxtbx);
            this.appSettingGp.Controls.Add(this.appSettingDeleteBtn);
            this.appSettingGp.Controls.Add(this.appSettingEditBtn);
            this.appSettingGp.Controls.Add(this.appSettingAddBtn);
            this.appSettingGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.appSettingGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.appSettingGp.Location = new System.Drawing.Point(9, 18);
            this.appSettingGp.Name = "appSettingGp";
            this.appSettingGp.Size = new System.Drawing.Size(859, 299);
            // 
            // 
            // 
            this.appSettingGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.appSettingGp.Style.BackColorGradientAngle = 90;
            this.appSettingGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.appSettingGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingGp.Style.BorderBottomWidth = 2;
            this.appSettingGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.appSettingGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingGp.Style.BorderLeftWidth = 2;
            this.appSettingGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingGp.Style.BorderRightWidth = 2;
            this.appSettingGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.appSettingGp.Style.BorderTopWidth = 2;
            this.appSettingGp.Style.CornerDiameter = 10;
            this.appSettingGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.appSettingGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.appSettingGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.appSettingGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.appSettingGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.appSettingGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.appSettingGp.TabIndex = 2;
            this.appSettingGp.Text = "تغییر مقادیر";
            // 
            // appSettingEdegreeLbl
            // 
            this.appSettingEdegreeLbl.BackColor = System.Drawing.Color.Transparent;
            this.appSettingEdegreeLbl.Location = new System.Drawing.Point(186, 158);
            this.appSettingEdegreeLbl.Name = "appSettingEdegreeLbl";
            this.appSettingEdegreeLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingEdegreeLbl.Size = new System.Drawing.Size(74, 34);
            this.appSettingEdegreeLbl.TabIndex = 23;
            this.appSettingEdegreeLbl.Text = "درجه علمی";
            // 
            // appSettingEdegreeTxtbx
            // 
            this.appSettingEdegreeTxtbx.Enabled = false;
            this.appSettingEdegreeTxtbx.Location = new System.Drawing.Point(38, 195);
            this.appSettingEdegreeTxtbx.Multiline = true;
            this.appSettingEdegreeTxtbx.Name = "appSettingEdegreeTxtbx";
            this.appSettingEdegreeTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingEdegreeTxtbx.Size = new System.Drawing.Size(235, 28);
            this.appSettingEdegreeTxtbx.TabIndex = 22;
            // 
            // appSettingEdegreeRbtn
            // 
            this.appSettingEdegreeRbtn.BackColor = System.Drawing.Color.Transparent;
            this.appSettingEdegreeRbtn.Location = new System.Drawing.Point(266, 152);
            this.appSettingEdegreeRbtn.Name = "appSettingEdegreeRbtn";
            this.appSettingEdegreeRbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingEdegreeRbtn.Size = new System.Drawing.Size(18, 23);
            this.appSettingEdegreeRbtn.TabIndex = 21;
            this.appSettingEdegreeRbtn.TabStop = true;
            this.appSettingEdegreeRbtn.UseVisualStyleBackColor = false;
            this.appSettingEdegreeRbtn.Click += new System.EventHandler(this.appSettingEdegreeRbtn_Click);
            // 
            // appSettingBackBtn
            // 
            this.appSettingBackBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.appSettingBackBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.appSettingBackBtn.Enabled = false;
            this.appSettingBackBtn.Location = new System.Drawing.Point(535, 233);
            this.appSettingBackBtn.Name = "appSettingBackBtn";
            this.appSettingBackBtn.Size = new System.Drawing.Size(123, 24);
            this.appSettingBackBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.appSettingBackBtn.TabIndex = 20;
            this.appSettingBackBtn.Text = "بازگشت";
            this.appSettingBackBtn.Click += new System.EventHandler(this.appSettingBackBtn_Click);
            // 
            // appSettingEgroupLbl
            // 
            this.appSettingEgroupLbl.BackColor = System.Drawing.Color.Transparent;
            this.appSettingEgroupLbl.Location = new System.Drawing.Point(472, 158);
            this.appSettingEgroupLbl.Name = "appSettingEgroupLbl";
            this.appSettingEgroupLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingEgroupLbl.Size = new System.Drawing.Size(74, 34);
            this.appSettingEgroupLbl.TabIndex = 19;
            this.appSettingEgroupLbl.Text = "گروه آموزشی";
            // 
            // appSettingFacultyLbl
            // 
            this.appSettingFacultyLbl.BackColor = System.Drawing.Color.Transparent;
            this.appSettingFacultyLbl.Location = new System.Drawing.Point(754, 155);
            this.appSettingFacultyLbl.Name = "appSettingFacultyLbl";
            this.appSettingFacultyLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingFacultyLbl.Size = new System.Drawing.Size(58, 26);
            this.appSettingFacultyLbl.TabIndex = 18;
            this.appSettingFacultyLbl.Text = "دانشکده";
            this.appSettingFacultyLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingFacultyTxtbx
            // 
            this.appSettingFacultyTxtbx.Enabled = false;
            this.appSettingFacultyTxtbx.Location = new System.Drawing.Point(595, 195);
            this.appSettingFacultyTxtbx.Multiline = true;
            this.appSettingFacultyTxtbx.Name = "appSettingFacultyTxtbx";
            this.appSettingFacultyTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingFacultyTxtbx.Size = new System.Drawing.Size(235, 28);
            this.appSettingFacultyTxtbx.TabIndex = 15;
            this.appSettingFacultyTxtbx.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingEgroupTxtbx
            // 
            this.appSettingEgroupTxtbx.Enabled = false;
            this.appSettingEgroupTxtbx.Location = new System.Drawing.Point(324, 195);
            this.appSettingEgroupTxtbx.Multiline = true;
            this.appSettingEgroupTxtbx.Name = "appSettingEgroupTxtbx";
            this.appSettingEgroupTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingEgroupTxtbx.Size = new System.Drawing.Size(235, 28);
            this.appSettingEgroupTxtbx.TabIndex = 17;
            // 
            // appSettingFacultyRbtn
            // 
            this.appSettingFacultyRbtn.BackColor = System.Drawing.Color.Transparent;
            this.appSettingFacultyRbtn.Location = new System.Drawing.Point(818, 152);
            this.appSettingFacultyRbtn.Name = "appSettingFacultyRbtn";
            this.appSettingFacultyRbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingFacultyRbtn.Size = new System.Drawing.Size(18, 23);
            this.appSettingFacultyRbtn.TabIndex = 14;
            this.appSettingFacultyRbtn.TabStop = true;
            this.appSettingFacultyRbtn.UseVisualStyleBackColor = false;
            this.appSettingFacultyRbtn.Click += new System.EventHandler(this.appSettingFacultyRbtn_Click);
            this.appSettingFacultyRbtn.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingEgroupRbtn
            // 
            this.appSettingEgroupRbtn.BackColor = System.Drawing.Color.Transparent;
            this.appSettingEgroupRbtn.Enabled = false;
            this.appSettingEgroupRbtn.Location = new System.Drawing.Point(552, 152);
            this.appSettingEgroupRbtn.Name = "appSettingEgroupRbtn";
            this.appSettingEgroupRbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingEgroupRbtn.Size = new System.Drawing.Size(18, 23);
            this.appSettingEgroupRbtn.TabIndex = 16;
            this.appSettingEgroupRbtn.TabStop = true;
            this.appSettingEgroupRbtn.UseVisualStyleBackColor = false;
            this.appSettingEgroupRbtn.Click += new System.EventHandler(this.appSettingEgroupRbtn_Click);
            // 
            // appSettingStatusLbl
            // 
            this.appSettingStatusLbl.BackColor = System.Drawing.Color.Transparent;
            this.appSettingStatusLbl.Location = new System.Drawing.Point(218, 78);
            this.appSettingStatusLbl.Name = "appSettingStatusLbl";
            this.appSettingStatusLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingStatusLbl.Size = new System.Drawing.Size(42, 26);
            this.appSettingStatusLbl.TabIndex = 13;
            this.appSettingStatusLbl.Text = "وضعیت";
            // 
            // aapSettingCoLbl
            // 
            this.aapSettingCoLbl.BackColor = System.Drawing.Color.Transparent;
            this.aapSettingCoLbl.Location = new System.Drawing.Point(218, 9);
            this.aapSettingCoLbl.Name = "aapSettingCoLbl";
            this.aapSettingCoLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.aapSettingCoLbl.Size = new System.Drawing.Size(42, 26);
            this.aapSettingCoLbl.TabIndex = 12;
            this.aapSettingCoLbl.Text = "سازمان";
            // 
            // appSettingProTypeLbl
            // 
            this.appSettingProTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.appSettingProTypeLbl.Location = new System.Drawing.Point(472, 81);
            this.appSettingProTypeLbl.Name = "appSettingProTypeLbl";
            this.appSettingProTypeLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingProTypeLbl.Size = new System.Drawing.Size(74, 34);
            this.appSettingProTypeLbl.TabIndex = 11;
            this.appSettingProTypeLbl.Text = "نوع پروپوزال";
            // 
            // appSettingRegTypeLbl
            // 
            this.appSettingRegTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.appSettingRegTypeLbl.Location = new System.Drawing.Point(497, 6);
            this.appSettingRegTypeLbl.Name = "appSettingRegTypeLbl";
            this.appSettingRegTypeLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingRegTypeLbl.Size = new System.Drawing.Size(49, 26);
            this.appSettingRegTypeLbl.TabIndex = 10;
            this.appSettingRegTypeLbl.Text = "نوع ثبت";
            // 
            // appSettingPropertyLbl
            // 
            this.appSettingPropertyLbl.BackColor = System.Drawing.Color.Transparent;
            this.appSettingPropertyLbl.Location = new System.Drawing.Point(770, 81);
            this.appSettingPropertyLbl.Name = "appSettingPropertyLbl";
            this.appSettingPropertyLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingPropertyLbl.Size = new System.Drawing.Size(42, 26);
            this.appSettingPropertyLbl.TabIndex = 9;
            this.appSettingPropertyLbl.Text = "خاصیت";
            this.appSettingPropertyLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingProcedureTypeLbl
            // 
            this.appSettingProcedureTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.appSettingProcedureTypeLbl.Location = new System.Drawing.Point(770, 4);
            this.appSettingProcedureTypeLbl.Name = "appSettingProcedureTypeLbl";
            this.appSettingProcedureTypeLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingProcedureTypeLbl.Size = new System.Drawing.Size(42, 22);
            this.appSettingProcedureTypeLbl.TabIndex = 8;
            this.appSettingProcedureTypeLbl.Text = "نوع کار";
            this.appSettingProcedureTypeLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingStatusTxtbx
            // 
            this.appSettingStatusTxtbx.Enabled = false;
            this.appSettingStatusTxtbx.Location = new System.Drawing.Point(29, 119);
            this.appSettingStatusTxtbx.Multiline = true;
            this.appSettingStatusTxtbx.Name = "appSettingStatusTxtbx";
            this.appSettingStatusTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingStatusTxtbx.Size = new System.Drawing.Size(235, 28);
            this.appSettingStatusTxtbx.TabIndex = 7;
            // 
            // appSettingPropertyTxtbx
            // 
            this.appSettingPropertyTxtbx.Enabled = false;
            this.appSettingPropertyTxtbx.Location = new System.Drawing.Point(595, 119);
            this.appSettingPropertyTxtbx.Multiline = true;
            this.appSettingPropertyTxtbx.Name = "appSettingPropertyTxtbx";
            this.appSettingPropertyTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingPropertyTxtbx.Size = new System.Drawing.Size(235, 28);
            this.appSettingPropertyTxtbx.TabIndex = 3;
            this.appSettingPropertyTxtbx.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingStatusRbtn
            // 
            this.appSettingStatusRbtn.BackColor = System.Drawing.Color.Transparent;
            this.appSettingStatusRbtn.Location = new System.Drawing.Point(266, 76);
            this.appSettingStatusRbtn.Name = "appSettingStatusRbtn";
            this.appSettingStatusRbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingStatusRbtn.Size = new System.Drawing.Size(18, 23);
            this.appSettingStatusRbtn.TabIndex = 5;
            this.appSettingStatusRbtn.TabStop = true;
            this.appSettingStatusRbtn.UseVisualStyleBackColor = false;
            this.appSettingStatusRbtn.Click += new System.EventHandler(this.appSettingStatusRbtn_Click);
            // 
            // appSettingProTypeTxtbx
            // 
            this.appSettingProTypeTxtbx.Enabled = false;
            this.appSettingProTypeTxtbx.Location = new System.Drawing.Point(324, 119);
            this.appSettingProTypeTxtbx.Multiline = true;
            this.appSettingProTypeTxtbx.Name = "appSettingProTypeTxtbx";
            this.appSettingProTypeTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingProTypeTxtbx.Size = new System.Drawing.Size(235, 28);
            this.appSettingProTypeTxtbx.TabIndex = 5;
            // 
            // appSettingPropertyRbtn
            // 
            this.appSettingPropertyRbtn.BackColor = System.Drawing.Color.Transparent;
            this.appSettingPropertyRbtn.Location = new System.Drawing.Point(818, 76);
            this.appSettingPropertyRbtn.Name = "appSettingPropertyRbtn";
            this.appSettingPropertyRbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingPropertyRbtn.Size = new System.Drawing.Size(18, 23);
            this.appSettingPropertyRbtn.TabIndex = 1;
            this.appSettingPropertyRbtn.TabStop = true;
            this.appSettingPropertyRbtn.UseVisualStyleBackColor = false;
            this.appSettingPropertyRbtn.Click += new System.EventHandler(this.appSettingPropertyRbtn_Click);
            this.appSettingPropertyRbtn.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingCoTxtbx
            // 
            this.appSettingCoTxtbx.Enabled = false;
            this.appSettingCoTxtbx.Location = new System.Drawing.Point(29, 43);
            this.appSettingCoTxtbx.Multiline = true;
            this.appSettingCoTxtbx.Name = "appSettingCoTxtbx";
            this.appSettingCoTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingCoTxtbx.Size = new System.Drawing.Size(235, 28);
            this.appSettingCoTxtbx.TabIndex = 6;
            // 
            // appSettingProTypeRbtn
            // 
            this.appSettingProTypeRbtn.BackColor = System.Drawing.Color.Transparent;
            this.appSettingProTypeRbtn.Location = new System.Drawing.Point(552, 76);
            this.appSettingProTypeRbtn.Name = "appSettingProTypeRbtn";
            this.appSettingProTypeRbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingProTypeRbtn.Size = new System.Drawing.Size(18, 23);
            this.appSettingProTypeRbtn.TabIndex = 3;
            this.appSettingProTypeRbtn.TabStop = true;
            this.appSettingProTypeRbtn.UseVisualStyleBackColor = false;
            this.appSettingProTypeRbtn.Click += new System.EventHandler(this.appSettingProTypeRbtn_Click);
            // 
            // appSettingRegTypeTxtbx
            // 
            this.appSettingRegTypeTxtbx.Enabled = false;
            this.appSettingRegTypeTxtbx.Location = new System.Drawing.Point(324, 43);
            this.appSettingRegTypeTxtbx.Multiline = true;
            this.appSettingRegTypeTxtbx.Name = "appSettingRegTypeTxtbx";
            this.appSettingRegTypeTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingRegTypeTxtbx.Size = new System.Drawing.Size(235, 28);
            this.appSettingRegTypeTxtbx.TabIndex = 4;
            // 
            // appSettingCoRbtn
            // 
            this.appSettingCoRbtn.BackColor = System.Drawing.Color.Transparent;
            this.appSettingCoRbtn.Location = new System.Drawing.Point(266, 3);
            this.appSettingCoRbtn.Name = "appSettingCoRbtn";
            this.appSettingCoRbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingCoRbtn.Size = new System.Drawing.Size(18, 23);
            this.appSettingCoRbtn.TabIndex = 4;
            this.appSettingCoRbtn.TabStop = true;
            this.appSettingCoRbtn.UseVisualStyleBackColor = false;
            this.appSettingCoRbtn.Click += new System.EventHandler(this.appSettingCoRbtn_Click);
            // 
            // appSettingProcedureTypeRbtn
            // 
            this.appSettingProcedureTypeRbtn.BackColor = System.Drawing.Color.Transparent;
            this.appSettingProcedureTypeRbtn.Location = new System.Drawing.Point(818, 3);
            this.appSettingProcedureTypeRbtn.Name = "appSettingProcedureTypeRbtn";
            this.appSettingProcedureTypeRbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingProcedureTypeRbtn.Size = new System.Drawing.Size(18, 23);
            this.appSettingProcedureTypeRbtn.TabIndex = 0;
            this.appSettingProcedureTypeRbtn.TabStop = true;
            this.appSettingProcedureTypeRbtn.UseVisualStyleBackColor = false;
            this.appSettingProcedureTypeRbtn.Click += new System.EventHandler(this.appSettingProcedureTypeRbtn_Click);
            this.appSettingProcedureTypeRbtn.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingRegTypeRbtn
            // 
            this.appSettingRegTypeRbtn.BackColor = System.Drawing.Color.Transparent;
            this.appSettingRegTypeRbtn.Location = new System.Drawing.Point(552, 3);
            this.appSettingRegTypeRbtn.Name = "appSettingRegTypeRbtn";
            this.appSettingRegTypeRbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingRegTypeRbtn.Size = new System.Drawing.Size(18, 23);
            this.appSettingRegTypeRbtn.TabIndex = 2;
            this.appSettingRegTypeRbtn.TabStop = true;
            this.appSettingRegTypeRbtn.UseVisualStyleBackColor = false;
            this.appSettingRegTypeRbtn.Click += new System.EventHandler(this.appSettingRegTypeRbtn_Click);
            // 
            // appSettingProcedureTypeTxtbx
            // 
            this.appSettingProcedureTypeTxtbx.Enabled = false;
            this.appSettingProcedureTypeTxtbx.Location = new System.Drawing.Point(595, 43);
            this.appSettingProcedureTypeTxtbx.Multiline = true;
            this.appSettingProcedureTypeTxtbx.Name = "appSettingProcedureTypeTxtbx";
            this.appSettingProcedureTypeTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.appSettingProcedureTypeTxtbx.Size = new System.Drawing.Size(235, 28);
            this.appSettingProcedureTypeTxtbx.TabIndex = 1;
            this.appSettingProcedureTypeTxtbx.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // appSettingDeleteBtn
            // 
            this.appSettingDeleteBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.appSettingDeleteBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.appSettingDeleteBtn.Enabled = false;
            this.appSettingDeleteBtn.Location = new System.Drawing.Point(385, 233);
            this.appSettingDeleteBtn.Name = "appSettingDeleteBtn";
            this.appSettingDeleteBtn.Size = new System.Drawing.Size(123, 24);
            this.appSettingDeleteBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.appSettingDeleteBtn.TabIndex = 4;
            this.appSettingDeleteBtn.Text = "حذف";
            this.appSettingDeleteBtn.Click += new System.EventHandler(this.appSettingDeleteBtn_Click);
            // 
            // appSettingEditBtn
            // 
            this.appSettingEditBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.appSettingEditBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.appSettingEditBtn.Enabled = false;
            this.appSettingEditBtn.Location = new System.Drawing.Point(199, 233);
            this.appSettingEditBtn.Name = "appSettingEditBtn";
            this.appSettingEditBtn.Size = new System.Drawing.Size(142, 24);
            this.appSettingEditBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.appSettingEditBtn.TabIndex = 3;
            this.appSettingEditBtn.Text = "ثبت تغییرات";
            this.appSettingEditBtn.Click += new System.EventHandler(this.appSettingEditBtn_Click);
            // 
            // appSettingAddBtn
            // 
            this.appSettingAddBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.appSettingAddBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.appSettingAddBtn.Enabled = false;
            this.appSettingAddBtn.Location = new System.Drawing.Point(32, 232);
            this.appSettingAddBtn.Name = "appSettingAddBtn";
            this.appSettingAddBtn.Size = new System.Drawing.Size(135, 24);
            this.appSettingAddBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.appSettingAddBtn.TabIndex = 2;
            this.appSettingAddBtn.Text = "افزودن";
            this.appSettingAddBtn.Click += new System.EventHandler(this.appSettingAddBtn_Click);
            // 
            // appSettingsTab
            // 
            this.appSettingsTab.AttachedControl = this.superTabControlPanel6;
            this.appSettingsTab.GlobalItem = false;
            this.appSettingsTab.Image = global::ProposalReportingSystem.Properties.Resources.settings;
            this.appSettingsTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.appSettingsTab.Name = "appSettingsTab";
            this.appSettingsTab.Text = "تنظیمات برنامه";
            // 
            // superTabControlPanel4
            // 
            this.superTabControlPanel4.Controls.Add(this.manageUserPanel);
            this.superTabControlPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel4.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel4.Name = "superTabControlPanel4";
            this.superTabControlPanel4.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel4.TabIndex = 0;
            this.superTabControlPanel4.TabItem = this.manageUserTab;
            // 
            // manageUserPanel
            // 
            this.manageUserPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.manageUserPanel.Controls.Add(this.manageUserManageGp);
            this.manageUserPanel.Controls.Add(this.manageUserShowGp);
            this.manageUserPanel.Location = new System.Drawing.Point(3, 3);
            this.manageUserPanel.Name = "manageUserPanel";
            this.manageUserPanel.Size = new System.Drawing.Size(887, 660);
            this.manageUserPanel.TabIndex = 1002;
            this.manageUserPanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageUserManageGp
            // 
            this.manageUserManageGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.manageUserManageGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.manageUserManageGp.Controls.Add(this.menageUserAccessLevelGp);
            this.manageUserManageGp.Controls.Add(this.manageUserPersonalInfoGp);
            this.manageUserManageGp.Controls.Add(this.manageUserShowAllBtn);
            this.manageUserManageGp.Controls.Add(this.manageUserClearBtn);
            this.manageUserManageGp.Controls.Add(this.manageUserDeleteBtn);
            this.manageUserManageGp.Controls.Add(this.manageUserEditBtn);
            this.manageUserManageGp.Controls.Add(this.manageUserAddBtn);
            this.manageUserManageGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.manageUserManageGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserManageGp.Location = new System.Drawing.Point(10, 8);
            this.manageUserManageGp.Name = "manageUserManageGp";
            this.manageUserManageGp.Size = new System.Drawing.Size(861, 302);
            // 
            // 
            // 
            this.manageUserManageGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.manageUserManageGp.Style.BackColorGradientAngle = 90;
            this.manageUserManageGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.manageUserManageGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserManageGp.Style.BorderBottomWidth = 2;
            this.manageUserManageGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.manageUserManageGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserManageGp.Style.BorderLeftWidth = 2;
            this.manageUserManageGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserManageGp.Style.BorderRightWidth = 2;
            this.manageUserManageGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserManageGp.Style.BorderTopWidth = 2;
            this.manageUserManageGp.Style.CornerDiameter = 10;
            this.manageUserManageGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.manageUserManageGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.manageUserManageGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.manageUserManageGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.manageUserManageGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.manageUserManageGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.manageUserManageGp.TabIndex = 1001;
            this.manageUserManageGp.Text = "اطلاعات کاربر";
            this.manageUserManageGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // menageUserAccessLevelGp
            // 
            this.menageUserAccessLevelGp.BackColor = System.Drawing.Color.Transparent;
            this.menageUserAccessLevelGp.CanvasColor = System.Drawing.Color.Transparent;
            this.menageUserAccessLevelGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.menageUserAccessLevelGp.Controls.Add(this.manageUserManageTypeCb);
            this.menageUserAccessLevelGp.Controls.Add(this.manageUserManageTeacherCb);
            this.menageUserAccessLevelGp.Controls.Add(this.manageUserDeleteUserCb);
            this.menageUserAccessLevelGp.Controls.Add(this.manageUserEditUserCb);
            this.menageUserAccessLevelGp.Controls.Add(this.manageUserAddUserCb);
            this.menageUserAccessLevelGp.Controls.Add(this.manageUserDeleteProCb);
            this.menageUserAccessLevelGp.Controls.Add(this.manageUserEditProCb);
            this.menageUserAccessLevelGp.Controls.Add(this.manageUserAddProCb);
            this.menageUserAccessLevelGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.menageUserAccessLevelGp.Font = new System.Drawing.Font("B Yekan+", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menageUserAccessLevelGp.Location = new System.Drawing.Point(49, 10);
            this.menageUserAccessLevelGp.Name = "menageUserAccessLevelGp";
            this.menageUserAccessLevelGp.Size = new System.Drawing.Size(416, 203);
            // 
            // 
            // 
            this.menageUserAccessLevelGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.menageUserAccessLevelGp.Style.BackColorGradientAngle = 90;
            this.menageUserAccessLevelGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.menageUserAccessLevelGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.menageUserAccessLevelGp.Style.BorderBottomWidth = 2;
            this.menageUserAccessLevelGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.menageUserAccessLevelGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.menageUserAccessLevelGp.Style.BorderLeftWidth = 2;
            this.menageUserAccessLevelGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.menageUserAccessLevelGp.Style.BorderRightWidth = 2;
            this.menageUserAccessLevelGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.menageUserAccessLevelGp.Style.BorderTopWidth = 2;
            this.menageUserAccessLevelGp.Style.CornerDiameter = 10;
            this.menageUserAccessLevelGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.menageUserAccessLevelGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.menageUserAccessLevelGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.menageUserAccessLevelGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.menageUserAccessLevelGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.menageUserAccessLevelGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.menageUserAccessLevelGp.TabIndex = 1004;
            this.menageUserAccessLevelGp.Text = "سطح دسترسی";
            // 
            // manageUserManageTypeCb
            // 
            this.manageUserManageTypeCb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserManageTypeCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserManageTypeCb.Location = new System.Drawing.Point(12, 145);
            this.manageUserManageTypeCb.Name = "manageUserManageTypeCb";
            this.manageUserManageTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserManageTypeCb.Size = new System.Drawing.Size(145, 27);
            this.manageUserManageTypeCb.TabIndex = 14;
            this.manageUserManageTypeCb.Text = "تغییر تنظیمات برنامه";
            this.manageUserManageTypeCb.UseVisualStyleBackColor = false;
            // 
            // manageUserManageTeacherCb
            // 
            this.manageUserManageTeacherCb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserManageTeacherCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserManageTeacherCb.Location = new System.Drawing.Point(223, 145);
            this.manageUserManageTeacherCb.Name = "manageUserManageTeacherCb";
            this.manageUserManageTeacherCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserManageTeacherCb.Size = new System.Drawing.Size(145, 27);
            this.manageUserManageTeacherCb.TabIndex = 10;
            this.manageUserManageTeacherCb.Text = "مدیریت اطلاعات اساتید";
            this.manageUserManageTeacherCb.UseVisualStyleBackColor = false;
            // 
            // manageUserDeleteUserCb
            // 
            this.manageUserDeleteUserCb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserDeleteUserCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserDeleteUserCb.Location = new System.Drawing.Point(12, 106);
            this.manageUserDeleteUserCb.Name = "manageUserDeleteUserCb";
            this.manageUserDeleteUserCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserDeleteUserCb.Size = new System.Drawing.Size(145, 27);
            this.manageUserDeleteUserCb.TabIndex = 13;
            this.manageUserDeleteUserCb.Text = "حذف کاربر";
            this.manageUserDeleteUserCb.UseVisualStyleBackColor = false;
            // 
            // manageUserEditUserCb
            // 
            this.manageUserEditUserCb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserEditUserCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserEditUserCb.Location = new System.Drawing.Point(12, 57);
            this.manageUserEditUserCb.Name = "manageUserEditUserCb";
            this.manageUserEditUserCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserEditUserCb.Size = new System.Drawing.Size(145, 27);
            this.manageUserEditUserCb.TabIndex = 12;
            this.manageUserEditUserCb.Text = "تغییر اطلاعات کاربر";
            this.manageUserEditUserCb.UseVisualStyleBackColor = false;
            // 
            // manageUserAddUserCb
            // 
            this.manageUserAddUserCb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserAddUserCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserAddUserCb.Location = new System.Drawing.Point(12, 7);
            this.manageUserAddUserCb.Name = "manageUserAddUserCb";
            this.manageUserAddUserCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserAddUserCb.Size = new System.Drawing.Size(145, 27);
            this.manageUserAddUserCb.TabIndex = 11;
            this.manageUserAddUserCb.Text = "افزودن کاربر";
            this.manageUserAddUserCb.UseVisualStyleBackColor = false;
            // 
            // manageUserDeleteProCb
            // 
            this.manageUserDeleteProCb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserDeleteProCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserDeleteProCb.Location = new System.Drawing.Point(223, 106);
            this.manageUserDeleteProCb.Name = "manageUserDeleteProCb";
            this.manageUserDeleteProCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserDeleteProCb.Size = new System.Drawing.Size(145, 27);
            this.manageUserDeleteProCb.TabIndex = 9;
            this.manageUserDeleteProCb.Text = "حذف پروپوزال";
            this.manageUserDeleteProCb.UseVisualStyleBackColor = false;
            // 
            // manageUserEditProCb
            // 
            this.manageUserEditProCb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserEditProCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserEditProCb.Location = new System.Drawing.Point(224, 55);
            this.manageUserEditProCb.Name = "manageUserEditProCb";
            this.manageUserEditProCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserEditProCb.Size = new System.Drawing.Size(145, 27);
            this.manageUserEditProCb.TabIndex = 8;
            this.manageUserEditProCb.Text = "تغییر اطلاعات پروپوزال";
            this.manageUserEditProCb.UseVisualStyleBackColor = false;
            // 
            // manageUserAddProCb
            // 
            this.manageUserAddProCb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserAddProCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserAddProCb.Location = new System.Drawing.Point(200, 3);
            this.manageUserAddProCb.Name = "manageUserAddProCb";
            this.manageUserAddProCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserAddProCb.Size = new System.Drawing.Size(169, 34);
            this.manageUserAddProCb.TabIndex = 7;
            this.manageUserAddProCb.Text = "افزودن پروپوزال";
            this.manageUserAddProCb.UseVisualStyleBackColor = false;
            // 
            // manageUserPersonalInfoGp
            // 
            this.manageUserPersonalInfoGp.BackColor = System.Drawing.Color.Transparent;
            this.manageUserPersonalInfoGp.CanvasColor = System.Drawing.Color.Transparent;
            this.manageUserPersonalInfoGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserShowPasswordChb);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserTellLb);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserEmailLb);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserPasswordLb);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserNcodLb);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserLnameLb);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserFnameLb);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserTelTxtbx);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserEmailTxtbx);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserPasswordTxtbx);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserNcodeTxtbx);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserLnameTxtbx);
            this.manageUserPersonalInfoGp.Controls.Add(this.manageUserFnameTxtbx);
            this.manageUserPersonalInfoGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.manageUserPersonalInfoGp.Location = new System.Drawing.Point(494, 3);
            this.manageUserPersonalInfoGp.Name = "manageUserPersonalInfoGp";
            this.manageUserPersonalInfoGp.Size = new System.Drawing.Size(348, 225);
            // 
            // 
            // 
            this.manageUserPersonalInfoGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.manageUserPersonalInfoGp.Style.BackColorGradientAngle = 90;
            this.manageUserPersonalInfoGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.manageUserPersonalInfoGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserPersonalInfoGp.Style.BorderBottomWidth = 2;
            this.manageUserPersonalInfoGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.manageUserPersonalInfoGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserPersonalInfoGp.Style.BorderLeftWidth = 2;
            this.manageUserPersonalInfoGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserPersonalInfoGp.Style.BorderRightWidth = 2;
            this.manageUserPersonalInfoGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserPersonalInfoGp.Style.BorderTopWidth = 2;
            this.manageUserPersonalInfoGp.Style.CornerDiameter = 10;
            this.manageUserPersonalInfoGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.manageUserPersonalInfoGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.manageUserPersonalInfoGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.manageUserPersonalInfoGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.manageUserPersonalInfoGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.manageUserPersonalInfoGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.manageUserPersonalInfoGp.TabIndex = 1000;
            this.manageUserPersonalInfoGp.Text = "مشخصات کاربر";
            // 
            // manageUserShowPasswordChb
            // 
            this.manageUserShowPasswordChb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserShowPasswordChb.Location = new System.Drawing.Point(208, 89);
            this.manageUserShowPasswordChb.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserShowPasswordChb.Name = "manageUserShowPasswordChb";
            this.manageUserShowPasswordChb.Size = new System.Drawing.Size(22, 24);
            this.manageUserShowPasswordChb.TabIndex = 2000;
            this.manageUserShowPasswordChb.TabStop = false;
            this.manageUserShowPasswordChb.UseVisualStyleBackColor = false;
            this.manageUserShowPasswordChb.MouseDown += new System.Windows.Forms.MouseEventHandler(this.manageUserShowPasswordChb_MouseDown);
            this.manageUserShowPasswordChb.MouseUp += new System.Windows.Forms.MouseEventHandler(this.manageUserShowPasswordChb_MouseUp);
            // 
            // manageUserTellLb
            // 
            this.manageUserTellLb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserTellLb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserTellLb.Location = new System.Drawing.Point(220, 137);
            this.manageUserTellLb.Name = "manageUserTellLb";
            this.manageUserTellLb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserTellLb.Size = new System.Drawing.Size(89, 27);
            this.manageUserTellLb.TabIndex = 25;
            this.manageUserTellLb.Text = "تلفن";
            this.manageUserTellLb.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageUserEmailLb
            // 
            this.manageUserEmailLb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserEmailLb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserEmailLb.Location = new System.Drawing.Point(220, 111);
            this.manageUserEmailLb.Name = "manageUserEmailLb";
            this.manageUserEmailLb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserEmailLb.Size = new System.Drawing.Size(89, 26);
            this.manageUserEmailLb.TabIndex = 24;
            this.manageUserEmailLb.Text = "ایمیل";
            this.manageUserEmailLb.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageUserPasswordLb
            // 
            this.manageUserPasswordLb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserPasswordLb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserPasswordLb.Location = new System.Drawing.Point(220, 85);
            this.manageUserPasswordLb.Name = "manageUserPasswordLb";
            this.manageUserPasswordLb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserPasswordLb.Size = new System.Drawing.Size(89, 25);
            this.manageUserPasswordLb.TabIndex = 23;
            this.manageUserPasswordLb.Text = "گذرواژه*";
            this.manageUserPasswordLb.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageUserNcodLb
            // 
            this.manageUserNcodLb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserNcodLb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserNcodLb.Location = new System.Drawing.Point(217, 59);
            this.manageUserNcodLb.Name = "manageUserNcodLb";
            this.manageUserNcodLb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserNcodLb.Size = new System.Drawing.Size(93, 26);
            this.manageUserNcodLb.TabIndex = 22;
            this.manageUserNcodLb.Text = "کد ملی*";
            this.manageUserNcodLb.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageUserLnameLb
            // 
            this.manageUserLnameLb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserLnameLb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserLnameLb.Location = new System.Drawing.Point(230, 33);
            this.manageUserLnameLb.Name = "manageUserLnameLb";
            this.manageUserLnameLb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserLnameLb.Size = new System.Drawing.Size(79, 26);
            this.manageUserLnameLb.TabIndex = 21;
            this.manageUserLnameLb.Text = "نام خانوادگی*";
            this.manageUserLnameLb.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageUserFnameLb
            // 
            this.manageUserFnameLb.BackColor = System.Drawing.Color.Transparent;
            this.manageUserFnameLb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserFnameLb.Location = new System.Drawing.Point(254, 11);
            this.manageUserFnameLb.Name = "manageUserFnameLb";
            this.manageUserFnameLb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserFnameLb.Size = new System.Drawing.Size(54, 23);
            this.manageUserFnameLb.TabIndex = 20;
            this.manageUserFnameLb.Text = "نام*";
            this.manageUserFnameLb.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageUserTelTxtbx
            // 
            this.manageUserTelTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageUserTelTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserTelTxtbx.Location = new System.Drawing.Point(22, 144);
            this.manageUserTelTxtbx.MaxLength = 20;
            this.manageUserTelTxtbx.Multiline = true;
            this.manageUserTelTxtbx.Name = "manageUserTelTxtbx";
            this.manageUserTelTxtbx.Size = new System.Drawing.Size(181, 21);
            this.manageUserTelTxtbx.TabIndex = 6;
            this.manageUserTelTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.manageUserNcodTxtbx_KeyPress);
            // 
            // manageUserEmailTxtbx
            // 
            this.manageUserEmailTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageUserEmailTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserEmailTxtbx.Location = new System.Drawing.Point(22, 118);
            this.manageUserEmailTxtbx.Multiline = true;
            this.manageUserEmailTxtbx.Name = "manageUserEmailTxtbx";
            this.manageUserEmailTxtbx.Size = new System.Drawing.Size(181, 21);
            this.manageUserEmailTxtbx.TabIndex = 5;
            this.manageUserEmailTxtbx.TextChanged += new System.EventHandler(this.manageUserEmailTxtbx_TextChanged);
            this.manageUserEmailTxtbx.Leave += new System.EventHandler(this.manageUserEmailTxtbx_Leave);
            // 
            // manageUserPasswordTxtbx
            // 
            this.manageUserPasswordTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageUserPasswordTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserPasswordTxtbx.Location = new System.Drawing.Point(22, 92);
            this.manageUserPasswordTxtbx.MaxLength = 12;
            this.manageUserPasswordTxtbx.Multiline = true;
            this.manageUserPasswordTxtbx.Name = "manageUserPasswordTxtbx";
            this.manageUserPasswordTxtbx.PasswordChar = '●';
            this.manageUserPasswordTxtbx.Size = new System.Drawing.Size(181, 21);
            this.manageUserPasswordTxtbx.TabIndex = 4;
            // 
            // manageUserNcodeTxtbx
            // 
            this.manageUserNcodeTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageUserNcodeTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserNcodeTxtbx.Location = new System.Drawing.Point(22, 66);
            this.manageUserNcodeTxtbx.MaxLength = 10;
            this.manageUserNcodeTxtbx.Multiline = true;
            this.manageUserNcodeTxtbx.Name = "manageUserNcodeTxtbx";
            this.manageUserNcodeTxtbx.Size = new System.Drawing.Size(181, 21);
            this.manageUserNcodeTxtbx.TabIndex = 1;
            this.manageUserNcodeTxtbx.TextChanged += new System.EventHandler(this.manageUserNcodTxtbx_TextChanged);
            this.manageUserNcodeTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.manageUserNcodTxtbx_KeyPress);
            this.manageUserNcodeTxtbx.Leave += new System.EventHandler(this.manageUserNcodTxtbx_Leave);
            // 
            // manageUserLnameTxtbx
            // 
            this.manageUserLnameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageUserLnameTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserLnameTxtbx.Location = new System.Drawing.Point(22, 40);
            this.manageUserLnameTxtbx.MaxLength = 100;
            this.manageUserLnameTxtbx.Multiline = true;
            this.manageUserLnameTxtbx.Name = "manageUserLnameTxtbx";
            this.manageUserLnameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserLnameTxtbx.Size = new System.Drawing.Size(181, 21);
            this.manageUserLnameTxtbx.TabIndex = 3;
            // 
            // manageUserFnameTxtbx
            // 
            this.manageUserFnameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageUserFnameTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserFnameTxtbx.Location = new System.Drawing.Point(22, 14);
            this.manageUserFnameTxtbx.MaxLength = 100;
            this.manageUserFnameTxtbx.Multiline = true;
            this.manageUserFnameTxtbx.Name = "manageUserFnameTxtbx";
            this.manageUserFnameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserFnameTxtbx.Size = new System.Drawing.Size(181, 21);
            this.manageUserFnameTxtbx.TabIndex = 2;
            // 
            // manageUserShowAllBtn
            // 
            this.manageUserShowAllBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserShowAllBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserShowAllBtn.Location = new System.Drawing.Point(495, 232);
            this.manageUserShowAllBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserShowAllBtn.Name = "manageUserShowAllBtn";
            this.manageUserShowAllBtn.Size = new System.Drawing.Size(81, 31);
            this.manageUserShowAllBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserShowAllBtn.TabIndex = 19;
            this.manageUserShowAllBtn.Text = "نمایش همه";
            this.manageUserShowAllBtn.Click += new System.EventHandler(this.manageUserShowBtn_Click);
            // 
            // manageUserClearBtn
            // 
            this.manageUserClearBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserClearBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserClearBtn.Location = new System.Drawing.Point(246, 232);
            this.manageUserClearBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserClearBtn.Name = "manageUserClearBtn";
            this.manageUserClearBtn.Size = new System.Drawing.Size(81, 31);
            this.manageUserClearBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserClearBtn.TabIndex = 18;
            this.manageUserClearBtn.Text = "پاک کردن";
            this.manageUserClearBtn.Click += new System.EventHandler(this.manageUserClearBtn_Click);
            // 
            // manageUserDeleteBtn
            // 
            this.manageUserDeleteBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserDeleteBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserDeleteBtn.Enabled = false;
            this.manageUserDeleteBtn.Location = new System.Drawing.Point(340, 232);
            this.manageUserDeleteBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserDeleteBtn.Name = "manageUserDeleteBtn";
            this.manageUserDeleteBtn.Size = new System.Drawing.Size(81, 31);
            this.manageUserDeleteBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserDeleteBtn.TabIndex = 17;
            this.manageUserDeleteBtn.Text = "حذف کردن";
            this.manageUserDeleteBtn.Click += new System.EventHandler(this.manageUserDeleteBtn_Click);
            // 
            // manageUserEditBtn
            // 
            this.manageUserEditBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserEditBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserEditBtn.Enabled = false;
            this.manageUserEditBtn.Location = new System.Drawing.Point(49, 232);
            this.manageUserEditBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserEditBtn.Name = "manageUserEditBtn";
            this.manageUserEditBtn.Size = new System.Drawing.Size(81, 31);
            this.manageUserEditBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserEditBtn.TabIndex = 16;
            this.manageUserEditBtn.Text = "ثبت تغییرات";
            this.manageUserEditBtn.Click += new System.EventHandler(this.manageUserEditBtn_Click);
            // 
            // manageUserAddBtn
            // 
            this.manageUserAddBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserAddBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserAddBtn.Location = new System.Drawing.Point(148, 232);
            this.manageUserAddBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserAddBtn.Name = "manageUserAddBtn";
            this.manageUserAddBtn.Size = new System.Drawing.Size(81, 31);
            this.manageUserAddBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserAddBtn.TabIndex = 15;
            this.manageUserAddBtn.Text = "افزودن اطلاعات";
            this.manageUserAddBtn.Click += new System.EventHandler(this.manageUserAddBtn_Click);
            // 
            // manageUserShowGp
            // 
            this.manageUserShowGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.manageUserShowGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.manageUserShowGp.Controls.Add(this.manageUserNavigationPanel);
            this.manageUserShowGp.Controls.Add(this.manageUserShowDgv);
            this.manageUserShowGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.manageUserShowGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserShowGp.Location = new System.Drawing.Point(10, 317);
            this.manageUserShowGp.Name = "manageUserShowGp";
            this.manageUserShowGp.Size = new System.Drawing.Size(861, 316);
            // 
            // 
            // 
            this.manageUserShowGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.manageUserShowGp.Style.BackColorGradientAngle = 90;
            this.manageUserShowGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.manageUserShowGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserShowGp.Style.BorderBottomWidth = 2;
            this.manageUserShowGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.manageUserShowGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserShowGp.Style.BorderLeftWidth = 2;
            this.manageUserShowGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserShowGp.Style.BorderRightWidth = 2;
            this.manageUserShowGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageUserShowGp.Style.BorderTopWidth = 2;
            this.manageUserShowGp.Style.CornerDiameter = 10;
            this.manageUserShowGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.manageUserShowGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.manageUserShowGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.manageUserShowGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.manageUserShowGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.manageUserShowGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.manageUserShowGp.TabIndex = 0;
            this.manageUserShowGp.Text = "فهرست کاربران";
            this.manageUserShowGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageUserNavigationPanel
            // 
            this.manageUserNavigationPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.manageUserNavigationPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.manageUserNavigationPanel.Controls.Add(this.manageUserNavigationCurrentPageTxtbx);
            this.manageUserNavigationPanel.Controls.Add(this.manageUserNavigationNextPageBtn);
            this.manageUserNavigationPanel.Controls.Add(this.manageUserNavigationLastPageBtn);
            this.manageUserNavigationPanel.Controls.Add(this.manageUserNavigationPreviousPageBtn);
            this.manageUserNavigationPanel.Controls.Add(this.manageUserNavigationFirstPageBtn);
            this.manageUserNavigationPanel.Controls.Add(this.manageUserNavigationReturnBtn);
            this.manageUserNavigationPanel.Location = new System.Drawing.Point(114, 115);
            this.manageUserNavigationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserNavigationPanel.Name = "manageUserNavigationPanel";
            this.manageUserNavigationPanel.Size = new System.Drawing.Size(615, 33);
            this.manageUserNavigationPanel.TabIndex = 4;
            // 
            // manageUserNavigationCurrentPageTxtbx
            // 
            // 
            // 
            // 
            this.manageUserNavigationCurrentPageTxtbx.Border.Class = "TextBoxBorder";
            this.manageUserNavigationCurrentPageTxtbx.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.manageUserNavigationCurrentPageTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserNavigationCurrentPageTxtbx.Location = new System.Drawing.Point(271, 3);
            this.manageUserNavigationCurrentPageTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserNavigationCurrentPageTxtbx.MaxLength = 5;
            this.manageUserNavigationCurrentPageTxtbx.Multiline = true;
            this.manageUserNavigationCurrentPageTxtbx.Name = "manageUserNavigationCurrentPageTxtbx";
            this.manageUserNavigationCurrentPageTxtbx.PreventEnterBeep = true;
            this.manageUserNavigationCurrentPageTxtbx.Size = new System.Drawing.Size(74, 24);
            this.manageUserNavigationCurrentPageTxtbx.TabIndex = 34;
            this.manageUserNavigationCurrentPageTxtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // manageUserNavigationNextPageBtn
            // 
            this.manageUserNavigationNextPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserNavigationNextPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserNavigationNextPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserNavigationNextPageBtn.Location = new System.Drawing.Point(349, 3);
            this.manageUserNavigationNextPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserNavigationNextPageBtn.Name = "manageUserNavigationNextPageBtn";
            this.manageUserNavigationNextPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageUserNavigationNextPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserNavigationNextPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem26});
            this.manageUserNavigationNextPageBtn.SubItemsExpandWidth = 0;
            this.manageUserNavigationNextPageBtn.TabIndex = 33;
            this.manageUserNavigationNextPageBtn.Text = "صفحه بعد";
            // 
            // superTabItem26
            // 
            this.superTabItem26.GlobalItem = false;
            this.superTabItem26.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem26.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem26.Name = "superTabItem26";
            this.superTabItem26.Text = "لاگ";
            // 
            // manageUserNavigationLastPageBtn
            // 
            this.manageUserNavigationLastPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserNavigationLastPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserNavigationLastPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserNavigationLastPageBtn.Location = new System.Drawing.Point(436, 3);
            this.manageUserNavigationLastPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserNavigationLastPageBtn.Name = "manageUserNavigationLastPageBtn";
            this.manageUserNavigationLastPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageUserNavigationLastPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserNavigationLastPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem27});
            this.manageUserNavigationLastPageBtn.SubItemsExpandWidth = 0;
            this.manageUserNavigationLastPageBtn.TabIndex = 32;
            this.manageUserNavigationLastPageBtn.Text = "صفحه آخر";
            // 
            // superTabItem27
            // 
            this.superTabItem27.GlobalItem = false;
            this.superTabItem27.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem27.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem27.Name = "superTabItem27";
            this.superTabItem27.Text = "لاگ";
            // 
            // manageUserNavigationPreviousPageBtn
            // 
            this.manageUserNavigationPreviousPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserNavigationPreviousPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserNavigationPreviousPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserNavigationPreviousPageBtn.Location = new System.Drawing.Point(184, 3);
            this.manageUserNavigationPreviousPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserNavigationPreviousPageBtn.Name = "manageUserNavigationPreviousPageBtn";
            this.manageUserNavigationPreviousPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageUserNavigationPreviousPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserNavigationPreviousPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem29});
            this.manageUserNavigationPreviousPageBtn.SubItemsExpandWidth = 0;
            this.manageUserNavigationPreviousPageBtn.TabIndex = 30;
            this.manageUserNavigationPreviousPageBtn.Text = "صفحه قبل";
            // 
            // superTabItem29
            // 
            this.superTabItem29.GlobalItem = false;
            this.superTabItem29.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem29.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem29.Name = "superTabItem29";
            this.superTabItem29.Text = "لاگ";
            // 
            // manageUserNavigationFirstPageBtn
            // 
            this.manageUserNavigationFirstPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserNavigationFirstPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserNavigationFirstPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserNavigationFirstPageBtn.Location = new System.Drawing.Point(97, 3);
            this.manageUserNavigationFirstPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserNavigationFirstPageBtn.Name = "manageUserNavigationFirstPageBtn";
            this.manageUserNavigationFirstPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageUserNavigationFirstPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserNavigationFirstPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem30});
            this.manageUserNavigationFirstPageBtn.SubItemsExpandWidth = 0;
            this.manageUserNavigationFirstPageBtn.TabIndex = 29;
            this.manageUserNavigationFirstPageBtn.Text = "صفحه اول";
            // 
            // superTabItem30
            // 
            this.superTabItem30.GlobalItem = false;
            this.superTabItem30.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem30.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem30.Name = "superTabItem30";
            this.superTabItem30.Text = "لاگ";
            // 
            // manageUserNavigationReturnBtn
            // 
            this.manageUserNavigationReturnBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageUserNavigationReturnBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageUserNavigationReturnBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageUserNavigationReturnBtn.Location = new System.Drawing.Point(10, 3);
            this.manageUserNavigationReturnBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserNavigationReturnBtn.Name = "manageUserNavigationReturnBtn";
            this.manageUserNavigationReturnBtn.Size = new System.Drawing.Size(82, 24);
            this.manageUserNavigationReturnBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageUserNavigationReturnBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem31});
            this.manageUserNavigationReturnBtn.SubItemsExpandWidth = 0;
            this.manageUserNavigationReturnBtn.TabIndex = 28;
            this.manageUserNavigationReturnBtn.Text = "بازگشت";
            // 
            // superTabItem31
            // 
            this.superTabItem31.GlobalItem = false;
            this.superTabItem31.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem31.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem31.Name = "superTabItem31";
            this.superTabItem31.Text = "لاگ";
            // 
            // manageUserShowDgv
            // 
            this.manageUserShowDgv.AllowUserToAddRows = false;
            this.manageUserShowDgv.AllowUserToDeleteRows = false;
            this.manageUserShowDgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.manageUserShowDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.manageUserShowDgv.Location = new System.Drawing.Point(17, 2);
            this.manageUserShowDgv.Margin = new System.Windows.Forms.Padding(2);
            this.manageUserShowDgv.MultiSelect = false;
            this.manageUserShowDgv.Name = "manageUserShowDgv";
            this.manageUserShowDgv.ReadOnly = true;
            this.manageUserShowDgv.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageUserShowDgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.manageUserShowDgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.Padding = new System.Windows.Forms.Padding(1);
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(226)))), ((int)(((byte)(171)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.manageUserShowDgv.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.manageUserShowDgv.RowTemplate.Height = 24;
            this.manageUserShowDgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.manageUserShowDgv.Size = new System.Drawing.Size(820, 110);
            this.manageUserShowDgv.TabIndex = 2;
            this.manageUserShowDgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.manageUserShowDgv_CellClick);
            this.manageUserShowDgv.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageUserTab
            // 
            this.manageUserTab.AttachedControl = this.superTabControlPanel4;
            this.manageUserTab.GlobalItem = false;
            this.manageUserTab.Image = global::ProposalReportingSystem.Properties.Resources.user;
            this.manageUserTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.manageUserTab.Name = "manageUserTab";
            this.manageUserTab.Text = "مدیریت اطلاعات کاربران";
            // 
            // superTabControlPanel12
            // 
            this.superTabControlPanel12.Controls.Add(this.manageTeacherPanel);
            this.superTabControlPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel12.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel12.Margin = new System.Windows.Forms.Padding(2);
            this.superTabControlPanel12.Name = "superTabControlPanel12";
            this.superTabControlPanel12.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel12.TabIndex = 0;
            this.superTabControlPanel12.TabItem = this.manageTeacherTab;
            // 
            // manageTeacherPanel
            // 
            this.manageTeacherPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.manageTeacherPanel.Controls.Add(this.teacherManageShowGp);
            this.manageTeacherPanel.Controls.Add(this.manageTeacherInfoGp);
            this.manageTeacherPanel.Location = new System.Drawing.Point(1, 9);
            this.manageTeacherPanel.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherPanel.Name = "manageTeacherPanel";
            this.manageTeacherPanel.Size = new System.Drawing.Size(884, 652);
            this.manageTeacherPanel.TabIndex = 2;
            this.manageTeacherPanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // teacherManageShowGp
            // 
            this.teacherManageShowGp.BackColor = System.Drawing.Color.Transparent;
            this.teacherManageShowGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.teacherManageShowGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.teacherManageShowGp.Controls.Add(this.manageTeacherNavigationPanel);
            this.teacherManageShowGp.Controls.Add(this.manageTeacherShowDgv);
            this.teacherManageShowGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.teacherManageShowGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.teacherManageShowGp.Location = new System.Drawing.Point(22, 306);
            this.teacherManageShowGp.Name = "teacherManageShowGp";
            this.teacherManageShowGp.Size = new System.Drawing.Size(842, 295);
            // 
            // 
            // 
            this.teacherManageShowGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.teacherManageShowGp.Style.BackColorGradientAngle = 90;
            this.teacherManageShowGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.teacherManageShowGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.teacherManageShowGp.Style.BorderBottomWidth = 2;
            this.teacherManageShowGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.teacherManageShowGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.teacherManageShowGp.Style.BorderLeftWidth = 2;
            this.teacherManageShowGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.teacherManageShowGp.Style.BorderRightWidth = 2;
            this.teacherManageShowGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.teacherManageShowGp.Style.BorderTopWidth = 2;
            this.teacherManageShowGp.Style.CornerDiameter = 10;
            this.teacherManageShowGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.teacherManageShowGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.teacherManageShowGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.teacherManageShowGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.teacherManageShowGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.teacherManageShowGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.teacherManageShowGp.TabIndex = 3;
            this.teacherManageShowGp.Text = "فهرست اساتید";
            this.teacherManageShowGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageTeacherNavigationPanel
            // 
            this.manageTeacherNavigationPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.manageTeacherNavigationPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.manageTeacherNavigationPanel.Controls.Add(this.manageTeacherNavigationCurrentPageTxtbx);
            this.manageTeacherNavigationPanel.Controls.Add(this.manageTeacherNavigationNextPageBtn);
            this.manageTeacherNavigationPanel.Controls.Add(this.manageTeacherNavigationLastPageBtn);
            this.manageTeacherNavigationPanel.Controls.Add(this.manageTeacherNavigationPreviousPageBtn);
            this.manageTeacherNavigationPanel.Controls.Add(this.manageTeacherNavigationFirstPageBtn);
            this.manageTeacherNavigationPanel.Controls.Add(this.manageTeacherNavigationReturnBtn);
            this.manageTeacherNavigationPanel.Location = new System.Drawing.Point(96, 136);
            this.manageTeacherNavigationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherNavigationPanel.Name = "manageTeacherNavigationPanel";
            this.manageTeacherNavigationPanel.Size = new System.Drawing.Size(615, 33);
            this.manageTeacherNavigationPanel.TabIndex = 4;
            // 
            // manageTeacherNavigationCurrentPageTxtbx
            // 
            // 
            // 
            // 
            this.manageTeacherNavigationCurrentPageTxtbx.Border.Class = "TextBoxBorder";
            this.manageTeacherNavigationCurrentPageTxtbx.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.manageTeacherNavigationCurrentPageTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherNavigationCurrentPageTxtbx.Location = new System.Drawing.Point(271, 3);
            this.manageTeacherNavigationCurrentPageTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherNavigationCurrentPageTxtbx.MaxLength = 5;
            this.manageTeacherNavigationCurrentPageTxtbx.Multiline = true;
            this.manageTeacherNavigationCurrentPageTxtbx.Name = "manageTeacherNavigationCurrentPageTxtbx";
            this.manageTeacherNavigationCurrentPageTxtbx.PreventEnterBeep = true;
            this.manageTeacherNavigationCurrentPageTxtbx.Size = new System.Drawing.Size(74, 24);
            this.manageTeacherNavigationCurrentPageTxtbx.TabIndex = 34;
            this.manageTeacherNavigationCurrentPageTxtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.manageTeacherNavigationCurrentPageTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.manageTeacherNavigationCurrentPageTxtbx_KeyPress);
            // 
            // manageTeacherNavigationNextPageBtn
            // 
            this.manageTeacherNavigationNextPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherNavigationNextPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherNavigationNextPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherNavigationNextPageBtn.Location = new System.Drawing.Point(349, 3);
            this.manageTeacherNavigationNextPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherNavigationNextPageBtn.Name = "manageTeacherNavigationNextPageBtn";
            this.manageTeacherNavigationNextPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageTeacherNavigationNextPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherNavigationNextPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem20});
            this.manageTeacherNavigationNextPageBtn.SubItemsExpandWidth = 0;
            this.manageTeacherNavigationNextPageBtn.TabIndex = 33;
            this.manageTeacherNavigationNextPageBtn.Text = "صفحه بعد";
            this.manageTeacherNavigationNextPageBtn.Click += new System.EventHandler(this.manageTeacherNavigationNextPageBtn_Click);
            // 
            // superTabItem20
            // 
            this.superTabItem20.GlobalItem = false;
            this.superTabItem20.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem20.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem20.Name = "superTabItem20";
            this.superTabItem20.Text = "لاگ";
            // 
            // manageTeacherNavigationLastPageBtn
            // 
            this.manageTeacherNavigationLastPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherNavigationLastPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherNavigationLastPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherNavigationLastPageBtn.Location = new System.Drawing.Point(436, 3);
            this.manageTeacherNavigationLastPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherNavigationLastPageBtn.Name = "manageTeacherNavigationLastPageBtn";
            this.manageTeacherNavigationLastPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageTeacherNavigationLastPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherNavigationLastPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem21});
            this.manageTeacherNavigationLastPageBtn.SubItemsExpandWidth = 0;
            this.manageTeacherNavigationLastPageBtn.TabIndex = 32;
            this.manageTeacherNavigationLastPageBtn.Text = "صفحه آخر";
            this.manageTeacherNavigationLastPageBtn.Click += new System.EventHandler(this.manageTeacherNavigationLastPageBtn_Click);
            // 
            // superTabItem21
            // 
            this.superTabItem21.GlobalItem = false;
            this.superTabItem21.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem21.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem21.Name = "superTabItem21";
            this.superTabItem21.Text = "لاگ";
            // 
            // manageTeacherNavigationPreviousPageBtn
            // 
            this.manageTeacherNavigationPreviousPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherNavigationPreviousPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherNavigationPreviousPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherNavigationPreviousPageBtn.Location = new System.Drawing.Point(184, 3);
            this.manageTeacherNavigationPreviousPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherNavigationPreviousPageBtn.Name = "manageTeacherNavigationPreviousPageBtn";
            this.manageTeacherNavigationPreviousPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageTeacherNavigationPreviousPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherNavigationPreviousPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem23});
            this.manageTeacherNavigationPreviousPageBtn.SubItemsExpandWidth = 0;
            this.manageTeacherNavigationPreviousPageBtn.TabIndex = 30;
            this.manageTeacherNavigationPreviousPageBtn.Text = "صفحه قبل";
            this.manageTeacherNavigationPreviousPageBtn.Click += new System.EventHandler(this.manageTeacherNavigationPreviousPageBtn_Click);
            // 
            // superTabItem23
            // 
            this.superTabItem23.GlobalItem = false;
            this.superTabItem23.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem23.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem23.Name = "superTabItem23";
            this.superTabItem23.Text = "لاگ";
            // 
            // manageTeacherNavigationFirstPageBtn
            // 
            this.manageTeacherNavigationFirstPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherNavigationFirstPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherNavigationFirstPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherNavigationFirstPageBtn.Location = new System.Drawing.Point(97, 3);
            this.manageTeacherNavigationFirstPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherNavigationFirstPageBtn.Name = "manageTeacherNavigationFirstPageBtn";
            this.manageTeacherNavigationFirstPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageTeacherNavigationFirstPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherNavigationFirstPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem24});
            this.manageTeacherNavigationFirstPageBtn.SubItemsExpandWidth = 0;
            this.manageTeacherNavigationFirstPageBtn.TabIndex = 29;
            this.manageTeacherNavigationFirstPageBtn.Text = "صفحه اول";
            this.manageTeacherNavigationFirstPageBtn.Click += new System.EventHandler(this.manageTeacherNavigationFirstPageBtn_Click);
            // 
            // superTabItem24
            // 
            this.superTabItem24.GlobalItem = false;
            this.superTabItem24.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem24.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem24.Name = "superTabItem24";
            this.superTabItem24.Text = "لاگ";
            // 
            // manageTeacherNavigationReturnBtn
            // 
            this.manageTeacherNavigationReturnBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherNavigationReturnBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherNavigationReturnBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherNavigationReturnBtn.Location = new System.Drawing.Point(10, 3);
            this.manageTeacherNavigationReturnBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherNavigationReturnBtn.Name = "manageTeacherNavigationReturnBtn";
            this.manageTeacherNavigationReturnBtn.Size = new System.Drawing.Size(82, 24);
            this.manageTeacherNavigationReturnBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherNavigationReturnBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem25});
            this.manageTeacherNavigationReturnBtn.SubItemsExpandWidth = 0;
            this.manageTeacherNavigationReturnBtn.TabIndex = 28;
            this.manageTeacherNavigationReturnBtn.Text = "بازگشت";
            // 
            // superTabItem25
            // 
            this.superTabItem25.GlobalItem = false;
            this.superTabItem25.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem25.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem25.Name = "superTabItem25";
            this.superTabItem25.Text = "لاگ";
            // 
            // manageTeacherShowDgv
            // 
            this.manageTeacherShowDgv.AllowUserToAddRows = false;
            this.manageTeacherShowDgv.AllowUserToDeleteRows = false;
            this.manageTeacherShowDgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.manageTeacherShowDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.manageTeacherShowDgv.Location = new System.Drawing.Point(12, 2);
            this.manageTeacherShowDgv.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherShowDgv.MultiSelect = false;
            this.manageTeacherShowDgv.Name = "manageTeacherShowDgv";
            this.manageTeacherShowDgv.ReadOnly = true;
            this.manageTeacherShowDgv.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherShowDgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.manageTeacherShowDgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.Padding = new System.Windows.Forms.Padding(1);
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(226)))), ((int)(((byte)(171)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.manageTeacherShowDgv.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.manageTeacherShowDgv.RowTemplate.Height = 24;
            this.manageTeacherShowDgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.manageTeacherShowDgv.Size = new System.Drawing.Size(806, 124);
            this.manageTeacherShowDgv.TabIndex = 1;
            this.manageTeacherShowDgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.manageTeacherShowDgv_CellClick);
            this.manageTeacherShowDgv.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageTeacherInfoGp
            // 
            this.manageTeacherInfoGp.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherInfoGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.manageTeacherInfoGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherSearchBtn);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherShowAllBtn);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorTel2Txtbx);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorMobileTxtbx);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorEmailTxtbx);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorTelTxtbx);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorTel2Lbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorEgroupCb);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorFacultyCb);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherLnameTxtbx);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorNcodeTxtbx);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherFnameTxtbx);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorEDegCb);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherFnameLbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorNcodeLbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherLnameLbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorMobileLbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorEmailLbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorEDegLbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorEGroupLbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorFacultyLbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherExecutorTelLbl);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherClearBtn);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherDeleteBtn);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherEditBtn);
            this.manageTeacherInfoGp.Controls.Add(this.manageTeacherAddBtn);
            this.manageTeacherInfoGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.manageTeacherInfoGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherInfoGp.Location = new System.Drawing.Point(22, 20);
            this.manageTeacherInfoGp.Name = "manageTeacherInfoGp";
            this.manageTeacherInfoGp.Size = new System.Drawing.Size(842, 280);
            // 
            // 
            // 
            this.manageTeacherInfoGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.manageTeacherInfoGp.Style.BackColorGradientAngle = 90;
            this.manageTeacherInfoGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.manageTeacherInfoGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageTeacherInfoGp.Style.BorderBottomWidth = 2;
            this.manageTeacherInfoGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.manageTeacherInfoGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageTeacherInfoGp.Style.BorderLeftWidth = 2;
            this.manageTeacherInfoGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageTeacherInfoGp.Style.BorderRightWidth = 2;
            this.manageTeacherInfoGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.manageTeacherInfoGp.Style.BorderTopWidth = 2;
            this.manageTeacherInfoGp.Style.CornerDiameter = 10;
            this.manageTeacherInfoGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.manageTeacherInfoGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.manageTeacherInfoGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.manageTeacherInfoGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.manageTeacherInfoGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.manageTeacherInfoGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.manageTeacherInfoGp.TabIndex = 2;
            this.manageTeacherInfoGp.Text = "اطلاعات استاد";
            this.manageTeacherInfoGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageTeacherSearchBtn
            // 
            this.manageTeacherSearchBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherSearchBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherSearchBtn.Location = new System.Drawing.Point(12, 213);
            this.manageTeacherSearchBtn.Name = "manageTeacherSearchBtn";
            this.manageTeacherSearchBtn.Size = new System.Drawing.Size(126, 35);
            this.manageTeacherSearchBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherSearchBtn.TabIndex = 80;
            this.manageTeacherSearchBtn.Text = "جستــــــــــجو";
            this.manageTeacherSearchBtn.Click += new System.EventHandler(this.manageTeacherSearchBtn_Click);
            // 
            // manageTeacherShowAllBtn
            // 
            this.manageTeacherShowAllBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherShowAllBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherShowAllBtn.Location = new System.Drawing.Point(692, 213);
            this.manageTeacherShowAllBtn.Name = "manageTeacherShowAllBtn";
            this.manageTeacherShowAllBtn.Size = new System.Drawing.Size(126, 34);
            this.manageTeacherShowAllBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherShowAllBtn.TabIndex = 79;
            this.manageTeacherShowAllBtn.Text = "نمایش همه";
            this.manageTeacherShowAllBtn.Click += new System.EventHandler(this.manageTeacherShowBtn_Click);
            this.manageTeacherShowAllBtn.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageTeacherExecutorTel2Txtbx
            // 
            this.manageTeacherExecutorTel2Txtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageTeacherExecutorTel2Txtbx.Location = new System.Drawing.Point(73, 145);
            this.manageTeacherExecutorTel2Txtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherExecutorTel2Txtbx.Name = "manageTeacherExecutorTel2Txtbx";
            this.manageTeacherExecutorTel2Txtbx.Size = new System.Drawing.Size(138, 25);
            this.manageTeacherExecutorTel2Txtbx.TabIndex = 10;
            // 
            // manageTeacherExecutorMobileTxtbx
            // 
            this.manageTeacherExecutorMobileTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageTeacherExecutorMobileTxtbx.Location = new System.Drawing.Point(73, 57);
            this.manageTeacherExecutorMobileTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherExecutorMobileTxtbx.Name = "manageTeacherExecutorMobileTxtbx";
            this.manageTeacherExecutorMobileTxtbx.Size = new System.Drawing.Size(138, 25);
            this.manageTeacherExecutorMobileTxtbx.TabIndex = 8;
            // 
            // manageTeacherExecutorEmailTxtbx
            // 
            this.manageTeacherExecutorEmailTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageTeacherExecutorEmailTxtbx.Location = new System.Drawing.Point(73, 14);
            this.manageTeacherExecutorEmailTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherExecutorEmailTxtbx.Name = "manageTeacherExecutorEmailTxtbx";
            this.manageTeacherExecutorEmailTxtbx.Size = new System.Drawing.Size(138, 25);
            this.manageTeacherExecutorEmailTxtbx.TabIndex = 7;
            this.manageTeacherExecutorEmailTxtbx.TextChanged += new System.EventHandler(this.manageTeacherExecutorEmailTxtbx_TextChanged);
            this.manageTeacherExecutorEmailTxtbx.Leave += new System.EventHandler(this.manageTeacherExecutorEmailTxtbx_Leave);
            // 
            // manageTeacherExecutorTelTxtbx
            // 
            this.manageTeacherExecutorTelTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageTeacherExecutorTelTxtbx.Location = new System.Drawing.Point(73, 102);
            this.manageTeacherExecutorTelTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherExecutorTelTxtbx.Name = "manageTeacherExecutorTelTxtbx";
            this.manageTeacherExecutorTelTxtbx.Size = new System.Drawing.Size(138, 25);
            this.manageTeacherExecutorTelTxtbx.TabIndex = 9;
            // 
            // manageTeacherExecutorTel2Lbl
            // 
            this.manageTeacherExecutorTel2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherExecutorTel2Lbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherExecutorTel2Lbl.Location = new System.Drawing.Point(220, 150);
            this.manageTeacherExecutorTel2Lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherExecutorTel2Lbl.Name = "manageTeacherExecutorTel2Lbl";
            this.manageTeacherExecutorTel2Lbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorTel2Lbl.Size = new System.Drawing.Size(73, 20);
            this.manageTeacherExecutorTel2Lbl.TabIndex = 78;
            this.manageTeacherExecutorTel2Lbl.Text = "تلفن تماس";
            this.manageTeacherExecutorTel2Lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // manageTeacherExecutorEgroupCb
            // 
            this.manageTeacherExecutorEgroupCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.manageTeacherExecutorEgroupCb.FormattingEnabled = true;
            this.manageTeacherExecutorEgroupCb.Location = new System.Drawing.Point(352, 17);
            this.manageTeacherExecutorEgroupCb.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherExecutorEgroupCb.Name = "manageTeacherExecutorEgroupCb";
            this.manageTeacherExecutorEgroupCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorEgroupCb.Size = new System.Drawing.Size(139, 25);
            this.manageTeacherExecutorEgroupCb.TabIndex = 5;
            // 
            // manageTeacherExecutorFacultyCb
            // 
            this.manageTeacherExecutorFacultyCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.manageTeacherExecutorFacultyCb.FormattingEnabled = true;
            this.manageTeacherExecutorFacultyCb.Location = new System.Drawing.Point(352, 149);
            this.manageTeacherExecutorFacultyCb.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherExecutorFacultyCb.Name = "manageTeacherExecutorFacultyCb";
            this.manageTeacherExecutorFacultyCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorFacultyCb.Size = new System.Drawing.Size(138, 25);
            this.manageTeacherExecutorFacultyCb.TabIndex = 4;
            this.manageTeacherExecutorFacultyCb.SelectedIndexChanged += new System.EventHandler(this.manageTeacherExecutorFacultyCb_SelectedIndexChanged);
            // 
            // manageTeacherLnameTxtbx
            // 
            this.manageTeacherLnameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageTeacherLnameTxtbx.Location = new System.Drawing.Point(586, 149);
            this.manageTeacherLnameTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherLnameTxtbx.Name = "manageTeacherLnameTxtbx";
            this.manageTeacherLnameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherLnameTxtbx.Size = new System.Drawing.Size(138, 25);
            this.manageTeacherLnameTxtbx.TabIndex = 3;
            // 
            // manageTeacherExecutorNcodeTxtbx
            // 
            this.manageTeacherExecutorNcodeTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageTeacherExecutorNcodeTxtbx.Location = new System.Drawing.Point(586, 22);
            this.manageTeacherExecutorNcodeTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherExecutorNcodeTxtbx.MaxLength = 10;
            this.manageTeacherExecutorNcodeTxtbx.Name = "manageTeacherExecutorNcodeTxtbx";
            this.manageTeacherExecutorNcodeTxtbx.Size = new System.Drawing.Size(138, 25);
            this.manageTeacherExecutorNcodeTxtbx.TabIndex = 1;
            this.manageTeacherExecutorNcodeTxtbx.TextChanged += new System.EventHandler(this.manageTeacherExecutorNcodeTxtbx_TextChanged);
            this.manageTeacherExecutorNcodeTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.manageTeacherExecutorNcodeTxtbx_KeyPress);
            this.manageTeacherExecutorNcodeTxtbx.Leave += new System.EventHandler(this.manageTeacherExecutorNcodeTxtbx_Leave);
            // 
            // manageTeacherFnameTxtbx
            // 
            this.manageTeacherFnameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manageTeacherFnameTxtbx.Location = new System.Drawing.Point(586, 84);
            this.manageTeacherFnameTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherFnameTxtbx.Name = "manageTeacherFnameTxtbx";
            this.manageTeacherFnameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherFnameTxtbx.Size = new System.Drawing.Size(138, 25);
            this.manageTeacherFnameTxtbx.TabIndex = 2;
            // 
            // manageTeacherExecutorEDegCb
            // 
            this.manageTeacherExecutorEDegCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.manageTeacherExecutorEDegCb.FormattingEnabled = true;
            this.manageTeacherExecutorEDegCb.Location = new System.Drawing.Point(352, 84);
            this.manageTeacherExecutorEDegCb.Margin = new System.Windows.Forms.Padding(2);
            this.manageTeacherExecutorEDegCb.Name = "manageTeacherExecutorEDegCb";
            this.manageTeacherExecutorEDegCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorEDegCb.Size = new System.Drawing.Size(139, 25);
            this.manageTeacherExecutorEDegCb.TabIndex = 6;
            // 
            // manageTeacherFnameLbl
            // 
            this.manageTeacherFnameLbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherFnameLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherFnameLbl.Location = new System.Drawing.Point(732, 84);
            this.manageTeacherFnameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherFnameLbl.Name = "manageTeacherFnameLbl";
            this.manageTeacherFnameLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherFnameLbl.Size = new System.Drawing.Size(73, 20);
            this.manageTeacherFnameLbl.TabIndex = 73;
            this.manageTeacherFnameLbl.Text = "نام";
            this.manageTeacherFnameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.manageTeacherFnameLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageTeacherExecutorNcodeLbl
            // 
            this.manageTeacherExecutorNcodeLbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherExecutorNcodeLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherExecutorNcodeLbl.Location = new System.Drawing.Point(733, 22);
            this.manageTeacherExecutorNcodeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherExecutorNcodeLbl.Name = "manageTeacherExecutorNcodeLbl";
            this.manageTeacherExecutorNcodeLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorNcodeLbl.Size = new System.Drawing.Size(70, 20);
            this.manageTeacherExecutorNcodeLbl.TabIndex = 53;
            this.manageTeacherExecutorNcodeLbl.Text = "کدملی";
            this.manageTeacherExecutorNcodeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.manageTeacherExecutorNcodeLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageTeacherLnameLbl
            // 
            this.manageTeacherLnameLbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherLnameLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherLnameLbl.Location = new System.Drawing.Point(732, 149);
            this.manageTeacherLnameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherLnameLbl.Name = "manageTeacherLnameLbl";
            this.manageTeacherLnameLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherLnameLbl.Size = new System.Drawing.Size(73, 20);
            this.manageTeacherLnameLbl.TabIndex = 57;
            this.manageTeacherLnameLbl.Text = "نام خانوادگی";
            this.manageTeacherLnameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.manageTeacherLnameLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageTeacherExecutorMobileLbl
            // 
            this.manageTeacherExecutorMobileLbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherExecutorMobileLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherExecutorMobileLbl.Location = new System.Drawing.Point(219, 57);
            this.manageTeacherExecutorMobileLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherExecutorMobileLbl.Name = "manageTeacherExecutorMobileLbl";
            this.manageTeacherExecutorMobileLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorMobileLbl.Size = new System.Drawing.Size(73, 20);
            this.manageTeacherExecutorMobileLbl.TabIndex = 60;
            this.manageTeacherExecutorMobileLbl.Text = "شماره همراه";
            this.manageTeacherExecutorMobileLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // manageTeacherExecutorEmailLbl
            // 
            this.manageTeacherExecutorEmailLbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherExecutorEmailLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherExecutorEmailLbl.Location = new System.Drawing.Point(219, 14);
            this.manageTeacherExecutorEmailLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherExecutorEmailLbl.Name = "manageTeacherExecutorEmailLbl";
            this.manageTeacherExecutorEmailLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorEmailLbl.Size = new System.Drawing.Size(73, 20);
            this.manageTeacherExecutorEmailLbl.TabIndex = 68;
            this.manageTeacherExecutorEmailLbl.Text = "آدرس ایمیل";
            this.manageTeacherExecutorEmailLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // manageTeacherExecutorEDegLbl
            // 
            this.manageTeacherExecutorEDegLbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherExecutorEDegLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherExecutorEDegLbl.Location = new System.Drawing.Point(496, 84);
            this.manageTeacherExecutorEDegLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherExecutorEDegLbl.Name = "manageTeacherExecutorEDegLbl";
            this.manageTeacherExecutorEDegLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorEDegLbl.Size = new System.Drawing.Size(82, 20);
            this.manageTeacherExecutorEDegLbl.TabIndex = 58;
            this.manageTeacherExecutorEDegLbl.Text = "درجه علمی";
            this.manageTeacherExecutorEDegLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // manageTeacherExecutorEGroupLbl
            // 
            this.manageTeacherExecutorEGroupLbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherExecutorEGroupLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherExecutorEGroupLbl.Location = new System.Drawing.Point(495, 18);
            this.manageTeacherExecutorEGroupLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherExecutorEGroupLbl.Name = "manageTeacherExecutorEGroupLbl";
            this.manageTeacherExecutorEGroupLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorEGroupLbl.Size = new System.Drawing.Size(87, 20);
            this.manageTeacherExecutorEGroupLbl.TabIndex = 66;
            this.manageTeacherExecutorEGroupLbl.Text = "گروه آموزشی";
            this.manageTeacherExecutorEGroupLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // manageTeacherExecutorFacultyLbl
            // 
            this.manageTeacherExecutorFacultyLbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherExecutorFacultyLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherExecutorFacultyLbl.Location = new System.Drawing.Point(495, 149);
            this.manageTeacherExecutorFacultyLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherExecutorFacultyLbl.Name = "manageTeacherExecutorFacultyLbl";
            this.manageTeacherExecutorFacultyLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorFacultyLbl.Size = new System.Drawing.Size(87, 20);
            this.manageTeacherExecutorFacultyLbl.TabIndex = 64;
            this.manageTeacherExecutorFacultyLbl.Text = "دانشکده";
            this.manageTeacherExecutorFacultyLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // manageTeacherExecutorTelLbl
            // 
            this.manageTeacherExecutorTelLbl.BackColor = System.Drawing.Color.Transparent;
            this.manageTeacherExecutorTelLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageTeacherExecutorTelLbl.Location = new System.Drawing.Point(220, 107);
            this.manageTeacherExecutorTelLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.manageTeacherExecutorTelLbl.Name = "manageTeacherExecutorTelLbl";
            this.manageTeacherExecutorTelLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.manageTeacherExecutorTelLbl.Size = new System.Drawing.Size(73, 20);
            this.manageTeacherExecutorTelLbl.TabIndex = 62;
            this.manageTeacherExecutorTelLbl.Text = "تلفن تماس";
            this.manageTeacherExecutorTelLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // manageTeacherClearBtn
            // 
            this.manageTeacherClearBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherClearBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherClearBtn.Location = new System.Drawing.Point(560, 213);
            this.manageTeacherClearBtn.Name = "manageTeacherClearBtn";
            this.manageTeacherClearBtn.Size = new System.Drawing.Size(126, 34);
            this.manageTeacherClearBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherClearBtn.TabIndex = 75;
            this.manageTeacherClearBtn.Text = "پاک کردن";
            this.manageTeacherClearBtn.Click += new System.EventHandler(this.manageTeacherClearBtn_Click);
            // 
            // manageTeacherDeleteBtn
            // 
            this.manageTeacherDeleteBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherDeleteBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherDeleteBtn.Enabled = false;
            this.manageTeacherDeleteBtn.Location = new System.Drawing.Point(428, 213);
            this.manageTeacherDeleteBtn.Name = "manageTeacherDeleteBtn";
            this.manageTeacherDeleteBtn.Size = new System.Drawing.Size(126, 34);
            this.manageTeacherDeleteBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherDeleteBtn.TabIndex = 72;
            this.manageTeacherDeleteBtn.Text = "حذف";
            this.manageTeacherDeleteBtn.Click += new System.EventHandler(this.manageTeacherDeleteBtn_Click);
            // 
            // manageTeacherEditBtn
            // 
            this.manageTeacherEditBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherEditBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherEditBtn.Enabled = false;
            this.manageTeacherEditBtn.Location = new System.Drawing.Point(285, 213);
            this.manageTeacherEditBtn.Name = "manageTeacherEditBtn";
            this.manageTeacherEditBtn.Size = new System.Drawing.Size(126, 35);
            this.manageTeacherEditBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherEditBtn.TabIndex = 71;
            this.manageTeacherEditBtn.Text = "ثبت تغییرات";
            this.manageTeacherEditBtn.Click += new System.EventHandler(this.manageTeacherEditBtn_Click);
            // 
            // manageTeacherAddBtn
            // 
            this.manageTeacherAddBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageTeacherAddBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageTeacherAddBtn.Location = new System.Drawing.Point(144, 213);
            this.manageTeacherAddBtn.Name = "manageTeacherAddBtn";
            this.manageTeacherAddBtn.Size = new System.Drawing.Size(126, 35);
            this.manageTeacherAddBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageTeacherAddBtn.TabIndex = 70;
            this.manageTeacherAddBtn.Text = "افزودن";
            this.manageTeacherAddBtn.Click += new System.EventHandler(this.manageTeacherAddBtn_Click);
            // 
            // manageTeacherTab
            // 
            this.manageTeacherTab.AttachedControl = this.superTabControlPanel12;
            this.manageTeacherTab.GlobalItem = false;
            this.manageTeacherTab.Image = global::ProposalReportingSystem.Properties.Resources.teachers;
            this.manageTeacherTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.manageTeacherTab.Name = "manageTeacherTab";
            this.manageTeacherTab.Text = "مدیریت اطلاعات اساتید";
            // 
            // superTabControlPanel5
            // 
            this.superTabControlPanel5.Controls.Add(this.editProposalPanel);
            this.superTabControlPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel5.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel5.Name = "superTabControlPanel5";
            this.superTabControlPanel5.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel5.TabIndex = 0;
            this.superTabControlPanel5.TabItem = this.manageProposalTab;
            // 
            // editProposalPanel
            // 
            this.editProposalPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.editProposalPanel.Controls.Add(this.editProposalEditGp);
            this.editProposalPanel.Controls.Add(this.editProposalShowGp);
            this.editProposalPanel.Location = new System.Drawing.Point(0, 2);
            this.editProposalPanel.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalPanel.Name = "editProposalPanel";
            this.editProposalPanel.Size = new System.Drawing.Size(888, 656);
            this.editProposalPanel.TabIndex = 2;
            this.editProposalPanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalEditGp
            // 
            this.editProposalEditGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.editProposalEditGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.editProposalEditGp.Controls.Add(this.editProposalShowAllBtn);
            this.editProposalEditGp.Controls.Add(this.editProposalDurationLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalSearchBtn);
            this.editProposalEditGp.Controls.Add(this.editProposalDeleteBtn);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorEGroupCb);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorFacultyCb);
            this.editProposalEditGp.Controls.Add(this.editProposalStartdateTimeInput);
            this.editProposalEditGp.Controls.Add(this.editProposalFileLinkLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalFileLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalOrganizationNumberCb);
            this.editProposalEditGp.Controls.Add(this.editProposalStatusCb);
            this.editProposalEditGp.Controls.Add(this.editProposalOrganizationNameCb);
            this.editProposalEditGp.Controls.Add(this.editProposalTypeCb);
            this.editProposalEditGp.Controls.Add(this.editProposalRegisterTypeCb);
            this.editProposalEditGp.Controls.Add(this.editProposalPropertyTypeCb);
            this.editProposalEditGp.Controls.Add(this.editProposalProcedureTypeCb);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorEDegCb);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorMobileTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorMobileLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorEmailLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorEDegLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorEmailTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorEGroupLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorFacultyLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorTel2Lbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorTel2Txtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorTel1Lbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorTel1Txtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorLNameLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorLNameTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorFNameLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorFNameTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalValueTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalValueLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalOrganizationLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalStatusLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalTypeLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalRegisterTypeLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalPropertyTypeLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalProcedureTypeLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalDurationTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalStartdateLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalCoexecutorLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalCoexecutorTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutor2Lbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorNcodeLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalKeywordsLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalEnglishTitleLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalPersianTitleLbl);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutor2Txtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalExecutorNcodeTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalKeywordsTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalEnglishTitleTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalPersianTitleTxtbx);
            this.editProposalEditGp.Controls.Add(this.editProposalRegisterBtn);
            this.editProposalEditGp.Controls.Add(this.editProposalClearBtn);
            this.editProposalEditGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.editProposalEditGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalEditGp.Location = new System.Drawing.Point(16, 2);
            this.editProposalEditGp.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalEditGp.Name = "editProposalEditGp";
            this.editProposalEditGp.Size = new System.Drawing.Size(847, 335);
            // 
            // 
            // 
            this.editProposalEditGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.editProposalEditGp.Style.BackColorGradientAngle = 90;
            this.editProposalEditGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.editProposalEditGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.editProposalEditGp.Style.BorderBottomWidth = 2;
            this.editProposalEditGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.editProposalEditGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.editProposalEditGp.Style.BorderLeftWidth = 2;
            this.editProposalEditGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.editProposalEditGp.Style.BorderRightWidth = 2;
            this.editProposalEditGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.editProposalEditGp.Style.BorderTopWidth = 2;
            this.editProposalEditGp.Style.CornerDiameter = 10;
            this.editProposalEditGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.editProposalEditGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.editProposalEditGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.editProposalEditGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.editProposalEditGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.editProposalEditGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.editProposalEditGp.TabIndex = 2;
            this.editProposalEditGp.Text = "اطلاعات پروپوزال";
            this.editProposalEditGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalShowAllBtn
            // 
            this.editProposalShowAllBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.editProposalShowAllBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.editProposalShowAllBtn.Location = new System.Drawing.Point(328, 262);
            this.editProposalShowAllBtn.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalShowAllBtn.Name = "editProposalShowAllBtn";
            this.editProposalShowAllBtn.Size = new System.Drawing.Size(77, 24);
            this.editProposalShowAllBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.editProposalShowAllBtn.TabIndex = 30;
            this.editProposalShowAllBtn.Text = "نمایش همه";
            this.editProposalShowAllBtn.Click += new System.EventHandler(this.editProposalShowAllBtn_Click);
            // 
            // editProposalDurationLbl
            // 
            this.editProposalDurationLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalDurationLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalDurationLbl.Location = new System.Drawing.Point(194, 2);
            this.editProposalDurationLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalDurationLbl.Name = "editProposalDurationLbl";
            this.editProposalDurationLbl.Size = new System.Drawing.Size(90, 20);
            this.editProposalDurationLbl.TabIndex = 73;
            this.editProposalDurationLbl.Text = "*مدت زمان (ماه)";
            this.editProposalDurationLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalSearchBtn
            // 
            this.editProposalSearchBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.editProposalSearchBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.editProposalSearchBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalSearchBtn.Location = new System.Drawing.Point(572, 2);
            this.editProposalSearchBtn.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalSearchBtn.Name = "editProposalSearchBtn";
            this.editProposalSearchBtn.Size = new System.Drawing.Size(58, 24);
            this.editProposalSearchBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.editProposalSearchBtn.TabIndex = 117;
            this.editProposalSearchBtn.Text = "جستجو";
            this.editProposalSearchBtn.Click += new System.EventHandler(this.editProposalSearchBtn_Click);
            // 
            // editProposalDeleteBtn
            // 
            this.editProposalDeleteBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.editProposalDeleteBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.editProposalDeleteBtn.Enabled = false;
            this.editProposalDeleteBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalDeleteBtn.Location = new System.Drawing.Point(236, 262);
            this.editProposalDeleteBtn.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalDeleteBtn.Name = "editProposalDeleteBtn";
            this.editProposalDeleteBtn.Size = new System.Drawing.Size(57, 24);
            this.editProposalDeleteBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.editProposalDeleteBtn.TabIndex = 28;
            this.editProposalDeleteBtn.Text = "حذف اطلاعات";
            this.editProposalDeleteBtn.Click += new System.EventHandler(this.editProposalDeleteBtn_Click);
            // 
            // editProposalExecutorEGroupCb
            // 
            this.editProposalExecutorEGroupCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.editProposalExecutorEGroupCb.FormattingEnabled = true;
            this.editProposalExecutorEGroupCb.Location = new System.Drawing.Point(572, 119);
            this.editProposalExecutorEGroupCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorEGroupCb.Name = "editProposalExecutorEGroupCb";
            this.editProposalExecutorEGroupCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalExecutorEGroupCb.Size = new System.Drawing.Size(139, 25);
            this.editProposalExecutorEGroupCb.TabIndex = 5;
            // 
            // editProposalExecutorFacultyCb
            // 
            this.editProposalExecutorFacultyCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.editProposalExecutorFacultyCb.FormattingEnabled = true;
            this.editProposalExecutorFacultyCb.Location = new System.Drawing.Point(572, 91);
            this.editProposalExecutorFacultyCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorFacultyCb.Name = "editProposalExecutorFacultyCb";
            this.editProposalExecutorFacultyCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalExecutorFacultyCb.Size = new System.Drawing.Size(139, 25);
            this.editProposalExecutorFacultyCb.TabIndex = 4;
            this.editProposalExecutorFacultyCb.SelectedIndexChanged += new System.EventHandler(this.editProposalExecutorFacultyCb_SelectedIndexChanged);
            // 
            // editProposalStartdateTimeInput
            // 
            this.editProposalStartdateTimeInput.BackColor = System.Drawing.Color.Transparent;
            this.editProposalStartdateTimeInput.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalStartdateTimeInput.GeoDate = new System.DateTime(2016, 11, 28, 0, 0, 0, 0);
            this.editProposalStartdateTimeInput.Location = new System.Drawing.Point(328, 229);
            this.editProposalStartdateTimeInput.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.editProposalStartdateTimeInput.MaximumSize = new System.Drawing.Size(1265, 36);
            this.editProposalStartdateTimeInput.Name = "editProposalStartdateTimeInput";
            this.editProposalStartdateTimeInput.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.editProposalStartdateTimeInput.Size = new System.Drawing.Size(139, 23);
            this.editProposalStartdateTimeInput.TabIndex = 16;
            // 
            // editProposalFileLinkLbl
            // 
            this.editProposalFileLinkLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalFileLinkLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalFileLinkLbl.Location = new System.Drawing.Point(395, 262);
            this.editProposalFileLinkLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalFileLinkLbl.Name = "editProposalFileLinkLbl";
            this.editProposalFileLinkLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalFileLinkLbl.Size = new System.Drawing.Size(83, 20);
            this.editProposalFileLinkLbl.TabIndex = 26;
            this.editProposalFileLinkLbl.TabStop = true;
            this.editProposalFileLinkLbl.Text = "افزودن فایل";
            this.editProposalFileLinkLbl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.editProposalFileLinkLbl_LinkClicked);
            // 
            // editProposalFileLbl
            // 
            this.editProposalFileLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalFileLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalFileLbl.Location = new System.Drawing.Point(474, 262);
            this.editProposalFileLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalFileLbl.Name = "editProposalFileLbl";
            this.editProposalFileLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalFileLbl.TabIndex = 111;
            this.editProposalFileLbl.Text = "*فایل پروپوزال";
            this.editProposalFileLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalOrganizationNumberCb
            // 
            this.editProposalOrganizationNumberCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalOrganizationNumberCb.FormattingEnabled = true;
            this.editProposalOrganizationNumberCb.Location = new System.Drawing.Point(150, 158);
            this.editProposalOrganizationNumberCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalOrganizationNumberCb.Name = "editProposalOrganizationNumberCb";
            this.editProposalOrganizationNumberCb.Size = new System.Drawing.Size(40, 25);
            this.editProposalOrganizationNumberCb.TabIndex = 22;
            this.editProposalOrganizationNumberCb.SelectedIndexChanged += new System.EventHandler(this.editProposalOrganizationNumberCb_SelectedIndexChanged);
            this.editProposalOrganizationNumberCb.TextChanged += new System.EventHandler(this.editProposalOrganizationNumberCb_TextChanged);
            this.editProposalOrganizationNumberCb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.editProposalExecutorNcodeTxtbx_KeyPress_1);
            // 
            // editProposalStatusCb
            // 
            this.editProposalStatusCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.editProposalStatusCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalStatusCb.FormattingEnabled = true;
            this.editProposalStatusCb.Location = new System.Drawing.Point(51, 221);
            this.editProposalStatusCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalStatusCb.Name = "editProposalStatusCb";
            this.editProposalStatusCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalStatusCb.Size = new System.Drawing.Size(139, 25);
            this.editProposalStatusCb.TabIndex = 25;
            // 
            // editProposalOrganizationNameCb
            // 
            this.editProposalOrganizationNameCb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.editProposalOrganizationNameCb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.editProposalOrganizationNameCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalOrganizationNameCb.FormattingEnabled = true;
            this.editProposalOrganizationNameCb.Location = new System.Drawing.Point(51, 158);
            this.editProposalOrganizationNameCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalOrganizationNameCb.Name = "editProposalOrganizationNameCb";
            this.editProposalOrganizationNameCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalOrganizationNameCb.Size = new System.Drawing.Size(96, 25);
            this.editProposalOrganizationNameCb.TabIndex = 23;
            this.editProposalOrganizationNameCb.SelectedIndexChanged += new System.EventHandler(this.editProposalOrganizationNameCb_SelectedIndexChanged);
            this.editProposalOrganizationNameCb.TextChanged += new System.EventHandler(this.editProposalOrganizationNameCb_TextChanged);
            // 
            // editProposalTypeCb
            // 
            this.editProposalTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.editProposalTypeCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalTypeCb.FormattingEnabled = true;
            this.editProposalTypeCb.Location = new System.Drawing.Point(51, 127);
            this.editProposalTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalTypeCb.Name = "editProposalTypeCb";
            this.editProposalTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalTypeCb.Size = new System.Drawing.Size(139, 25);
            this.editProposalTypeCb.TabIndex = 21;
            // 
            // editProposalRegisterTypeCb
            // 
            this.editProposalRegisterTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.editProposalRegisterTypeCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalRegisterTypeCb.FormattingEnabled = true;
            this.editProposalRegisterTypeCb.Location = new System.Drawing.Point(51, 97);
            this.editProposalRegisterTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalRegisterTypeCb.Name = "editProposalRegisterTypeCb";
            this.editProposalRegisterTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalRegisterTypeCb.Size = new System.Drawing.Size(139, 25);
            this.editProposalRegisterTypeCb.TabIndex = 20;
            // 
            // editProposalPropertyTypeCb
            // 
            this.editProposalPropertyTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.editProposalPropertyTypeCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalPropertyTypeCb.FormattingEnabled = true;
            this.editProposalPropertyTypeCb.Location = new System.Drawing.Point(51, 64);
            this.editProposalPropertyTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalPropertyTypeCb.Name = "editProposalPropertyTypeCb";
            this.editProposalPropertyTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalPropertyTypeCb.Size = new System.Drawing.Size(139, 25);
            this.editProposalPropertyTypeCb.TabIndex = 19;
            // 
            // editProposalProcedureTypeCb
            // 
            this.editProposalProcedureTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.editProposalProcedureTypeCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalProcedureTypeCb.FormattingEnabled = true;
            this.editProposalProcedureTypeCb.Location = new System.Drawing.Point(51, 35);
            this.editProposalProcedureTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalProcedureTypeCb.Name = "editProposalProcedureTypeCb";
            this.editProposalProcedureTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalProcedureTypeCb.Size = new System.Drawing.Size(139, 25);
            this.editProposalProcedureTypeCb.TabIndex = 18;
            // 
            // editProposalExecutorEDegCb
            // 
            this.editProposalExecutorEDegCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.editProposalExecutorEDegCb.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorEDegCb.FormattingEnabled = true;
            this.editProposalExecutorEDegCb.Location = new System.Drawing.Point(572, 148);
            this.editProposalExecutorEDegCb.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorEDegCb.Name = "editProposalExecutorEDegCb";
            this.editProposalExecutorEDegCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalExecutorEDegCb.Size = new System.Drawing.Size(139, 25);
            this.editProposalExecutorEDegCb.TabIndex = 6;
            // 
            // editProposalExecutorMobileTxtbx
            // 
            this.editProposalExecutorMobileTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalExecutorMobileTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorMobileTxtbx.Location = new System.Drawing.Point(572, 204);
            this.editProposalExecutorMobileTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorMobileTxtbx.MaxLength = 20;
            this.editProposalExecutorMobileTxtbx.Name = "editProposalExecutorMobileTxtbx";
            this.editProposalExecutorMobileTxtbx.Size = new System.Drawing.Size(138, 25);
            this.editProposalExecutorMobileTxtbx.TabIndex = 8;
            this.editProposalExecutorMobileTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.editProposalExecutorNcodeTxtbx_KeyPress_1);
            // 
            // editProposalExecutorMobileLbl
            // 
            this.editProposalExecutorMobileLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorMobileLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorMobileLbl.Location = new System.Drawing.Point(718, 204);
            this.editProposalExecutorMobileLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorMobileLbl.Name = "editProposalExecutorMobileLbl";
            this.editProposalExecutorMobileLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorMobileLbl.TabIndex = 92;
            this.editProposalExecutorMobileLbl.Text = "*شماره همراه";
            this.editProposalExecutorMobileLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorMobileLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalExecutorEmailLbl
            // 
            this.editProposalExecutorEmailLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorEmailLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorEmailLbl.Location = new System.Drawing.Point(718, 176);
            this.editProposalExecutorEmailLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorEmailLbl.Name = "editProposalExecutorEmailLbl";
            this.editProposalExecutorEmailLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorEmailLbl.TabIndex = 102;
            this.editProposalExecutorEmailLbl.Text = "*آدرس ایمیل";
            this.editProposalExecutorEmailLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorEmailLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalExecutorEDegLbl
            // 
            this.editProposalExecutorEDegLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorEDegLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorEDegLbl.Location = new System.Drawing.Point(718, 149);
            this.editProposalExecutorEDegLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorEDegLbl.Name = "editProposalExecutorEDegLbl";
            this.editProposalExecutorEDegLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorEDegLbl.TabIndex = 90;
            this.editProposalExecutorEDegLbl.Text = "*درجه علمی";
            this.editProposalExecutorEDegLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorEDegLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalExecutorEmailTxtbx
            // 
            this.editProposalExecutorEmailTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalExecutorEmailTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorEmailTxtbx.Location = new System.Drawing.Point(572, 176);
            this.editProposalExecutorEmailTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorEmailTxtbx.MaxLength = 50;
            this.editProposalExecutorEmailTxtbx.Name = "editProposalExecutorEmailTxtbx";
            this.editProposalExecutorEmailTxtbx.Size = new System.Drawing.Size(138, 25);
            this.editProposalExecutorEmailTxtbx.TabIndex = 7;
            this.editProposalExecutorEmailTxtbx.TextChanged += new System.EventHandler(this.editProposalExecutorEmailTxtbx_TextChanged);
            this.editProposalExecutorEmailTxtbx.Leave += new System.EventHandler(this.editProposalExecutorEmailTxtbx_Leave);
            // 
            // editProposalExecutorEGroupLbl
            // 
            this.editProposalExecutorEGroupLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorEGroupLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorEGroupLbl.Location = new System.Drawing.Point(718, 119);
            this.editProposalExecutorEGroupLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorEGroupLbl.Name = "editProposalExecutorEGroupLbl";
            this.editProposalExecutorEGroupLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorEGroupLbl.TabIndex = 100;
            this.editProposalExecutorEGroupLbl.Text = "*گروه آموزشی";
            this.editProposalExecutorEGroupLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorEGroupLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalExecutorFacultyLbl
            // 
            this.editProposalExecutorFacultyLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorFacultyLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorFacultyLbl.Location = new System.Drawing.Point(718, 91);
            this.editProposalExecutorFacultyLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorFacultyLbl.Name = "editProposalExecutorFacultyLbl";
            this.editProposalExecutorFacultyLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorFacultyLbl.TabIndex = 98;
            this.editProposalExecutorFacultyLbl.Text = "*دانشکده";
            this.editProposalExecutorFacultyLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorFacultyLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalExecutorTel2Lbl
            // 
            this.editProposalExecutorTel2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorTel2Lbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorTel2Lbl.Location = new System.Drawing.Point(718, 262);
            this.editProposalExecutorTel2Lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorTel2Lbl.Name = "editProposalExecutorTel2Lbl";
            this.editProposalExecutorTel2Lbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorTel2Lbl.TabIndex = 96;
            this.editProposalExecutorTel2Lbl.Text = "تلفن تماس";
            this.editProposalExecutorTel2Lbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorTel2Lbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalExecutorTel2Txtbx
            // 
            this.editProposalExecutorTel2Txtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalExecutorTel2Txtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorTel2Txtbx.Location = new System.Drawing.Point(572, 262);
            this.editProposalExecutorTel2Txtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorTel2Txtbx.MaxLength = 20;
            this.editProposalExecutorTel2Txtbx.Name = "editProposalExecutorTel2Txtbx";
            this.editProposalExecutorTel2Txtbx.Size = new System.Drawing.Size(138, 25);
            this.editProposalExecutorTel2Txtbx.TabIndex = 10;
            this.editProposalExecutorTel2Txtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.editProposalExecutorNcodeTxtbx_KeyPress_1);
            // 
            // editProposalExecutorTel1Lbl
            // 
            this.editProposalExecutorTel1Lbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorTel1Lbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorTel1Lbl.Location = new System.Drawing.Point(718, 232);
            this.editProposalExecutorTel1Lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorTel1Lbl.Name = "editProposalExecutorTel1Lbl";
            this.editProposalExecutorTel1Lbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorTel1Lbl.TabIndex = 94;
            this.editProposalExecutorTel1Lbl.Text = "تلفن تماس";
            this.editProposalExecutorTel1Lbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorTel1Lbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalExecutorTel1Txtbx
            // 
            this.editProposalExecutorTel1Txtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalExecutorTel1Txtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorTel1Txtbx.Location = new System.Drawing.Point(572, 232);
            this.editProposalExecutorTel1Txtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorTel1Txtbx.MaxLength = 20;
            this.editProposalExecutorTel1Txtbx.Name = "editProposalExecutorTel1Txtbx";
            this.editProposalExecutorTel1Txtbx.Size = new System.Drawing.Size(138, 25);
            this.editProposalExecutorTel1Txtbx.TabIndex = 9;
            this.editProposalExecutorTel1Txtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.editProposalExecutorNcodeTxtbx_KeyPress_1);
            // 
            // editProposalExecutorLNameLbl
            // 
            this.editProposalExecutorLNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorLNameLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorLNameLbl.Location = new System.Drawing.Point(718, 61);
            this.editProposalExecutorLNameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorLNameLbl.Name = "editProposalExecutorLNameLbl";
            this.editProposalExecutorLNameLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorLNameLbl.TabIndex = 89;
            this.editProposalExecutorLNameLbl.Text = "*نام خانوادگی";
            this.editProposalExecutorLNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorLNameLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalExecutorLNameTxtbx
            // 
            this.editProposalExecutorLNameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalExecutorLNameTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorLNameTxtbx.Location = new System.Drawing.Point(572, 61);
            this.editProposalExecutorLNameTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorLNameTxtbx.MaxLength = 100;
            this.editProposalExecutorLNameTxtbx.Name = "editProposalExecutorLNameTxtbx";
            this.editProposalExecutorLNameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalExecutorLNameTxtbx.Size = new System.Drawing.Size(138, 25);
            this.editProposalExecutorLNameTxtbx.TabIndex = 3;
            // 
            // editProposalExecutorFNameLbl
            // 
            this.editProposalExecutorFNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorFNameLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorFNameLbl.Location = new System.Drawing.Point(718, 32);
            this.editProposalExecutorFNameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorFNameLbl.Name = "editProposalExecutorFNameLbl";
            this.editProposalExecutorFNameLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorFNameLbl.TabIndex = 87;
            this.editProposalExecutorFNameLbl.Text = "*نام";
            this.editProposalExecutorFNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorFNameLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalExecutorFNameTxtbx
            // 
            this.editProposalExecutorFNameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalExecutorFNameTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorFNameTxtbx.Location = new System.Drawing.Point(572, 32);
            this.editProposalExecutorFNameTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorFNameTxtbx.MaxLength = 100;
            this.editProposalExecutorFNameTxtbx.Name = "editProposalExecutorFNameTxtbx";
            this.editProposalExecutorFNameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalExecutorFNameTxtbx.Size = new System.Drawing.Size(138, 25);
            this.editProposalExecutorFNameTxtbx.TabIndex = 2;
            this.editProposalExecutorFNameTxtbx.Enter += new System.EventHandler(this.editProposalExecutorFNameTxtbx_Enter);
            // 
            // editProposalValueTxtbx
            // 
            this.editProposalValueTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalValueTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalValueTxtbx.Location = new System.Drawing.Point(51, 189);
            this.editProposalValueTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalValueTxtbx.MaxLength = 20;
            this.editProposalValueTxtbx.Name = "editProposalValueTxtbx";
            this.editProposalValueTxtbx.Size = new System.Drawing.Size(138, 25);
            this.editProposalValueTxtbx.TabIndex = 24;
            this.editProposalValueTxtbx.TextChanged += new System.EventHandler(this.editProposalValueTxtbx_TextChanged);
            this.editProposalValueTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.editProposalExecutorNcodeTxtbx_KeyPress_1);
            // 
            // editProposalValueLbl
            // 
            this.editProposalValueLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalValueLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalValueLbl.Location = new System.Drawing.Point(194, 189);
            this.editProposalValueLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalValueLbl.Name = "editProposalValueLbl";
            this.editProposalValueLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalValueLbl.TabIndex = 82;
            this.editProposalValueLbl.Text = "*مبلغ";
            this.editProposalValueLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalOrganizationLbl
            // 
            this.editProposalOrganizationLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalOrganizationLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalOrganizationLbl.Location = new System.Drawing.Point(194, 159);
            this.editProposalOrganizationLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalOrganizationLbl.Name = "editProposalOrganizationLbl";
            this.editProposalOrganizationLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalOrganizationLbl.TabIndex = 81;
            this.editProposalOrganizationLbl.Text = "*سازمان کارفرما";
            this.editProposalOrganizationLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalStatusLbl
            // 
            this.editProposalStatusLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalStatusLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalStatusLbl.Location = new System.Drawing.Point(194, 219);
            this.editProposalStatusLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalStatusLbl.Name = "editProposalStatusLbl";
            this.editProposalStatusLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalStatusLbl.TabIndex = 80;
            this.editProposalStatusLbl.Text = "*وضعیت";
            this.editProposalStatusLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalTypeLbl
            // 
            this.editProposalTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalTypeLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalTypeLbl.Location = new System.Drawing.Point(194, 130);
            this.editProposalTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalTypeLbl.Name = "editProposalTypeLbl";
            this.editProposalTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalTypeLbl.TabIndex = 79;
            this.editProposalTypeLbl.Text = "*نوع پروپوزال";
            this.editProposalTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalRegisterTypeLbl
            // 
            this.editProposalRegisterTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalRegisterTypeLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalRegisterTypeLbl.Location = new System.Drawing.Point(194, 98);
            this.editProposalRegisterTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalRegisterTypeLbl.Name = "editProposalRegisterTypeLbl";
            this.editProposalRegisterTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalRegisterTypeLbl.TabIndex = 78;
            this.editProposalRegisterTypeLbl.Text = "*نوع ثبت";
            this.editProposalRegisterTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalPropertyTypeLbl
            // 
            this.editProposalPropertyTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalPropertyTypeLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalPropertyTypeLbl.Location = new System.Drawing.Point(194, 63);
            this.editProposalPropertyTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalPropertyTypeLbl.Name = "editProposalPropertyTypeLbl";
            this.editProposalPropertyTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalPropertyTypeLbl.TabIndex = 77;
            this.editProposalPropertyTypeLbl.Text = "*خاصیت";
            this.editProposalPropertyTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalProcedureTypeLbl
            // 
            this.editProposalProcedureTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalProcedureTypeLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalProcedureTypeLbl.Location = new System.Drawing.Point(194, 32);
            this.editProposalProcedureTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalProcedureTypeLbl.Name = "editProposalProcedureTypeLbl";
            this.editProposalProcedureTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalProcedureTypeLbl.TabIndex = 76;
            this.editProposalProcedureTypeLbl.Text = "*نوع کار";
            this.editProposalProcedureTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalDurationTxtbx
            // 
            this.editProposalDurationTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalDurationTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalDurationTxtbx.Location = new System.Drawing.Point(51, 2);
            this.editProposalDurationTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalDurationTxtbx.MaxLength = 10;
            this.editProposalDurationTxtbx.Name = "editProposalDurationTxtbx";
            this.editProposalDurationTxtbx.Size = new System.Drawing.Size(139, 25);
            this.editProposalDurationTxtbx.TabIndex = 17;
            this.editProposalDurationTxtbx.TextChanged += new System.EventHandler(this.editProposalDurationTxtbx_TextChanged);
            this.editProposalDurationTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.editProposalExecutorNcodeTxtbx_KeyPress_1);
            // 
            // editProposalStartdateLbl
            // 
            this.editProposalStartdateLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalStartdateLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalStartdateLbl.Location = new System.Drawing.Point(472, 229);
            this.editProposalStartdateLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalStartdateLbl.Name = "editProposalStartdateLbl";
            this.editProposalStartdateLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalStartdateLbl.TabIndex = 72;
            this.editProposalStartdateLbl.Text = "*تاریخ ارسال";
            this.editProposalStartdateLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalCoexecutorLbl
            // 
            this.editProposalCoexecutorLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalCoexecutorLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalCoexecutorLbl.Location = new System.Drawing.Point(472, 188);
            this.editProposalCoexecutorLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalCoexecutorLbl.Name = "editProposalCoexecutorLbl";
            this.editProposalCoexecutorLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalCoexecutorLbl.TabIndex = 71;
            this.editProposalCoexecutorLbl.Text = "همکاران مجری";
            this.editProposalCoexecutorLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalCoexecutorTxtbx
            // 
            this.editProposalCoexecutorTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalCoexecutorTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalCoexecutorTxtbx.Location = new System.Drawing.Point(328, 177);
            this.editProposalCoexecutorTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalCoexecutorTxtbx.Multiline = true;
            this.editProposalCoexecutorTxtbx.Name = "editProposalCoexecutorTxtbx";
            this.editProposalCoexecutorTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalCoexecutorTxtbx.Size = new System.Drawing.Size(138, 36);
            this.editProposalCoexecutorTxtbx.TabIndex = 15;
            // 
            // editProposalExecutor2Lbl
            // 
            this.editProposalExecutor2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutor2Lbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutor2Lbl.Location = new System.Drawing.Point(474, 150);
            this.editProposalExecutor2Lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutor2Lbl.Name = "editProposalExecutor2Lbl";
            this.editProposalExecutor2Lbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutor2Lbl.TabIndex = 69;
            this.editProposalExecutor2Lbl.Text = "مجریان همکار";
            this.editProposalExecutor2Lbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalExecutorNcodeLbl
            // 
            this.editProposalExecutorNcodeLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalExecutorNcodeLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorNcodeLbl.Location = new System.Drawing.Point(718, 2);
            this.editProposalExecutorNcodeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalExecutorNcodeLbl.Name = "editProposalExecutorNcodeLbl";
            this.editProposalExecutorNcodeLbl.Size = new System.Drawing.Size(73, 20);
            this.editProposalExecutorNcodeLbl.TabIndex = 68;
            this.editProposalExecutorNcodeLbl.Text = "*کدملی مجری";
            this.editProposalExecutorNcodeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.editProposalExecutorNcodeLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // editProposalKeywordsLbl
            // 
            this.editProposalKeywordsLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalKeywordsLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalKeywordsLbl.Location = new System.Drawing.Point(471, 73);
            this.editProposalKeywordsLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalKeywordsLbl.Name = "editProposalKeywordsLbl";
            this.editProposalKeywordsLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalKeywordsLbl.TabIndex = 67;
            this.editProposalKeywordsLbl.Text = "*کلمات کلیدی";
            this.editProposalKeywordsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalEnglishTitleLbl
            // 
            this.editProposalEnglishTitleLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalEnglishTitleLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalEnglishTitleLbl.Location = new System.Drawing.Point(471, 44);
            this.editProposalEnglishTitleLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalEnglishTitleLbl.Name = "editProposalEnglishTitleLbl";
            this.editProposalEnglishTitleLbl.Size = new System.Drawing.Size(74, 20);
            this.editProposalEnglishTitleLbl.TabIndex = 66;
            this.editProposalEnglishTitleLbl.Text = "*عنوان لاتین";
            this.editProposalEnglishTitleLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalPersianTitleLbl
            // 
            this.editProposalPersianTitleLbl.BackColor = System.Drawing.Color.Transparent;
            this.editProposalPersianTitleLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalPersianTitleLbl.Location = new System.Drawing.Point(471, 16);
            this.editProposalPersianTitleLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.editProposalPersianTitleLbl.Name = "editProposalPersianTitleLbl";
            this.editProposalPersianTitleLbl.Size = new System.Drawing.Size(73, 22);
            this.editProposalPersianTitleLbl.TabIndex = 65;
            this.editProposalPersianTitleLbl.Text = "*عنوان فارسی";
            this.editProposalPersianTitleLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // editProposalExecutor2Txtbx
            // 
            this.editProposalExecutor2Txtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalExecutor2Txtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutor2Txtbx.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.editProposalExecutor2Txtbx.Location = new System.Drawing.Point(328, 130);
            this.editProposalExecutor2Txtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutor2Txtbx.Multiline = true;
            this.editProposalExecutor2Txtbx.Name = "editProposalExecutor2Txtbx";
            this.editProposalExecutor2Txtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalExecutor2Txtbx.Size = new System.Drawing.Size(138, 34);
            this.editProposalExecutor2Txtbx.TabIndex = 14;
            // 
            // editProposalExecutorNcodeTxtbx
            // 
            this.editProposalExecutorNcodeTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalExecutorNcodeTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalExecutorNcodeTxtbx.Location = new System.Drawing.Point(635, 2);
            this.editProposalExecutorNcodeTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalExecutorNcodeTxtbx.MaxLength = 10;
            this.editProposalExecutorNcodeTxtbx.Name = "editProposalExecutorNcodeTxtbx";
            this.editProposalExecutorNcodeTxtbx.Size = new System.Drawing.Size(75, 25);
            this.editProposalExecutorNcodeTxtbx.TabIndex = 1;
            this.editProposalExecutorNcodeTxtbx.TextChanged += new System.EventHandler(this.editProposalExecutorNcodeTxtbx_TextChanged);
            this.editProposalExecutorNcodeTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.editProposalExecutorNcodeTxtbx_KeyPress_1);
            // 
            // editProposalKeywordsTxtbx
            // 
            this.editProposalKeywordsTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalKeywordsTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalKeywordsTxtbx.Location = new System.Drawing.Point(328, 73);
            this.editProposalKeywordsTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalKeywordsTxtbx.Multiline = true;
            this.editProposalKeywordsTxtbx.Name = "editProposalKeywordsTxtbx";
            this.editProposalKeywordsTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalKeywordsTxtbx.Size = new System.Drawing.Size(138, 44);
            this.editProposalKeywordsTxtbx.TabIndex = 13;
            // 
            // editProposalEnglishTitleTxtbx
            // 
            this.editProposalEnglishTitleTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalEnglishTitleTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalEnglishTitleTxtbx.Location = new System.Drawing.Point(328, 38);
            this.editProposalEnglishTitleTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalEnglishTitleTxtbx.Multiline = true;
            this.editProposalEnglishTitleTxtbx.Name = "editProposalEnglishTitleTxtbx";
            this.editProposalEnglishTitleTxtbx.Size = new System.Drawing.Size(138, 26);
            this.editProposalEnglishTitleTxtbx.TabIndex = 12;
            // 
            // editProposalPersianTitleTxtbx
            // 
            this.editProposalPersianTitleTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.editProposalPersianTitleTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalPersianTitleTxtbx.Location = new System.Drawing.Point(328, 2);
            this.editProposalPersianTitleTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalPersianTitleTxtbx.Multiline = true;
            this.editProposalPersianTitleTxtbx.Name = "editProposalPersianTitleTxtbx";
            this.editProposalPersianTitleTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalPersianTitleTxtbx.Size = new System.Drawing.Size(138, 31);
            this.editProposalPersianTitleTxtbx.TabIndex = 11;
            // 
            // editProposalRegisterBtn
            // 
            this.editProposalRegisterBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.editProposalRegisterBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.editProposalRegisterBtn.Enabled = false;
            this.editProposalRegisterBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalRegisterBtn.Location = new System.Drawing.Point(51, 262);
            this.editProposalRegisterBtn.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalRegisterBtn.Name = "editProposalRegisterBtn";
            this.editProposalRegisterBtn.Size = new System.Drawing.Size(82, 24);
            this.editProposalRegisterBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.editProposalRegisterBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.logTab});
            this.editProposalRegisterBtn.SubItemsExpandWidth = 0;
            this.editProposalRegisterBtn.TabIndex = 27;
            this.editProposalRegisterBtn.Text = "ثبت تغییرات";
            this.editProposalRegisterBtn.Click += new System.EventHandler(this.editProposalRegisterBtn_Click);
            // 
            // logTab
            // 
            this.logTab.GlobalItem = false;
            this.logTab.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.logTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.logTab.Name = "logTab";
            this.logTab.Text = "لاگ";
            // 
            // editProposalClearBtn
            // 
            this.editProposalClearBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.editProposalClearBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.editProposalClearBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalClearBtn.Location = new System.Drawing.Point(138, 262);
            this.editProposalClearBtn.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalClearBtn.Name = "editProposalClearBtn";
            this.editProposalClearBtn.Size = new System.Drawing.Size(94, 24);
            this.editProposalClearBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.editProposalClearBtn.TabIndex = 29;
            this.editProposalClearBtn.Text = "پاک کردن";
            this.editProposalClearBtn.Click += new System.EventHandler(this.editProposalClearBtn_Click);
            // 
            // editProposalShowGp
            // 
            this.editProposalShowGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.editProposalShowGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.editProposalShowGp.Controls.Add(this.manageProposalNavigationPanel);
            this.editProposalShowGp.Controls.Add(this.editProposalShowDgv);
            this.editProposalShowGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.editProposalShowGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.editProposalShowGp.Location = new System.Drawing.Point(14, 342);
            this.editProposalShowGp.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalShowGp.Name = "editProposalShowGp";
            this.editProposalShowGp.Size = new System.Drawing.Size(847, 284);
            // 
            // 
            // 
            this.editProposalShowGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.editProposalShowGp.Style.BackColorGradientAngle = 90;
            this.editProposalShowGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.editProposalShowGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.editProposalShowGp.Style.BorderBottomWidth = 2;
            this.editProposalShowGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.editProposalShowGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.editProposalShowGp.Style.BorderLeftWidth = 2;
            this.editProposalShowGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.editProposalShowGp.Style.BorderRightWidth = 2;
            this.editProposalShowGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.editProposalShowGp.Style.BorderTopWidth = 2;
            this.editProposalShowGp.Style.CornerDiameter = 10;
            this.editProposalShowGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.editProposalShowGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.editProposalShowGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.editProposalShowGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.editProposalShowGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.editProposalShowGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.editProposalShowGp.TabIndex = 1;
            this.editProposalShowGp.Text = "فهرست پروپوزال ها";
            this.editProposalShowGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageProposalNavigationPanel
            // 
            this.manageProposalNavigationPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.manageProposalNavigationPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.manageProposalNavigationPanel.Controls.Add(this.manageProposalNavigationCurrentPageTxtbx);
            this.manageProposalNavigationPanel.Controls.Add(this.manageProposalNavigationNextPageBtn);
            this.manageProposalNavigationPanel.Controls.Add(this.manageProposalNavigationLastPageBtn);
            this.manageProposalNavigationPanel.Controls.Add(this.buttonX4);
            this.manageProposalNavigationPanel.Controls.Add(this.manageProposalNavigationPreviousPageBtn);
            this.manageProposalNavigationPanel.Controls.Add(this.manageProposalNavigationFirstPageBtn);
            this.manageProposalNavigationPanel.Controls.Add(this.manageProposalNavigationReturnBtn);
            this.manageProposalNavigationPanel.Location = new System.Drawing.Point(98, 115);
            this.manageProposalNavigationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.manageProposalNavigationPanel.Name = "manageProposalNavigationPanel";
            this.manageProposalNavigationPanel.Size = new System.Drawing.Size(615, 33);
            this.manageProposalNavigationPanel.TabIndex = 3;
            // 
            // manageProposalNavigationCurrentPageTxtbx
            // 
            // 
            // 
            // 
            this.manageProposalNavigationCurrentPageTxtbx.Border.Class = "TextBoxBorder";
            this.manageProposalNavigationCurrentPageTxtbx.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.manageProposalNavigationCurrentPageTxtbx.Enabled = false;
            this.manageProposalNavigationCurrentPageTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageProposalNavigationCurrentPageTxtbx.Location = new System.Drawing.Point(271, 3);
            this.manageProposalNavigationCurrentPageTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.manageProposalNavigationCurrentPageTxtbx.MaxLength = 5;
            this.manageProposalNavigationCurrentPageTxtbx.Name = "manageProposalNavigationCurrentPageTxtbx";
            this.manageProposalNavigationCurrentPageTxtbx.PreventEnterBeep = true;
            this.manageProposalNavigationCurrentPageTxtbx.Size = new System.Drawing.Size(74, 25);
            this.manageProposalNavigationCurrentPageTxtbx.TabIndex = 34;
            this.manageProposalNavigationCurrentPageTxtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.manageProposalNavigationCurrentPageTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.manageProposalNavigationCurrentPageTxtbx_KeyPress);
            // 
            // manageProposalNavigationNextPageBtn
            // 
            this.manageProposalNavigationNextPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageProposalNavigationNextPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageProposalNavigationNextPageBtn.Enabled = false;
            this.manageProposalNavigationNextPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageProposalNavigationNextPageBtn.Location = new System.Drawing.Point(349, 3);
            this.manageProposalNavigationNextPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageProposalNavigationNextPageBtn.Name = "manageProposalNavigationNextPageBtn";
            this.manageProposalNavigationNextPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageProposalNavigationNextPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageProposalNavigationNextPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem6});
            this.manageProposalNavigationNextPageBtn.SubItemsExpandWidth = 0;
            this.manageProposalNavigationNextPageBtn.TabIndex = 33;
            this.manageProposalNavigationNextPageBtn.Text = "صفحه بعد";
            this.manageProposalNavigationNextPageBtn.Click += new System.EventHandler(this.manageProposalNavigationNextPageBtn_Click);
            // 
            // superTabItem6
            // 
            this.superTabItem6.GlobalItem = false;
            this.superTabItem6.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem6.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem6.Name = "superTabItem6";
            this.superTabItem6.Text = "لاگ";
            // 
            // manageProposalNavigationLastPageBtn
            // 
            this.manageProposalNavigationLastPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageProposalNavigationLastPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageProposalNavigationLastPageBtn.Enabled = false;
            this.manageProposalNavigationLastPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageProposalNavigationLastPageBtn.Location = new System.Drawing.Point(436, 3);
            this.manageProposalNavigationLastPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageProposalNavigationLastPageBtn.Name = "manageProposalNavigationLastPageBtn";
            this.manageProposalNavigationLastPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageProposalNavigationLastPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageProposalNavigationLastPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem5});
            this.manageProposalNavigationLastPageBtn.SubItemsExpandWidth = 0;
            this.manageProposalNavigationLastPageBtn.TabIndex = 32;
            this.manageProposalNavigationLastPageBtn.Text = "صفحه آخر";
            this.manageProposalNavigationLastPageBtn.Click += new System.EventHandler(this.manageProposalNavigationLastPageBtn_Click);
            // 
            // superTabItem5
            // 
            this.superTabItem5.GlobalItem = false;
            this.superTabItem5.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem5.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem5.Name = "superTabItem5";
            this.superTabItem5.Text = "لاگ";
            // 
            // buttonX4
            // 
            this.buttonX4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX4.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX4.Enabled = false;
            this.buttonX4.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.buttonX4.Location = new System.Drawing.Point(523, 3);
            this.buttonX4.Margin = new System.Windows.Forms.Padding(2);
            this.buttonX4.Name = "buttonX4";
            this.buttonX4.Size = new System.Drawing.Size(82, 24);
            this.buttonX4.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.buttonX4.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem4});
            this.buttonX4.SubItemsExpandWidth = 0;
            this.buttonX4.TabIndex = 31;
            this.buttonX4.Text = "ثبت تغییرات";
            // 
            // superTabItem4
            // 
            this.superTabItem4.GlobalItem = false;
            this.superTabItem4.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem4.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem4.Name = "superTabItem4";
            this.superTabItem4.Text = "لاگ";
            // 
            // manageProposalNavigationPreviousPageBtn
            // 
            this.manageProposalNavigationPreviousPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageProposalNavigationPreviousPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageProposalNavigationPreviousPageBtn.Enabled = false;
            this.manageProposalNavigationPreviousPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageProposalNavigationPreviousPageBtn.Location = new System.Drawing.Point(184, 3);
            this.manageProposalNavigationPreviousPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageProposalNavigationPreviousPageBtn.Name = "manageProposalNavigationPreviousPageBtn";
            this.manageProposalNavigationPreviousPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageProposalNavigationPreviousPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageProposalNavigationPreviousPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem3});
            this.manageProposalNavigationPreviousPageBtn.SubItemsExpandWidth = 0;
            this.manageProposalNavigationPreviousPageBtn.TabIndex = 30;
            this.manageProposalNavigationPreviousPageBtn.Text = "صفحه قبل";
            this.manageProposalNavigationPreviousPageBtn.Click += new System.EventHandler(this.manageProposalNavigationPreviousPageBtn_Click);
            // 
            // superTabItem3
            // 
            this.superTabItem3.GlobalItem = false;
            this.superTabItem3.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem3.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem3.Name = "superTabItem3";
            this.superTabItem3.Text = "لاگ";
            // 
            // manageProposalNavigationFirstPageBtn
            // 
            this.manageProposalNavigationFirstPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageProposalNavigationFirstPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageProposalNavigationFirstPageBtn.Enabled = false;
            this.manageProposalNavigationFirstPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageProposalNavigationFirstPageBtn.Location = new System.Drawing.Point(97, 3);
            this.manageProposalNavigationFirstPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageProposalNavigationFirstPageBtn.Name = "manageProposalNavigationFirstPageBtn";
            this.manageProposalNavigationFirstPageBtn.Size = new System.Drawing.Size(82, 24);
            this.manageProposalNavigationFirstPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageProposalNavigationFirstPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem2});
            this.manageProposalNavigationFirstPageBtn.SubItemsExpandWidth = 0;
            this.manageProposalNavigationFirstPageBtn.TabIndex = 29;
            this.manageProposalNavigationFirstPageBtn.Text = "صفحه اول";
            this.manageProposalNavigationFirstPageBtn.Click += new System.EventHandler(this.manageProposalNavigationFirstPageBtn_Click);
            // 
            // superTabItem2
            // 
            this.superTabItem2.GlobalItem = false;
            this.superTabItem2.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem2.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem2.Name = "superTabItem2";
            this.superTabItem2.Text = "لاگ";
            // 
            // manageProposalNavigationReturnBtn
            // 
            this.manageProposalNavigationReturnBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.manageProposalNavigationReturnBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.manageProposalNavigationReturnBtn.Enabled = false;
            this.manageProposalNavigationReturnBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.manageProposalNavigationReturnBtn.Location = new System.Drawing.Point(10, 3);
            this.manageProposalNavigationReturnBtn.Margin = new System.Windows.Forms.Padding(2);
            this.manageProposalNavigationReturnBtn.Name = "manageProposalNavigationReturnBtn";
            this.manageProposalNavigationReturnBtn.Size = new System.Drawing.Size(82, 24);
            this.manageProposalNavigationReturnBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.manageProposalNavigationReturnBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem1});
            this.manageProposalNavigationReturnBtn.SubItemsExpandWidth = 0;
            this.manageProposalNavigationReturnBtn.TabIndex = 28;
            this.manageProposalNavigationReturnBtn.Text = "بازگشت";
            this.manageProposalNavigationReturnBtn.Click += new System.EventHandler(this.manageProposalNavigationReturnBtn_Click);
            // 
            // superTabItem1
            // 
            this.superTabItem1.GlobalItem = false;
            this.superTabItem1.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem1.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem1.Name = "superTabItem1";
            this.superTabItem1.Text = "لاگ";
            // 
            // editProposalShowDgv
            // 
            this.editProposalShowDgv.AllowUserToAddRows = false;
            this.editProposalShowDgv.AllowUserToDeleteRows = false;
            this.editProposalShowDgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.editProposalShowDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.editProposalShowDgv.Location = new System.Drawing.Point(10, 4);
            this.editProposalShowDgv.Margin = new System.Windows.Forms.Padding(2);
            this.editProposalShowDgv.MultiSelect = false;
            this.editProposalShowDgv.Name = "editProposalShowDgv";
            this.editProposalShowDgv.ReadOnly = true;
            this.editProposalShowDgv.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.editProposalShowDgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.editProposalShowDgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(1);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(226)))), ((int)(((byte)(171)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.editProposalShowDgv.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.editProposalShowDgv.RowTemplate.Height = 24;
            this.editProposalShowDgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.editProposalShowDgv.Size = new System.Drawing.Size(806, 98);
            this.editProposalShowDgv.TabIndex = 2;
            this.editProposalShowDgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.editProposalShowDgv_CellClick);
            this.editProposalShowDgv.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // manageProposalTab
            // 
            this.manageProposalTab.AttachedControl = this.superTabControlPanel5;
            this.manageProposalTab.GlobalItem = false;
            this.manageProposalTab.Image = global::ProposalReportingSystem.Properties.Resources.file;
            this.manageProposalTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.manageProposalTab.Name = "manageProposalTab";
            this.manageProposalTab.Text = "مدیریت اطلاعات پروپوزال";
            // 
            // superTabControlPanel3
            // 
            this.superTabControlPanel3.Controls.Add(this.searchProposalPanel);
            this.superTabControlPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel3.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel3.Name = "superTabControlPanel3";
            this.superTabControlPanel3.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel3.TabIndex = 0;
            this.superTabControlPanel3.TabItem = this.searchProposalTab;
            // 
            // searchProposalPanel
            // 
            this.searchProposalPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.searchProposalPanel.Controls.Add(this.searchProposalShowGp);
            this.searchProposalPanel.Controls.Add(this.searchProposalSearchGp);
            this.searchProposalPanel.Location = new System.Drawing.Point(1, 2);
            this.searchProposalPanel.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalPanel.Name = "searchProposalPanel";
            this.searchProposalPanel.Size = new System.Drawing.Size(887, 655);
            this.searchProposalPanel.TabIndex = 2;
            this.searchProposalPanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalShowGp
            // 
            this.searchProposalShowGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.searchProposalShowGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.searchProposalShowGp.Controls.Add(this.searchProposalNavigationPanel);
            this.searchProposalShowGp.Controls.Add(this.searchProposalShowDgv);
            this.searchProposalShowGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.searchProposalShowGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalShowGp.Location = new System.Drawing.Point(14, 340);
            this.searchProposalShowGp.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalShowGp.Name = "searchProposalShowGp";
            this.searchProposalShowGp.Size = new System.Drawing.Size(847, 269);
            // 
            // 
            // 
            this.searchProposalShowGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.searchProposalShowGp.Style.BackColorGradientAngle = 90;
            this.searchProposalShowGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.searchProposalShowGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalShowGp.Style.BorderBottomWidth = 2;
            this.searchProposalShowGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.searchProposalShowGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalShowGp.Style.BorderLeftWidth = 2;
            this.searchProposalShowGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalShowGp.Style.BorderRightWidth = 2;
            this.searchProposalShowGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalShowGp.Style.BorderTopWidth = 2;
            this.searchProposalShowGp.Style.CornerDiameter = 10;
            this.searchProposalShowGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.searchProposalShowGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.searchProposalShowGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.searchProposalShowGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.searchProposalShowGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.searchProposalShowGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.searchProposalShowGp.TabIndex = 1;
            this.searchProposalShowGp.Text = "فهرست پروپوزال ها";
            this.searchProposalShowGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalNavigationPanel
            // 
            this.searchProposalNavigationPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.searchProposalNavigationPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.searchProposalNavigationPanel.Controls.Add(this.searchProposalNavigationCurrentPageTxtbx);
            this.searchProposalNavigationPanel.Controls.Add(this.searchProposalNavigationNextPageBtn);
            this.searchProposalNavigationPanel.Controls.Add(this.searchProposalNavigationLastPageBtn);
            this.searchProposalNavigationPanel.Controls.Add(this.searchProposalNavigationPreviousPageBtn);
            this.searchProposalNavigationPanel.Controls.Add(this.searchProposalNavigationFirstPageBtn);
            this.searchProposalNavigationPanel.Controls.Add(this.searchProposalNavigationReturnBtn);
            this.searchProposalNavigationPanel.Location = new System.Drawing.Point(115, 131);
            this.searchProposalNavigationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalNavigationPanel.Name = "searchProposalNavigationPanel";
            this.searchProposalNavigationPanel.Size = new System.Drawing.Size(615, 33);
            this.searchProposalNavigationPanel.TabIndex = 5;
            // 
            // searchProposalNavigationCurrentPageTxtbx
            // 
            // 
            // 
            // 
            this.searchProposalNavigationCurrentPageTxtbx.Border.Class = "TextBoxBorder";
            this.searchProposalNavigationCurrentPageTxtbx.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.searchProposalNavigationCurrentPageTxtbx.Enabled = false;
            this.searchProposalNavigationCurrentPageTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalNavigationCurrentPageTxtbx.Location = new System.Drawing.Point(271, 3);
            this.searchProposalNavigationCurrentPageTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalNavigationCurrentPageTxtbx.MaxLength = 5;
            this.searchProposalNavigationCurrentPageTxtbx.Name = "searchProposalNavigationCurrentPageTxtbx";
            this.searchProposalNavigationCurrentPageTxtbx.PreventEnterBeep = true;
            this.searchProposalNavigationCurrentPageTxtbx.Size = new System.Drawing.Size(74, 25);
            this.searchProposalNavigationCurrentPageTxtbx.TabIndex = 34;
            this.searchProposalNavigationCurrentPageTxtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.searchProposalNavigationCurrentPageTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.searchProposalNavigationCurrentPageTxtbx_KeyPress);
            // 
            // searchProposalNavigationNextPageBtn
            // 
            this.searchProposalNavigationNextPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.searchProposalNavigationNextPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.searchProposalNavigationNextPageBtn.Enabled = false;
            this.searchProposalNavigationNextPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalNavigationNextPageBtn.Location = new System.Drawing.Point(349, 3);
            this.searchProposalNavigationNextPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalNavigationNextPageBtn.Name = "searchProposalNavigationNextPageBtn";
            this.searchProposalNavigationNextPageBtn.Size = new System.Drawing.Size(82, 24);
            this.searchProposalNavigationNextPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.searchProposalNavigationNextPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem14});
            this.searchProposalNavigationNextPageBtn.SubItemsExpandWidth = 0;
            this.searchProposalNavigationNextPageBtn.TabIndex = 33;
            this.searchProposalNavigationNextPageBtn.Text = "صفحه بعد";
            this.searchProposalNavigationNextPageBtn.Click += new System.EventHandler(this.searchProposalNavigationNextPageBtn_Click);
            // 
            // superTabItem14
            // 
            this.superTabItem14.GlobalItem = false;
            this.superTabItem14.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem14.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem14.Name = "superTabItem14";
            this.superTabItem14.Text = "لاگ";
            // 
            // searchProposalNavigationLastPageBtn
            // 
            this.searchProposalNavigationLastPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.searchProposalNavigationLastPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.searchProposalNavigationLastPageBtn.Enabled = false;
            this.searchProposalNavigationLastPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalNavigationLastPageBtn.Location = new System.Drawing.Point(436, 3);
            this.searchProposalNavigationLastPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalNavigationLastPageBtn.Name = "searchProposalNavigationLastPageBtn";
            this.searchProposalNavigationLastPageBtn.Size = new System.Drawing.Size(82, 24);
            this.searchProposalNavigationLastPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.searchProposalNavigationLastPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem15});
            this.searchProposalNavigationLastPageBtn.SubItemsExpandWidth = 0;
            this.searchProposalNavigationLastPageBtn.TabIndex = 32;
            this.searchProposalNavigationLastPageBtn.Text = "صفحه آخر";
            this.searchProposalNavigationLastPageBtn.Click += new System.EventHandler(this.searchProposalNavigationLastPageBtn_Click);
            // 
            // superTabItem15
            // 
            this.superTabItem15.GlobalItem = false;
            this.superTabItem15.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem15.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem15.Name = "superTabItem15";
            this.superTabItem15.Text = "لاگ";
            // 
            // searchProposalNavigationPreviousPageBtn
            // 
            this.searchProposalNavigationPreviousPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.searchProposalNavigationPreviousPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.searchProposalNavigationPreviousPageBtn.Enabled = false;
            this.searchProposalNavigationPreviousPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalNavigationPreviousPageBtn.Location = new System.Drawing.Point(184, 3);
            this.searchProposalNavigationPreviousPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalNavigationPreviousPageBtn.Name = "searchProposalNavigationPreviousPageBtn";
            this.searchProposalNavigationPreviousPageBtn.Size = new System.Drawing.Size(82, 24);
            this.searchProposalNavigationPreviousPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.searchProposalNavigationPreviousPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem17});
            this.searchProposalNavigationPreviousPageBtn.SubItemsExpandWidth = 0;
            this.searchProposalNavigationPreviousPageBtn.TabIndex = 30;
            this.searchProposalNavigationPreviousPageBtn.Text = "صفحه قبل";
            this.searchProposalNavigationPreviousPageBtn.Click += new System.EventHandler(this.searchProposalNavigationPreviousPageBtn_Click);
            // 
            // superTabItem17
            // 
            this.superTabItem17.GlobalItem = false;
            this.superTabItem17.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem17.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem17.Name = "superTabItem17";
            this.superTabItem17.Text = "لاگ";
            // 
            // searchProposalNavigationFirstPageBtn
            // 
            this.searchProposalNavigationFirstPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.searchProposalNavigationFirstPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.searchProposalNavigationFirstPageBtn.Enabled = false;
            this.searchProposalNavigationFirstPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalNavigationFirstPageBtn.Location = new System.Drawing.Point(97, 3);
            this.searchProposalNavigationFirstPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalNavigationFirstPageBtn.Name = "searchProposalNavigationFirstPageBtn";
            this.searchProposalNavigationFirstPageBtn.Size = new System.Drawing.Size(82, 24);
            this.searchProposalNavigationFirstPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.searchProposalNavigationFirstPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem18});
            this.searchProposalNavigationFirstPageBtn.SubItemsExpandWidth = 0;
            this.searchProposalNavigationFirstPageBtn.TabIndex = 29;
            this.searchProposalNavigationFirstPageBtn.Text = "صفحه اول";
            this.searchProposalNavigationFirstPageBtn.Click += new System.EventHandler(this.searchProposalNavigationFirstPageBtn_Click);
            // 
            // superTabItem18
            // 
            this.superTabItem18.GlobalItem = false;
            this.superTabItem18.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem18.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem18.Name = "superTabItem18";
            this.superTabItem18.Text = "لاگ";
            // 
            // searchProposalNavigationReturnBtn
            // 
            this.searchProposalNavigationReturnBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.searchProposalNavigationReturnBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.searchProposalNavigationReturnBtn.Enabled = false;
            this.searchProposalNavigationReturnBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalNavigationReturnBtn.Location = new System.Drawing.Point(10, 3);
            this.searchProposalNavigationReturnBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalNavigationReturnBtn.Name = "searchProposalNavigationReturnBtn";
            this.searchProposalNavigationReturnBtn.Size = new System.Drawing.Size(82, 24);
            this.searchProposalNavigationReturnBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.searchProposalNavigationReturnBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem19});
            this.searchProposalNavigationReturnBtn.SubItemsExpandWidth = 0;
            this.searchProposalNavigationReturnBtn.TabIndex = 28;
            this.searchProposalNavigationReturnBtn.Text = "بازگشت";
            this.searchProposalNavigationReturnBtn.Click += new System.EventHandler(this.searchProposalNavigationReturnBtn_Click);
            // 
            // superTabItem19
            // 
            this.superTabItem19.GlobalItem = false;
            this.superTabItem19.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem19.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem19.Name = "superTabItem19";
            this.superTabItem19.Text = "لاگ";
            // 
            // searchProposalShowDgv
            // 
            this.searchProposalShowDgv.AllowUserToAddRows = false;
            this.searchProposalShowDgv.AllowUserToDeleteRows = false;
            this.searchProposalShowDgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.searchProposalShowDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.searchProposalShowDgv.Location = new System.Drawing.Point(16, 9);
            this.searchProposalShowDgv.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalShowDgv.MultiSelect = false;
            this.searchProposalShowDgv.Name = "searchProposalShowDgv";
            this.searchProposalShowDgv.ReadOnly = true;
            this.searchProposalShowDgv.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalShowDgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.searchProposalShowDgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Padding = new System.Windows.Forms.Padding(1);
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(226)))), ((int)(((byte)(171)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.searchProposalShowDgv.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.searchProposalShowDgv.RowTemplate.Height = 24;
            this.searchProposalShowDgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.searchProposalShowDgv.Size = new System.Drawing.Size(806, 111);
            this.searchProposalShowDgv.TabIndex = 2;
            this.searchProposalShowDgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.searchProposalShowDgv_CellClick);
            this.searchProposalShowDgv.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalSearchGp
            // 
            this.searchProposalSearchGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.searchProposalSearchGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.searchProposalSearchGp.Controls.Add(this.searchProposalShowAllBtn);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalStartDateToTimeInput);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorEGroupCb);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorFacultyCb);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalStartDateToChbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalStartDateFromChbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalStartDateFromTimeInput);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalValueToTxtbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalValueToLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalStartDateToLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalOrganizationNumberCb);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalStatusCb);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalOrganizationNameCb);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalTypeCb);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalRegisterTypeCb);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalPropertyTypeCb);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalProcedureTypeCb);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorMobileTxtbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorMobileLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorEGroupLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorFacultyLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorLNameLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorLNameTxtbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorFNameLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorFNameTxtbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalValueFromTxtbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalValueFromLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalOrganizationLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalStatusLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalTypeLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalRegisterTypeLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalPropertyTypeLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalProcedureTypeLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalStartDateFromLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorNCodeLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalEnglishTitleLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalPersianTitleLbl);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorNCodeTxtbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalEnglishTitleTxtbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalPersianTitleTxtbx);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalSearchBtn);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalClearBtn);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalExecutorInfoGp);
            this.searchProposalSearchGp.Controls.Add(this.searchProposalProposalInfoGp);
            this.searchProposalSearchGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.searchProposalSearchGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalSearchGp.Location = new System.Drawing.Point(14, 15);
            this.searchProposalSearchGp.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalSearchGp.Name = "searchProposalSearchGp";
            this.searchProposalSearchGp.Size = new System.Drawing.Size(847, 311);
            // 
            // 
            // 
            this.searchProposalSearchGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.searchProposalSearchGp.Style.BackColorGradientAngle = 90;
            this.searchProposalSearchGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.searchProposalSearchGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalSearchGp.Style.BorderBottomWidth = 2;
            this.searchProposalSearchGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.searchProposalSearchGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalSearchGp.Style.BorderLeftWidth = 2;
            this.searchProposalSearchGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalSearchGp.Style.BorderRightWidth = 2;
            this.searchProposalSearchGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalSearchGp.Style.BorderTopWidth = 2;
            this.searchProposalSearchGp.Style.CornerDiameter = 10;
            this.searchProposalSearchGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.searchProposalSearchGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.searchProposalSearchGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.searchProposalSearchGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.searchProposalSearchGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.searchProposalSearchGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.searchProposalSearchGp.TabIndex = 0;
            this.searchProposalSearchGp.Text = "جستجوی اطلاعات";
            this.searchProposalSearchGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalShowAllBtn
            // 
            this.searchProposalShowAllBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.searchProposalShowAllBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.searchProposalShowAllBtn.Location = new System.Drawing.Point(320, 249);
            this.searchProposalShowAllBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalShowAllBtn.Name = "searchProposalShowAllBtn";
            this.searchProposalShowAllBtn.Size = new System.Drawing.Size(94, 24);
            this.searchProposalShowAllBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.searchProposalShowAllBtn.TabIndex = 22;
            this.searchProposalShowAllBtn.Text = "نمایش همه";
            this.searchProposalShowAllBtn.Click += new System.EventHandler(this.searchProposalShowAllBtn_Click);
            // 
            // searchProposalStartDateToTimeInput
            // 
            this.searchProposalStartDateToTimeInput.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalStartDateToTimeInput.Enabled = false;
            this.searchProposalStartDateToTimeInput.GeoDate = new System.DateTime(2016, 11, 28, 0, 0, 0, 0);
            this.searchProposalStartDateToTimeInput.Location = new System.Drawing.Point(338, 126);
            this.searchProposalStartDateToTimeInput.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.searchProposalStartDateToTimeInput.MaximumSize = new System.Drawing.Size(1602, 63);
            this.searchProposalStartDateToTimeInput.Name = "searchProposalStartDateToTimeInput";
            this.searchProposalStartDateToTimeInput.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.searchProposalStartDateToTimeInput.Size = new System.Drawing.Size(138, 24);
            this.searchProposalStartDateToTimeInput.TabIndex = 10;
            // 
            // searchProposalExecutorEGroupCb
            // 
            this.searchProposalExecutorEGroupCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchProposalExecutorEGroupCb.FormattingEnabled = true;
            this.searchProposalExecutorEGroupCb.Location = new System.Drawing.Point(591, 161);
            this.searchProposalExecutorEGroupCb.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalExecutorEGroupCb.Name = "searchProposalExecutorEGroupCb";
            this.searchProposalExecutorEGroupCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalExecutorEGroupCb.Size = new System.Drawing.Size(139, 25);
            this.searchProposalExecutorEGroupCb.TabIndex = 5;
            // 
            // searchProposalExecutorFacultyCb
            // 
            this.searchProposalExecutorFacultyCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchProposalExecutorFacultyCb.FormattingEnabled = true;
            this.searchProposalExecutorFacultyCb.Location = new System.Drawing.Point(591, 132);
            this.searchProposalExecutorFacultyCb.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalExecutorFacultyCb.Name = "searchProposalExecutorFacultyCb";
            this.searchProposalExecutorFacultyCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalExecutorFacultyCb.Size = new System.Drawing.Size(139, 25);
            this.searchProposalExecutorFacultyCb.TabIndex = 4;
            this.searchProposalExecutorFacultyCb.SelectedIndexChanged += new System.EventHandler(this.searchProposalExecutorFacultyCb_SelectedIndexChanged);
            // 
            // searchProposalStartDateToChbx
            // 
            this.searchProposalStartDateToChbx.AutoSize = true;
            this.searchProposalStartDateToChbx.Location = new System.Drawing.Point(320, 129);
            this.searchProposalStartDateToChbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalStartDateToChbx.Name = "searchProposalStartDateToChbx";
            this.searchProposalStartDateToChbx.Size = new System.Drawing.Size(15, 14);
            this.searchProposalStartDateToChbx.TabIndex = 72;
            this.searchProposalStartDateToChbx.UseVisualStyleBackColor = true;
            this.searchProposalStartDateToChbx.CheckedChanged += new System.EventHandler(this.searchProposalStartDateToChbx_CheckedChanged);
            // 
            // searchProposalStartDateFromChbx
            // 
            this.searchProposalStartDateFromChbx.AutoSize = true;
            this.searchProposalStartDateFromChbx.Location = new System.Drawing.Point(320, 100);
            this.searchProposalStartDateFromChbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalStartDateFromChbx.Name = "searchProposalStartDateFromChbx";
            this.searchProposalStartDateFromChbx.Size = new System.Drawing.Size(15, 14);
            this.searchProposalStartDateFromChbx.TabIndex = 71;
            this.searchProposalStartDateFromChbx.UseVisualStyleBackColor = true;
            this.searchProposalStartDateFromChbx.CheckedChanged += new System.EventHandler(this.searchProposalStartDateFromChbx_CheckedChanged);
            // 
            // searchProposalStartDateFromTimeInput
            // 
            this.searchProposalStartDateFromTimeInput.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalStartDateFromTimeInput.Enabled = false;
            this.searchProposalStartDateFromTimeInput.GeoDate = new System.DateTime(2016, 11, 28, 0, 0, 0, 0);
            this.searchProposalStartDateFromTimeInput.Location = new System.Drawing.Point(338, 97);
            this.searchProposalStartDateFromTimeInput.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.searchProposalStartDateFromTimeInput.MaximumSize = new System.Drawing.Size(1125, 28);
            this.searchProposalStartDateFromTimeInput.Name = "searchProposalStartDateFromTimeInput";
            this.searchProposalStartDateFromTimeInput.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.searchProposalStartDateFromTimeInput.Size = new System.Drawing.Size(138, 26);
            this.searchProposalStartDateFromTimeInput.TabIndex = 9;
            // 
            // searchProposalValueToTxtbx
            // 
            this.searchProposalValueToTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchProposalValueToTxtbx.Location = new System.Drawing.Point(338, 180);
            this.searchProposalValueToTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalValueToTxtbx.MaxLength = 20;
            this.searchProposalValueToTxtbx.Name = "searchProposalValueToTxtbx";
            this.searchProposalValueToTxtbx.Size = new System.Drawing.Size(138, 25);
            this.searchProposalValueToTxtbx.TabIndex = 12;
            this.searchProposalValueToTxtbx.TextChanged += new System.EventHandler(this.searchProposalValueToTxtbx_TextChanged_1);
            this.searchProposalValueToTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.searchProposalExecutorNCodeTxtbx_KeyPress);
            // 
            // searchProposalValueToLbl
            // 
            this.searchProposalValueToLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalValueToLbl.Location = new System.Drawing.Point(480, 180);
            this.searchProposalValueToLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalValueToLbl.Name = "searchProposalValueToLbl";
            this.searchProposalValueToLbl.Size = new System.Drawing.Size(74, 20);
            this.searchProposalValueToLbl.TabIndex = 63;
            this.searchProposalValueToLbl.Text = "تا مبلغ";
            this.searchProposalValueToLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalStartDateToLbl
            // 
            this.searchProposalStartDateToLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalStartDateToLbl.Location = new System.Drawing.Point(482, 126);
            this.searchProposalStartDateToLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalStartDateToLbl.Name = "searchProposalStartDateToLbl";
            this.searchProposalStartDateToLbl.Size = new System.Drawing.Size(73, 20);
            this.searchProposalStartDateToLbl.TabIndex = 62;
            this.searchProposalStartDateToLbl.Text = "تا تاریخ";
            this.searchProposalStartDateToLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalOrganizationNumberCb
            // 
            this.searchProposalOrganizationNumberCb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.searchProposalOrganizationNumberCb.FormattingEnabled = true;
            this.searchProposalOrganizationNumberCb.Location = new System.Drawing.Point(182, 158);
            this.searchProposalOrganizationNumberCb.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalOrganizationNumberCb.Name = "searchProposalOrganizationNumberCb";
            this.searchProposalOrganizationNumberCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalOrganizationNumberCb.Size = new System.Drawing.Size(40, 25);
            this.searchProposalOrganizationNumberCb.TabIndex = 17;
            this.searchProposalOrganizationNumberCb.SelectedIndexChanged += new System.EventHandler(this.searchProposalOrganizationNumberCb_SelectedIndexChanged);
            this.searchProposalOrganizationNumberCb.TextChanged += new System.EventHandler(this.searchProposalOrganizationNumberCb_TextChanged);
            this.searchProposalOrganizationNumberCb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.searchProposalExecutorNCodeTxtbx_KeyPress);
            // 
            // searchProposalStatusCb
            // 
            this.searchProposalStatusCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchProposalStatusCb.FormattingEnabled = true;
            this.searchProposalStatusCb.Location = new System.Drawing.Point(83, 187);
            this.searchProposalStatusCb.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalStatusCb.Name = "searchProposalStatusCb";
            this.searchProposalStatusCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalStatusCb.Size = new System.Drawing.Size(138, 25);
            this.searchProposalStatusCb.TabIndex = 19;
            // 
            // searchProposalOrganizationNameCb
            // 
            this.searchProposalOrganizationNameCb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.searchProposalOrganizationNameCb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.searchProposalOrganizationNameCb.FormattingEnabled = true;
            this.searchProposalOrganizationNameCb.Location = new System.Drawing.Point(83, 158);
            this.searchProposalOrganizationNameCb.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalOrganizationNameCb.Name = "searchProposalOrganizationNameCb";
            this.searchProposalOrganizationNameCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalOrganizationNameCb.Size = new System.Drawing.Size(96, 25);
            this.searchProposalOrganizationNameCb.TabIndex = 18;
            this.searchProposalOrganizationNameCb.SelectedIndexChanged += new System.EventHandler(this.searchProposalOrganizationNameCb_SelectedIndexChanged);
            this.searchProposalOrganizationNameCb.TextChanged += new System.EventHandler(this.searchProposalOrganizationNameCb_TextChanged);
            // 
            // searchProposalTypeCb
            // 
            this.searchProposalTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchProposalTypeCb.FormattingEnabled = true;
            this.searchProposalTypeCb.Location = new System.Drawing.Point(83, 127);
            this.searchProposalTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalTypeCb.Name = "searchProposalTypeCb";
            this.searchProposalTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalTypeCb.Size = new System.Drawing.Size(139, 25);
            this.searchProposalTypeCb.TabIndex = 16;
            // 
            // searchProposalRegisterTypeCb
            // 
            this.searchProposalRegisterTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchProposalRegisterTypeCb.FormattingEnabled = true;
            this.searchProposalRegisterTypeCb.Location = new System.Drawing.Point(83, 97);
            this.searchProposalRegisterTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalRegisterTypeCb.Name = "searchProposalRegisterTypeCb";
            this.searchProposalRegisterTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalRegisterTypeCb.Size = new System.Drawing.Size(139, 25);
            this.searchProposalRegisterTypeCb.TabIndex = 15;
            // 
            // searchProposalPropertyTypeCb
            // 
            this.searchProposalPropertyTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchProposalPropertyTypeCb.FormattingEnabled = true;
            this.searchProposalPropertyTypeCb.Location = new System.Drawing.Point(83, 64);
            this.searchProposalPropertyTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalPropertyTypeCb.Name = "searchProposalPropertyTypeCb";
            this.searchProposalPropertyTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalPropertyTypeCb.Size = new System.Drawing.Size(139, 25);
            this.searchProposalPropertyTypeCb.TabIndex = 14;
            // 
            // searchProposalProcedureTypeCb
            // 
            this.searchProposalProcedureTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchProposalProcedureTypeCb.FormattingEnabled = true;
            this.searchProposalProcedureTypeCb.Location = new System.Drawing.Point(83, 35);
            this.searchProposalProcedureTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalProcedureTypeCb.Name = "searchProposalProcedureTypeCb";
            this.searchProposalProcedureTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalProcedureTypeCb.Size = new System.Drawing.Size(139, 25);
            this.searchProposalProcedureTypeCb.TabIndex = 13;
            // 
            // searchProposalExecutorMobileTxtbx
            // 
            this.searchProposalExecutorMobileTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchProposalExecutorMobileTxtbx.Location = new System.Drawing.Point(591, 189);
            this.searchProposalExecutorMobileTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalExecutorMobileTxtbx.MaxLength = 20;
            this.searchProposalExecutorMobileTxtbx.Name = "searchProposalExecutorMobileTxtbx";
            this.searchProposalExecutorMobileTxtbx.Size = new System.Drawing.Size(138, 25);
            this.searchProposalExecutorMobileTxtbx.TabIndex = 6;
            this.searchProposalExecutorMobileTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.searchProposalExecutorNCodeTxtbx_KeyPress);
            // 
            // searchProposalExecutorMobileLbl
            // 
            this.searchProposalExecutorMobileLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalExecutorMobileLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalExecutorMobileLbl.Location = new System.Drawing.Point(736, 189);
            this.searchProposalExecutorMobileLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalExecutorMobileLbl.Name = "searchProposalExecutorMobileLbl";
            this.searchProposalExecutorMobileLbl.Size = new System.Drawing.Size(73, 20);
            this.searchProposalExecutorMobileLbl.TabIndex = 40;
            this.searchProposalExecutorMobileLbl.Text = "شماره همراه";
            this.searchProposalExecutorMobileLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.searchProposalExecutorMobileLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalExecutorEGroupLbl
            // 
            this.searchProposalExecutorEGroupLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalExecutorEGroupLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalExecutorEGroupLbl.Location = new System.Drawing.Point(736, 161);
            this.searchProposalExecutorEGroupLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalExecutorEGroupLbl.Name = "searchProposalExecutorEGroupLbl";
            this.searchProposalExecutorEGroupLbl.Size = new System.Drawing.Size(73, 20);
            this.searchProposalExecutorEGroupLbl.TabIndex = 48;
            this.searchProposalExecutorEGroupLbl.Text = "گروه آموزشی";
            this.searchProposalExecutorEGroupLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.searchProposalExecutorEGroupLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalExecutorFacultyLbl
            // 
            this.searchProposalExecutorFacultyLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalExecutorFacultyLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalExecutorFacultyLbl.Location = new System.Drawing.Point(736, 132);
            this.searchProposalExecutorFacultyLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalExecutorFacultyLbl.Name = "searchProposalExecutorFacultyLbl";
            this.searchProposalExecutorFacultyLbl.Size = new System.Drawing.Size(73, 20);
            this.searchProposalExecutorFacultyLbl.TabIndex = 46;
            this.searchProposalExecutorFacultyLbl.Text = "دانشکده";
            this.searchProposalExecutorFacultyLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.searchProposalExecutorFacultyLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalExecutorLNameLbl
            // 
            this.searchProposalExecutorLNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalExecutorLNameLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalExecutorLNameLbl.Location = new System.Drawing.Point(736, 102);
            this.searchProposalExecutorLNameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalExecutorLNameLbl.Name = "searchProposalExecutorLNameLbl";
            this.searchProposalExecutorLNameLbl.Size = new System.Drawing.Size(73, 20);
            this.searchProposalExecutorLNameLbl.TabIndex = 36;
            this.searchProposalExecutorLNameLbl.Text = "نام خانوادگی";
            this.searchProposalExecutorLNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.searchProposalExecutorLNameLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalExecutorLNameTxtbx
            // 
            this.searchProposalExecutorLNameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchProposalExecutorLNameTxtbx.Location = new System.Drawing.Point(591, 102);
            this.searchProposalExecutorLNameTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalExecutorLNameTxtbx.MaxLength = 100;
            this.searchProposalExecutorLNameTxtbx.Name = "searchProposalExecutorLNameTxtbx";
            this.searchProposalExecutorLNameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalExecutorLNameTxtbx.Size = new System.Drawing.Size(138, 25);
            this.searchProposalExecutorLNameTxtbx.TabIndex = 3;
            // 
            // searchProposalExecutorFNameLbl
            // 
            this.searchProposalExecutorFNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalExecutorFNameLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalExecutorFNameLbl.Location = new System.Drawing.Point(736, 73);
            this.searchProposalExecutorFNameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalExecutorFNameLbl.Name = "searchProposalExecutorFNameLbl";
            this.searchProposalExecutorFNameLbl.Size = new System.Drawing.Size(73, 20);
            this.searchProposalExecutorFNameLbl.TabIndex = 34;
            this.searchProposalExecutorFNameLbl.Text = "نام";
            this.searchProposalExecutorFNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.searchProposalExecutorFNameLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalExecutorFNameTxtbx
            // 
            this.searchProposalExecutorFNameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchProposalExecutorFNameTxtbx.Location = new System.Drawing.Point(591, 73);
            this.searchProposalExecutorFNameTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalExecutorFNameTxtbx.MaxLength = 100;
            this.searchProposalExecutorFNameTxtbx.Name = "searchProposalExecutorFNameTxtbx";
            this.searchProposalExecutorFNameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalExecutorFNameTxtbx.Size = new System.Drawing.Size(138, 25);
            this.searchProposalExecutorFNameTxtbx.TabIndex = 2;
            // 
            // searchProposalValueFromTxtbx
            // 
            this.searchProposalValueFromTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchProposalValueFromTxtbx.Location = new System.Drawing.Point(338, 152);
            this.searchProposalValueFromTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalValueFromTxtbx.MaxLength = 20;
            this.searchProposalValueFromTxtbx.Name = "searchProposalValueFromTxtbx";
            this.searchProposalValueFromTxtbx.Size = new System.Drawing.Size(138, 25);
            this.searchProposalValueFromTxtbx.TabIndex = 11;
            this.searchProposalValueFromTxtbx.TextChanged += new System.EventHandler(this.searchProposalValueFromTxtbx_TextChanged_1);
            this.searchProposalValueFromTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.searchProposalExecutorNCodeTxtbx_KeyPress);
            // 
            // searchProposalValueFromLbl
            // 
            this.searchProposalValueFromLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalValueFromLbl.Location = new System.Drawing.Point(480, 152);
            this.searchProposalValueFromLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalValueFromLbl.Name = "searchProposalValueFromLbl";
            this.searchProposalValueFromLbl.Size = new System.Drawing.Size(74, 20);
            this.searchProposalValueFromLbl.TabIndex = 29;
            this.searchProposalValueFromLbl.Text = "از مبلغ";
            this.searchProposalValueFromLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalOrganizationLbl
            // 
            this.searchProposalOrganizationLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalOrganizationLbl.Location = new System.Drawing.Point(226, 159);
            this.searchProposalOrganizationLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalOrganizationLbl.Name = "searchProposalOrganizationLbl";
            this.searchProposalOrganizationLbl.Size = new System.Drawing.Size(74, 20);
            this.searchProposalOrganizationLbl.TabIndex = 27;
            this.searchProposalOrganizationLbl.Text = "سازمان کارفرما";
            this.searchProposalOrganizationLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalStatusLbl
            // 
            this.searchProposalStatusLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalStatusLbl.Location = new System.Drawing.Point(226, 184);
            this.searchProposalStatusLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalStatusLbl.Name = "searchProposalStatusLbl";
            this.searchProposalStatusLbl.Size = new System.Drawing.Size(74, 20);
            this.searchProposalStatusLbl.TabIndex = 25;
            this.searchProposalStatusLbl.Text = "وضعیت";
            this.searchProposalStatusLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalTypeLbl
            // 
            this.searchProposalTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalTypeLbl.Location = new System.Drawing.Point(226, 130);
            this.searchProposalTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalTypeLbl.Name = "searchProposalTypeLbl";
            this.searchProposalTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.searchProposalTypeLbl.TabIndex = 23;
            this.searchProposalTypeLbl.Text = "نوع پروپوزال";
            this.searchProposalTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalRegisterTypeLbl
            // 
            this.searchProposalRegisterTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalRegisterTypeLbl.Location = new System.Drawing.Point(226, 98);
            this.searchProposalRegisterTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalRegisterTypeLbl.Name = "searchProposalRegisterTypeLbl";
            this.searchProposalRegisterTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.searchProposalRegisterTypeLbl.TabIndex = 21;
            this.searchProposalRegisterTypeLbl.Text = "نوع ثبت";
            this.searchProposalRegisterTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalPropertyTypeLbl
            // 
            this.searchProposalPropertyTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalPropertyTypeLbl.Location = new System.Drawing.Point(226, 63);
            this.searchProposalPropertyTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalPropertyTypeLbl.Name = "searchProposalPropertyTypeLbl";
            this.searchProposalPropertyTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.searchProposalPropertyTypeLbl.TabIndex = 19;
            this.searchProposalPropertyTypeLbl.Text = "خاصیت";
            this.searchProposalPropertyTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalProcedureTypeLbl
            // 
            this.searchProposalProcedureTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalProcedureTypeLbl.Location = new System.Drawing.Point(226, 30);
            this.searchProposalProcedureTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalProcedureTypeLbl.Name = "searchProposalProcedureTypeLbl";
            this.searchProposalProcedureTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.searchProposalProcedureTypeLbl.TabIndex = 17;
            this.searchProposalProcedureTypeLbl.Text = "نوع کار";
            this.searchProposalProcedureTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalStartDateFromLbl
            // 
            this.searchProposalStartDateFromLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalStartDateFromLbl.Location = new System.Drawing.Point(483, 97);
            this.searchProposalStartDateFromLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalStartDateFromLbl.Name = "searchProposalStartDateFromLbl";
            this.searchProposalStartDateFromLbl.Size = new System.Drawing.Size(73, 20);
            this.searchProposalStartDateFromLbl.TabIndex = 13;
            this.searchProposalStartDateFromLbl.Text = "از تاریخ";
            this.searchProposalStartDateFromLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalExecutorNCodeLbl
            // 
            this.searchProposalExecutorNCodeLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalExecutorNCodeLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalExecutorNCodeLbl.Location = new System.Drawing.Point(736, 44);
            this.searchProposalExecutorNCodeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalExecutorNCodeLbl.Name = "searchProposalExecutorNCodeLbl";
            this.searchProposalExecutorNCodeLbl.Size = new System.Drawing.Size(73, 20);
            this.searchProposalExecutorNCodeLbl.TabIndex = 8;
            this.searchProposalExecutorNCodeLbl.Text = "کدملی مجری";
            this.searchProposalExecutorNCodeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.searchProposalExecutorNCodeLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalEnglishTitleLbl
            // 
            this.searchProposalEnglishTitleLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalEnglishTitleLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalEnglishTitleLbl.Location = new System.Drawing.Point(480, 69);
            this.searchProposalEnglishTitleLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalEnglishTitleLbl.Name = "searchProposalEnglishTitleLbl";
            this.searchProposalEnglishTitleLbl.Size = new System.Drawing.Size(74, 20);
            this.searchProposalEnglishTitleLbl.TabIndex = 6;
            this.searchProposalEnglishTitleLbl.Text = "عنوان لاتین";
            this.searchProposalEnglishTitleLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalPersianTitleLbl
            // 
            this.searchProposalPersianTitleLbl.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalPersianTitleLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.searchProposalPersianTitleLbl.Location = new System.Drawing.Point(480, 41);
            this.searchProposalPersianTitleLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchProposalPersianTitleLbl.Name = "searchProposalPersianTitleLbl";
            this.searchProposalPersianTitleLbl.Size = new System.Drawing.Size(73, 22);
            this.searchProposalPersianTitleLbl.TabIndex = 5;
            this.searchProposalPersianTitleLbl.Text = "عنوان فارسی";
            this.searchProposalPersianTitleLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchProposalExecutorNCodeTxtbx
            // 
            this.searchProposalExecutorNCodeTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchProposalExecutorNCodeTxtbx.Location = new System.Drawing.Point(591, 44);
            this.searchProposalExecutorNCodeTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalExecutorNCodeTxtbx.MaxLength = 10;
            this.searchProposalExecutorNCodeTxtbx.Name = "searchProposalExecutorNCodeTxtbx";
            this.searchProposalExecutorNCodeTxtbx.Size = new System.Drawing.Size(138, 25);
            this.searchProposalExecutorNCodeTxtbx.TabIndex = 1;
            this.searchProposalExecutorNCodeTxtbx.TextChanged += new System.EventHandler(this.searchProposalExecutorNCodeTxtbx_TextChanged);
            this.searchProposalExecutorNCodeTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.searchProposalExecutorNCodeTxtbx_KeyPress);
            // 
            // searchProposalEnglishTitleTxtbx
            // 
            this.searchProposalEnglishTitleTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchProposalEnglishTitleTxtbx.Location = new System.Drawing.Point(338, 68);
            this.searchProposalEnglishTitleTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalEnglishTitleTxtbx.Name = "searchProposalEnglishTitleTxtbx";
            this.searchProposalEnglishTitleTxtbx.Size = new System.Drawing.Size(138, 25);
            this.searchProposalEnglishTitleTxtbx.TabIndex = 8;
            // 
            // searchProposalPersianTitleTxtbx
            // 
            this.searchProposalPersianTitleTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchProposalPersianTitleTxtbx.Location = new System.Drawing.Point(338, 40);
            this.searchProposalPersianTitleTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalPersianTitleTxtbx.Name = "searchProposalPersianTitleTxtbx";
            this.searchProposalPersianTitleTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchProposalPersianTitleTxtbx.Size = new System.Drawing.Size(138, 25);
            this.searchProposalPersianTitleTxtbx.TabIndex = 7;
            // 
            // searchProposalSearchBtn
            // 
            this.searchProposalSearchBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.searchProposalSearchBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.searchProposalSearchBtn.Location = new System.Drawing.Point(37, 249);
            this.searchProposalSearchBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalSearchBtn.Name = "searchProposalSearchBtn";
            this.searchProposalSearchBtn.Size = new System.Drawing.Size(147, 24);
            this.searchProposalSearchBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.searchProposalSearchBtn.TabIndex = 20;
            this.searchProposalSearchBtn.Text = "جستــــــــــجو";
            this.searchProposalSearchBtn.Click += new System.EventHandler(this.searchProposalSearchBtn_Click);
            // 
            // searchProposalClearBtn
            // 
            this.searchProposalClearBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.searchProposalClearBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.searchProposalClearBtn.Location = new System.Drawing.Point(206, 249);
            this.searchProposalClearBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalClearBtn.Name = "searchProposalClearBtn";
            this.searchProposalClearBtn.Size = new System.Drawing.Size(94, 24);
            this.searchProposalClearBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.searchProposalClearBtn.TabIndex = 21;
            this.searchProposalClearBtn.Text = "پاک کردن";
            this.searchProposalClearBtn.Click += new System.EventHandler(this.searchProposalClearBtn_Click);
            // 
            // searchProposalExecutorInfoGp
            // 
            this.searchProposalExecutorInfoGp.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalExecutorInfoGp.CanvasColor = System.Drawing.Color.Transparent;
            this.searchProposalExecutorInfoGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.searchProposalExecutorInfoGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.searchProposalExecutorInfoGp.Location = new System.Drawing.Point(578, 2);
            this.searchProposalExecutorInfoGp.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalExecutorInfoGp.Name = "searchProposalExecutorInfoGp";
            this.searchProposalExecutorInfoGp.Size = new System.Drawing.Size(246, 241);
            // 
            // 
            // 
            this.searchProposalExecutorInfoGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.searchProposalExecutorInfoGp.Style.BackColorGradientAngle = 90;
            this.searchProposalExecutorInfoGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.searchProposalExecutorInfoGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalExecutorInfoGp.Style.BorderBottomWidth = 2;
            this.searchProposalExecutorInfoGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.searchProposalExecutorInfoGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalExecutorInfoGp.Style.BorderLeftWidth = 2;
            this.searchProposalExecutorInfoGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalExecutorInfoGp.Style.BorderRightWidth = 2;
            this.searchProposalExecutorInfoGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalExecutorInfoGp.Style.BorderTopWidth = 2;
            this.searchProposalExecutorInfoGp.Style.CornerDiameter = 10;
            this.searchProposalExecutorInfoGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.searchProposalExecutorInfoGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.searchProposalExecutorInfoGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.searchProposalExecutorInfoGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.searchProposalExecutorInfoGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.searchProposalExecutorInfoGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.searchProposalExecutorInfoGp.TabIndex = 68;
            this.searchProposalExecutorInfoGp.Text = "جستجو بر اساس اطلاعات مجری";
            this.searchProposalExecutorInfoGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // searchProposalProposalInfoGp
            // 
            this.searchProposalProposalInfoGp.BackColor = System.Drawing.Color.Transparent;
            this.searchProposalProposalInfoGp.CanvasColor = System.Drawing.Color.Transparent;
            this.searchProposalProposalInfoGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.searchProposalProposalInfoGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.searchProposalProposalInfoGp.Location = new System.Drawing.Point(37, 2);
            this.searchProposalProposalInfoGp.Margin = new System.Windows.Forms.Padding(2);
            this.searchProposalProposalInfoGp.Name = "searchProposalProposalInfoGp";
            this.searchProposalProposalInfoGp.Size = new System.Drawing.Size(524, 241);
            // 
            // 
            // 
            this.searchProposalProposalInfoGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.searchProposalProposalInfoGp.Style.BackColorGradientAngle = 90;
            this.searchProposalProposalInfoGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.searchProposalProposalInfoGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalProposalInfoGp.Style.BorderBottomWidth = 2;
            this.searchProposalProposalInfoGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.searchProposalProposalInfoGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalProposalInfoGp.Style.BorderLeftWidth = 2;
            this.searchProposalProposalInfoGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalProposalInfoGp.Style.BorderRightWidth = 2;
            this.searchProposalProposalInfoGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.searchProposalProposalInfoGp.Style.BorderTopWidth = 2;
            this.searchProposalProposalInfoGp.Style.CornerDiameter = 10;
            this.searchProposalProposalInfoGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.searchProposalProposalInfoGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.searchProposalProposalInfoGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.searchProposalProposalInfoGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.searchProposalProposalInfoGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.searchProposalProposalInfoGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.searchProposalProposalInfoGp.TabIndex = 121;
            this.searchProposalProposalInfoGp.Text = "جستجو بر اساس اطلاعات پروپوزال";
            // 
            // searchProposalTab
            // 
            this.searchProposalTab.AttachedControl = this.superTabControlPanel3;
            this.searchProposalTab.GlobalItem = false;
            this.searchProposalTab.Image = global::ProposalReportingSystem.Properties.Resources.search;
            this.searchProposalTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.searchProposalTab.Name = "searchProposalTab";
            this.searchProposalTab.Text = "جستـــجوی پروپوزال";
            // 
            // superTabControlPanel2
            // 
            this.superTabControlPanel2.Controls.Add(this.addProposalPanel);
            this.superTabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel2.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel2.Name = "superTabControlPanel2";
            this.superTabControlPanel2.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel2.TabIndex = 0;
            this.superTabControlPanel2.TabItem = this.addProposalTab;
            // 
            // addProposalPanel
            // 
            this.addProposalPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.addProposalPanel.Controls.Add(this.addProposalShowGp);
            this.addProposalPanel.Controls.Add(this.addProposalAddGp);
            this.addProposalPanel.Location = new System.Drawing.Point(1, 2);
            this.addProposalPanel.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalPanel.Name = "addProposalPanel";
            this.addProposalPanel.Size = new System.Drawing.Size(892, 654);
            this.addProposalPanel.TabIndex = 1;
            this.addProposalPanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalShowGp
            // 
            this.addProposalShowGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.addProposalShowGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.addProposalShowGp.Controls.Add(this.addProposalNavigationPanel);
            this.addProposalShowGp.Controls.Add(this.addProposalShowDgv);
            this.addProposalShowGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.addProposalShowGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalShowGp.Location = new System.Drawing.Point(14, 340);
            this.addProposalShowGp.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalShowGp.Name = "addProposalShowGp";
            this.addProposalShowGp.Size = new System.Drawing.Size(847, 292);
            // 
            // 
            // 
            this.addProposalShowGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.addProposalShowGp.Style.BackColorGradientAngle = 90;
            this.addProposalShowGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.addProposalShowGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.addProposalShowGp.Style.BorderBottomWidth = 2;
            this.addProposalShowGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.addProposalShowGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.addProposalShowGp.Style.BorderLeftWidth = 2;
            this.addProposalShowGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.addProposalShowGp.Style.BorderRightWidth = 2;
            this.addProposalShowGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.addProposalShowGp.Style.BorderTopWidth = 2;
            this.addProposalShowGp.Style.CornerDiameter = 10;
            this.addProposalShowGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.addProposalShowGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.addProposalShowGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.addProposalShowGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.addProposalShowGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.addProposalShowGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.addProposalShowGp.TabIndex = 1;
            this.addProposalShowGp.Text = "فهرست پروپوزال ها";
            this.addProposalShowGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalNavigationPanel
            // 
            this.addProposalNavigationPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.addProposalNavigationPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.addProposalNavigationPanel.Controls.Add(this.addProposalNavigationCurrentPageTxtbx);
            this.addProposalNavigationPanel.Controls.Add(this.addProposalNavigationNextPageBtn);
            this.addProposalNavigationPanel.Controls.Add(this.addProposalNavigationLastPageBtn);
            this.addProposalNavigationPanel.Controls.Add(this.addProposalNavigationPreviousPageBtn);
            this.addProposalNavigationPanel.Controls.Add(this.addProposalNavigationFirstPageBtn);
            this.addProposalNavigationPanel.Controls.Add(this.addProposalNavigationReturnBtn);
            this.addProposalNavigationPanel.Location = new System.Drawing.Point(121, 143);
            this.addProposalNavigationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalNavigationPanel.Name = "addProposalNavigationPanel";
            this.addProposalNavigationPanel.Size = new System.Drawing.Size(615, 33);
            this.addProposalNavigationPanel.TabIndex = 4;
            // 
            // addProposalNavigationCurrentPageTxtbx
            // 
            // 
            // 
            // 
            this.addProposalNavigationCurrentPageTxtbx.Border.Class = "TextBoxBorder";
            this.addProposalNavigationCurrentPageTxtbx.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.addProposalNavigationCurrentPageTxtbx.Enabled = false;
            this.addProposalNavigationCurrentPageTxtbx.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalNavigationCurrentPageTxtbx.Location = new System.Drawing.Point(271, 3);
            this.addProposalNavigationCurrentPageTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalNavigationCurrentPageTxtbx.MaxLength = 5;
            this.addProposalNavigationCurrentPageTxtbx.Name = "addProposalNavigationCurrentPageTxtbx";
            this.addProposalNavigationCurrentPageTxtbx.PreventEnterBeep = true;
            this.addProposalNavigationCurrentPageTxtbx.Size = new System.Drawing.Size(74, 25);
            this.addProposalNavigationCurrentPageTxtbx.TabIndex = 34;
            this.addProposalNavigationCurrentPageTxtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.addProposalNavigationCurrentPageTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addProposalNavigationCurrentPageTxtbx_KeyPress);
            // 
            // addProposalNavigationNextPageBtn
            // 
            this.addProposalNavigationNextPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addProposalNavigationNextPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addProposalNavigationNextPageBtn.Enabled = false;
            this.addProposalNavigationNextPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalNavigationNextPageBtn.Location = new System.Drawing.Point(349, 3);
            this.addProposalNavigationNextPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalNavigationNextPageBtn.Name = "addProposalNavigationNextPageBtn";
            this.addProposalNavigationNextPageBtn.Size = new System.Drawing.Size(82, 24);
            this.addProposalNavigationNextPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.addProposalNavigationNextPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem7});
            this.addProposalNavigationNextPageBtn.SubItemsExpandWidth = 0;
            this.addProposalNavigationNextPageBtn.TabIndex = 33;
            this.addProposalNavigationNextPageBtn.Text = "صفحه بعد";
            this.addProposalNavigationNextPageBtn.Click += new System.EventHandler(this.addProposalNavigationNextPageBtn_Click);
            // 
            // superTabItem7
            // 
            this.superTabItem7.GlobalItem = false;
            this.superTabItem7.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem7.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem7.Name = "superTabItem7";
            this.superTabItem7.Text = "لاگ";
            // 
            // addProposalNavigationLastPageBtn
            // 
            this.addProposalNavigationLastPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addProposalNavigationLastPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addProposalNavigationLastPageBtn.Enabled = false;
            this.addProposalNavigationLastPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalNavigationLastPageBtn.Location = new System.Drawing.Point(436, 3);
            this.addProposalNavigationLastPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalNavigationLastPageBtn.Name = "addProposalNavigationLastPageBtn";
            this.addProposalNavigationLastPageBtn.Size = new System.Drawing.Size(82, 24);
            this.addProposalNavigationLastPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.addProposalNavigationLastPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem8});
            this.addProposalNavigationLastPageBtn.SubItemsExpandWidth = 0;
            this.addProposalNavigationLastPageBtn.TabIndex = 32;
            this.addProposalNavigationLastPageBtn.Text = "صفحه آخر";
            this.addProposalNavigationLastPageBtn.Click += new System.EventHandler(this.addProposalNavigationLastPageBtn_Click);
            // 
            // superTabItem8
            // 
            this.superTabItem8.GlobalItem = false;
            this.superTabItem8.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem8.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem8.Name = "superTabItem8";
            this.superTabItem8.Text = "لاگ";
            // 
            // addProposalNavigationPreviousPageBtn
            // 
            this.addProposalNavigationPreviousPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addProposalNavigationPreviousPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addProposalNavigationPreviousPageBtn.Enabled = false;
            this.addProposalNavigationPreviousPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalNavigationPreviousPageBtn.Location = new System.Drawing.Point(184, 3);
            this.addProposalNavigationPreviousPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalNavigationPreviousPageBtn.Name = "addProposalNavigationPreviousPageBtn";
            this.addProposalNavigationPreviousPageBtn.Size = new System.Drawing.Size(82, 24);
            this.addProposalNavigationPreviousPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.addProposalNavigationPreviousPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem11});
            this.addProposalNavigationPreviousPageBtn.SubItemsExpandWidth = 0;
            this.addProposalNavigationPreviousPageBtn.TabIndex = 30;
            this.addProposalNavigationPreviousPageBtn.Text = "صفحه قبل";
            this.addProposalNavigationPreviousPageBtn.Click += new System.EventHandler(this.addProposalNavigationPreviousPageBtn_Click);
            // 
            // superTabItem11
            // 
            this.superTabItem11.GlobalItem = false;
            this.superTabItem11.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem11.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem11.Name = "superTabItem11";
            this.superTabItem11.Text = "لاگ";
            // 
            // addProposalNavigationFirstPageBtn
            // 
            this.addProposalNavigationFirstPageBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addProposalNavigationFirstPageBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addProposalNavigationFirstPageBtn.Enabled = false;
            this.addProposalNavigationFirstPageBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalNavigationFirstPageBtn.Location = new System.Drawing.Point(97, 3);
            this.addProposalNavigationFirstPageBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalNavigationFirstPageBtn.Name = "addProposalNavigationFirstPageBtn";
            this.addProposalNavigationFirstPageBtn.Size = new System.Drawing.Size(82, 24);
            this.addProposalNavigationFirstPageBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.addProposalNavigationFirstPageBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem12});
            this.addProposalNavigationFirstPageBtn.SubItemsExpandWidth = 0;
            this.addProposalNavigationFirstPageBtn.TabIndex = 29;
            this.addProposalNavigationFirstPageBtn.Text = "صفحه اول";
            this.addProposalNavigationFirstPageBtn.Click += new System.EventHandler(this.addProposalNavigationFirstPageBtn_Click);
            // 
            // superTabItem12
            // 
            this.superTabItem12.GlobalItem = false;
            this.superTabItem12.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem12.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem12.Name = "superTabItem12";
            this.superTabItem12.Text = "لاگ";
            // 
            // addProposalNavigationReturnBtn
            // 
            this.addProposalNavigationReturnBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addProposalNavigationReturnBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addProposalNavigationReturnBtn.Enabled = false;
            this.addProposalNavigationReturnBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalNavigationReturnBtn.Location = new System.Drawing.Point(10, 3);
            this.addProposalNavigationReturnBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalNavigationReturnBtn.Name = "addProposalNavigationReturnBtn";
            this.addProposalNavigationReturnBtn.Size = new System.Drawing.Size(82, 24);
            this.addProposalNavigationReturnBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.addProposalNavigationReturnBtn.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem13});
            this.addProposalNavigationReturnBtn.SubItemsExpandWidth = 0;
            this.addProposalNavigationReturnBtn.TabIndex = 28;
            this.addProposalNavigationReturnBtn.Text = "بازگشت";
            this.addProposalNavigationReturnBtn.Click += new System.EventHandler(this.addProposalNavigationReturnBtn_Click);
            // 
            // superTabItem13
            // 
            this.superTabItem13.GlobalItem = false;
            this.superTabItem13.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.superTabItem13.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.superTabItem13.Name = "superTabItem13";
            this.superTabItem13.Text = "لاگ";
            // 
            // addProposalShowDgv
            // 
            this.addProposalShowDgv.AllowUserToAddRows = false;
            this.addProposalShowDgv.AllowUserToDeleteRows = false;
            this.addProposalShowDgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.addProposalShowDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.addProposalShowDgv.Location = new System.Drawing.Point(10, 2);
            this.addProposalShowDgv.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalShowDgv.MultiSelect = false;
            this.addProposalShowDgv.Name = "addProposalShowDgv";
            this.addProposalShowDgv.ReadOnly = true;
            this.addProposalShowDgv.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalShowDgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.addProposalShowDgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.LightCyan;
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.Padding = new System.Windows.Forms.Padding(1);
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(226)))), ((int)(((byte)(171)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.addProposalShowDgv.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.addProposalShowDgv.RowTemplate.Height = 24;
            this.addProposalShowDgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.addProposalShowDgv.Size = new System.Drawing.Size(816, 137);
            this.addProposalShowDgv.TabIndex = 0;
            this.addProposalShowDgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.addProposalShowDgv_CellClick);
            this.addProposalShowDgv.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalAddGp
            // 
            this.addProposalAddGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.addProposalAddGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.addProposalAddGp.Controls.Add(this.addProposalEnglishTitleTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalShowAllBtn);
            this.addProposalAddGp.Controls.Add(this.addProposalSearchBtn);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorEGroupCb);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorFacultyCb);
            this.addProposalAddGp.Controls.Add(this.addProposalStartdateTimeInput);
            this.addProposalAddGp.Controls.Add(this.addProposalFileLinkLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalFileLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalOrganizationNumberCb);
            this.addProposalAddGp.Controls.Add(this.addProposalStatusCb);
            this.addProposalAddGp.Controls.Add(this.addProposalOrganizationNameCb);
            this.addProposalAddGp.Controls.Add(this.addProposalProposalTypeCb);
            this.addProposalAddGp.Controls.Add(this.addProposalRegisterTypeCb);
            this.addProposalAddGp.Controls.Add(this.addProposalPropertyTypeCb);
            this.addProposalAddGp.Controls.Add(this.addProposalProcedureTypeCb);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorEDegCb);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorMobileTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorMobileLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorEmailLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorEDegLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorEmailTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorEGroupLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorFacultyLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorTel2Lbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorTel2Txtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorTel1Lbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorTel1Txtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorLNameLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorLNameTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorFNameLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorFNameTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalValueTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalValueLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalOrganizationLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalStatusLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalTypeLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalRegisterTypeLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalPropertyTypeLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalProcedureTypeLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalDurationTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalDurationLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalStartdateLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalCoexecutorLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalCoexecutorTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutor2Lbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorNcodeLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalKeywordsLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalEnglishTitleLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalPersianTitleLbl);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutor2Txtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalExecutorNcodeTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalKeywordsTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalPersianTitleTxtbx);
            this.addProposalAddGp.Controls.Add(this.addProposalClearBtn);
            this.addProposalAddGp.Controls.Add(this.addProposalRegisterBtn);
            this.addProposalAddGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.addProposalAddGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalAddGp.Location = new System.Drawing.Point(14, 15);
            this.addProposalAddGp.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalAddGp.Name = "addProposalAddGp";
            this.addProposalAddGp.Size = new System.Drawing.Size(847, 321);
            // 
            // 
            // 
            this.addProposalAddGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.addProposalAddGp.Style.BackColorGradientAngle = 90;
            this.addProposalAddGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.addProposalAddGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.addProposalAddGp.Style.BorderBottomWidth = 2;
            this.addProposalAddGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.addProposalAddGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.addProposalAddGp.Style.BorderLeftWidth = 2;
            this.addProposalAddGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.addProposalAddGp.Style.BorderRightWidth = 2;
            this.addProposalAddGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.addProposalAddGp.Style.BorderTopWidth = 2;
            this.addProposalAddGp.Style.CornerDiameter = 10;
            this.addProposalAddGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.addProposalAddGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.addProposalAddGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.addProposalAddGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.addProposalAddGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.addProposalAddGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.addProposalAddGp.TabIndex = 0;
            this.addProposalAddGp.Text = "اطلاعات پروپوزال";
            this.addProposalAddGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalEnglishTitleTxtbx
            // 
            this.addProposalEnglishTitleTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalEnglishTitleTxtbx.Location = new System.Drawing.Point(346, 42);
            this.addProposalEnglishTitleTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalEnglishTitleTxtbx.Multiline = true;
            this.addProposalEnglishTitleTxtbx.Name = "addProposalEnglishTitleTxtbx";
            this.addProposalEnglishTitleTxtbx.Size = new System.Drawing.Size(138, 24);
            this.addProposalEnglishTitleTxtbx.TabIndex = 12;
            // 
            // addProposalShowAllBtn
            // 
            this.addProposalShowAllBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addProposalShowAllBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addProposalShowAllBtn.Location = new System.Drawing.Point(301, 249);
            this.addProposalShowAllBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalShowAllBtn.Name = "addProposalShowAllBtn";
            this.addProposalShowAllBtn.Size = new System.Drawing.Size(94, 24);
            this.addProposalShowAllBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.addProposalShowAllBtn.TabIndex = 29;
            this.addProposalShowAllBtn.Text = "نمایش همه";
            this.addProposalShowAllBtn.Click += new System.EventHandler(this.addProposalShowBtn_Click);
            // 
            // addProposalSearchBtn
            // 
            this.addProposalSearchBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addProposalSearchBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addProposalSearchBtn.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalSearchBtn.Location = new System.Drawing.Point(590, 3);
            this.addProposalSearchBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalSearchBtn.Name = "addProposalSearchBtn";
            this.addProposalSearchBtn.Size = new System.Drawing.Size(45, 24);
            this.addProposalSearchBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.addProposalSearchBtn.TabIndex = 118;
            this.addProposalSearchBtn.Text = "جستجو";
            this.addProposalSearchBtn.Click += new System.EventHandler(this.addProposalSearchBtn_Click);
            // 
            // addProposalExecutorEGroupCb
            // 
            this.addProposalExecutorEGroupCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addProposalExecutorEGroupCb.FormattingEnabled = true;
            this.addProposalExecutorEGroupCb.Location = new System.Drawing.Point(590, 119);
            this.addProposalExecutorEGroupCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorEGroupCb.Name = "addProposalExecutorEGroupCb";
            this.addProposalExecutorEGroupCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalExecutorEGroupCb.Size = new System.Drawing.Size(139, 25);
            this.addProposalExecutorEGroupCb.TabIndex = 5;
            // 
            // addProposalExecutorFacultyCb
            // 
            this.addProposalExecutorFacultyCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addProposalExecutorFacultyCb.FormattingEnabled = true;
            this.addProposalExecutorFacultyCb.Location = new System.Drawing.Point(590, 90);
            this.addProposalExecutorFacultyCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorFacultyCb.Name = "addProposalExecutorFacultyCb";
            this.addProposalExecutorFacultyCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalExecutorFacultyCb.Size = new System.Drawing.Size(139, 25);
            this.addProposalExecutorFacultyCb.TabIndex = 4;
            this.addProposalExecutorFacultyCb.SelectedIndexChanged += new System.EventHandler(this.addProposalExecutorFacultyCb_SelectedIndexChanged);
            // 
            // addProposalStartdateTimeInput
            // 
            this.addProposalStartdateTimeInput.BackColor = System.Drawing.Color.Transparent;
            this.addProposalStartdateTimeInput.GeoDate = new System.DateTime(2017, 1, 21, 0, 0, 0, 0);
            this.addProposalStartdateTimeInput.Location = new System.Drawing.Point(346, 202);
            this.addProposalStartdateTimeInput.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.addProposalStartdateTimeInput.MaximumSize = new System.Drawing.Size(1265, 36);
            this.addProposalStartdateTimeInput.Name = "addProposalStartdateTimeInput";
            this.addProposalStartdateTimeInput.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.addProposalStartdateTimeInput.Size = new System.Drawing.Size(139, 24);
            this.addProposalStartdateTimeInput.TabIndex = 16;
            // 
            // addProposalFileLinkLbl
            // 
            this.addProposalFileLinkLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalFileLinkLbl.Location = new System.Drawing.Point(399, 249);
            this.addProposalFileLinkLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalFileLinkLbl.Name = "addProposalFileLinkLbl";
            this.addProposalFileLinkLbl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalFileLinkLbl.Size = new System.Drawing.Size(83, 20);
            this.addProposalFileLinkLbl.TabIndex = 26;
            this.addProposalFileLinkLbl.TabStop = true;
            this.addProposalFileLinkLbl.Text = "افزودن فایل";
            this.addProposalFileLinkLbl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.addProposalFileLinkLbl_LinkClicked);
            // 
            // addProposalFileLbl
            // 
            this.addProposalFileLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalFileLbl.Location = new System.Drawing.Point(489, 249);
            this.addProposalFileLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalFileLbl.Name = "addProposalFileLbl";
            this.addProposalFileLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalFileLbl.TabIndex = 61;
            this.addProposalFileLbl.Text = "*فایل پروپوزال";
            this.addProposalFileLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalOrganizationNumberCb
            // 
            this.addProposalOrganizationNumberCb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.addProposalOrganizationNumberCb.FormattingEnabled = true;
            this.addProposalOrganizationNumberCb.ItemHeight = 17;
            this.addProposalOrganizationNumberCb.Location = new System.Drawing.Point(168, 158);
            this.addProposalOrganizationNumberCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalOrganizationNumberCb.Name = "addProposalOrganizationNumberCb";
            this.addProposalOrganizationNumberCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalOrganizationNumberCb.Size = new System.Drawing.Size(40, 25);
            this.addProposalOrganizationNumberCb.TabIndex = 22;
            this.addProposalOrganizationNumberCb.SelectedIndexChanged += new System.EventHandler(this.addProposalOrganizationNumberCb_SelectedIndexChanged);
            this.addProposalOrganizationNumberCb.TextChanged += new System.EventHandler(this.addProposalOrganizationNumberCb_TextChanged);
            this.addProposalOrganizationNumberCb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addProposalExecutorNcodeTxtbx_KeyPress);
            // 
            // addProposalStatusCb
            // 
            this.addProposalStatusCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addProposalStatusCb.FormattingEnabled = true;
            this.addProposalStatusCb.ItemHeight = 17;
            this.addProposalStatusCb.Location = new System.Drawing.Point(69, 220);
            this.addProposalStatusCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalStatusCb.Name = "addProposalStatusCb";
            this.addProposalStatusCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalStatusCb.Size = new System.Drawing.Size(139, 25);
            this.addProposalStatusCb.TabIndex = 25;
            // 
            // addProposalOrganizationNameCb
            // 
            this.addProposalOrganizationNameCb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.addProposalOrganizationNameCb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.addProposalOrganizationNameCb.FormattingEnabled = true;
            this.addProposalOrganizationNameCb.ItemHeight = 17;
            this.addProposalOrganizationNameCb.Location = new System.Drawing.Point(69, 158);
            this.addProposalOrganizationNameCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalOrganizationNameCb.Name = "addProposalOrganizationNameCb";
            this.addProposalOrganizationNameCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalOrganizationNameCb.Size = new System.Drawing.Size(96, 25);
            this.addProposalOrganizationNameCb.TabIndex = 23;
            this.addProposalOrganizationNameCb.SelectedIndexChanged += new System.EventHandler(this.addProposalOrganizationNameCb_SelectedIndexChanged);
            this.addProposalOrganizationNameCb.TextChanged += new System.EventHandler(this.addProposalOrganizationNameCb_TextChanged);
            // 
            // addProposalProposalTypeCb
            // 
            this.addProposalProposalTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addProposalProposalTypeCb.FormattingEnabled = true;
            this.addProposalProposalTypeCb.Location = new System.Drawing.Point(69, 126);
            this.addProposalProposalTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalProposalTypeCb.Name = "addProposalProposalTypeCb";
            this.addProposalProposalTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalProposalTypeCb.Size = new System.Drawing.Size(139, 25);
            this.addProposalProposalTypeCb.TabIndex = 21;
            // 
            // addProposalRegisterTypeCb
            // 
            this.addProposalRegisterTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addProposalRegisterTypeCb.FormattingEnabled = true;
            this.addProposalRegisterTypeCb.ItemHeight = 17;
            this.addProposalRegisterTypeCb.Location = new System.Drawing.Point(69, 96);
            this.addProposalRegisterTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalRegisterTypeCb.Name = "addProposalRegisterTypeCb";
            this.addProposalRegisterTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalRegisterTypeCb.Size = new System.Drawing.Size(139, 25);
            this.addProposalRegisterTypeCb.TabIndex = 20;
            // 
            // addProposalPropertyTypeCb
            // 
            this.addProposalPropertyTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addProposalPropertyTypeCb.FormattingEnabled = true;
            this.addProposalPropertyTypeCb.ItemHeight = 17;
            this.addProposalPropertyTypeCb.Location = new System.Drawing.Point(69, 63);
            this.addProposalPropertyTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalPropertyTypeCb.Name = "addProposalPropertyTypeCb";
            this.addProposalPropertyTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalPropertyTypeCb.Size = new System.Drawing.Size(139, 25);
            this.addProposalPropertyTypeCb.TabIndex = 19;
            // 
            // addProposalProcedureTypeCb
            // 
            this.addProposalProcedureTypeCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addProposalProcedureTypeCb.FormattingEnabled = true;
            this.addProposalProcedureTypeCb.ItemHeight = 17;
            this.addProposalProcedureTypeCb.Location = new System.Drawing.Point(69, 34);
            this.addProposalProcedureTypeCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalProcedureTypeCb.Name = "addProposalProcedureTypeCb";
            this.addProposalProcedureTypeCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalProcedureTypeCb.Size = new System.Drawing.Size(139, 25);
            this.addProposalProcedureTypeCb.TabIndex = 18;
            // 
            // addProposalExecutorEDegCb
            // 
            this.addProposalExecutorEDegCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addProposalExecutorEDegCb.FormattingEnabled = true;
            this.addProposalExecutorEDegCb.Location = new System.Drawing.Point(590, 147);
            this.addProposalExecutorEDegCb.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorEDegCb.Name = "addProposalExecutorEDegCb";
            this.addProposalExecutorEDegCb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalExecutorEDegCb.Size = new System.Drawing.Size(139, 25);
            this.addProposalExecutorEDegCb.TabIndex = 6;
            // 
            // addProposalExecutorMobileTxtbx
            // 
            this.addProposalExecutorMobileTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalExecutorMobileTxtbx.Location = new System.Drawing.Point(590, 203);
            this.addProposalExecutorMobileTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorMobileTxtbx.MaxLength = 20;
            this.addProposalExecutorMobileTxtbx.Name = "addProposalExecutorMobileTxtbx";
            this.addProposalExecutorMobileTxtbx.Size = new System.Drawing.Size(138, 25);
            this.addProposalExecutorMobileTxtbx.TabIndex = 8;
            this.addProposalExecutorMobileTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addProposalExecutorNcodeTxtbx_KeyPress);
            // 
            // addProposalExecutorMobileLbl
            // 
            this.addProposalExecutorMobileLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorMobileLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorMobileLbl.Location = new System.Drawing.Point(736, 203);
            this.addProposalExecutorMobileLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorMobileLbl.Name = "addProposalExecutorMobileLbl";
            this.addProposalExecutorMobileLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorMobileLbl.TabIndex = 40;
            this.addProposalExecutorMobileLbl.Text = "*شماره همراه";
            this.addProposalExecutorMobileLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorMobileLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalExecutorEmailLbl
            // 
            this.addProposalExecutorEmailLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorEmailLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorEmailLbl.Location = new System.Drawing.Point(736, 175);
            this.addProposalExecutorEmailLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorEmailLbl.Name = "addProposalExecutorEmailLbl";
            this.addProposalExecutorEmailLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorEmailLbl.TabIndex = 50;
            this.addProposalExecutorEmailLbl.Text = "*آدرس ایمیل";
            this.addProposalExecutorEmailLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorEmailLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalExecutorEDegLbl
            // 
            this.addProposalExecutorEDegLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorEDegLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorEDegLbl.Location = new System.Drawing.Point(736, 148);
            this.addProposalExecutorEDegLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorEDegLbl.Name = "addProposalExecutorEDegLbl";
            this.addProposalExecutorEDegLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorEDegLbl.TabIndex = 38;
            this.addProposalExecutorEDegLbl.Text = "*درجه علمی";
            this.addProposalExecutorEDegLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorEDegLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalExecutorEmailTxtbx
            // 
            this.addProposalExecutorEmailTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalExecutorEmailTxtbx.Location = new System.Drawing.Point(590, 175);
            this.addProposalExecutorEmailTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorEmailTxtbx.MaxLength = 50;
            this.addProposalExecutorEmailTxtbx.Name = "addProposalExecutorEmailTxtbx";
            this.addProposalExecutorEmailTxtbx.Size = new System.Drawing.Size(138, 25);
            this.addProposalExecutorEmailTxtbx.TabIndex = 7;
            this.addProposalExecutorEmailTxtbx.TextChanged += new System.EventHandler(this.addProposalExecutorEmailTxtbx_TextChanged);
            this.addProposalExecutorEmailTxtbx.Leave += new System.EventHandler(this.addProposalExecutorEmailTxtbx_Leave);
            // 
            // addProposalExecutorEGroupLbl
            // 
            this.addProposalExecutorEGroupLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorEGroupLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorEGroupLbl.Location = new System.Drawing.Point(736, 119);
            this.addProposalExecutorEGroupLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorEGroupLbl.Name = "addProposalExecutorEGroupLbl";
            this.addProposalExecutorEGroupLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorEGroupLbl.TabIndex = 48;
            this.addProposalExecutorEGroupLbl.Text = "*گروه آموزشی";
            this.addProposalExecutorEGroupLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorEGroupLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalExecutorFacultyLbl
            // 
            this.addProposalExecutorFacultyLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorFacultyLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorFacultyLbl.Location = new System.Drawing.Point(736, 90);
            this.addProposalExecutorFacultyLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorFacultyLbl.Name = "addProposalExecutorFacultyLbl";
            this.addProposalExecutorFacultyLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorFacultyLbl.TabIndex = 46;
            this.addProposalExecutorFacultyLbl.Text = "*دانشکده";
            this.addProposalExecutorFacultyLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorFacultyLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalExecutorTel2Lbl
            // 
            this.addProposalExecutorTel2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorTel2Lbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorTel2Lbl.Location = new System.Drawing.Point(736, 261);
            this.addProposalExecutorTel2Lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorTel2Lbl.Name = "addProposalExecutorTel2Lbl";
            this.addProposalExecutorTel2Lbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorTel2Lbl.TabIndex = 44;
            this.addProposalExecutorTel2Lbl.Text = "تلفن تماس";
            this.addProposalExecutorTel2Lbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorTel2Lbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalExecutorTel2Txtbx
            // 
            this.addProposalExecutorTel2Txtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalExecutorTel2Txtbx.Location = new System.Drawing.Point(590, 261);
            this.addProposalExecutorTel2Txtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorTel2Txtbx.MaxLength = 20;
            this.addProposalExecutorTel2Txtbx.Name = "addProposalExecutorTel2Txtbx";
            this.addProposalExecutorTel2Txtbx.Size = new System.Drawing.Size(138, 25);
            this.addProposalExecutorTel2Txtbx.TabIndex = 10;
            this.addProposalExecutorTel2Txtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addProposalExecutorNcodeTxtbx_KeyPress);
            // 
            // addProposalExecutorTel1Lbl
            // 
            this.addProposalExecutorTel1Lbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorTel1Lbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorTel1Lbl.Location = new System.Drawing.Point(736, 232);
            this.addProposalExecutorTel1Lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorTel1Lbl.Name = "addProposalExecutorTel1Lbl";
            this.addProposalExecutorTel1Lbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorTel1Lbl.TabIndex = 42;
            this.addProposalExecutorTel1Lbl.Text = "تلفن تماس";
            this.addProposalExecutorTel1Lbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorTel1Lbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalExecutorTel1Txtbx
            // 
            this.addProposalExecutorTel1Txtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalExecutorTel1Txtbx.Location = new System.Drawing.Point(590, 232);
            this.addProposalExecutorTel1Txtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorTel1Txtbx.MaxLength = 20;
            this.addProposalExecutorTel1Txtbx.Name = "addProposalExecutorTel1Txtbx";
            this.addProposalExecutorTel1Txtbx.Size = new System.Drawing.Size(138, 25);
            this.addProposalExecutorTel1Txtbx.TabIndex = 9;
            this.addProposalExecutorTel1Txtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addProposalExecutorNcodeTxtbx_KeyPress);
            // 
            // addProposalExecutorLNameLbl
            // 
            this.addProposalExecutorLNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorLNameLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorLNameLbl.Location = new System.Drawing.Point(736, 60);
            this.addProposalExecutorLNameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorLNameLbl.Name = "addProposalExecutorLNameLbl";
            this.addProposalExecutorLNameLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorLNameLbl.TabIndex = 36;
            this.addProposalExecutorLNameLbl.Text = "*نام خانوادگی";
            this.addProposalExecutorLNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorLNameLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalExecutorLNameTxtbx
            // 
            this.addProposalExecutorLNameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalExecutorLNameTxtbx.Location = new System.Drawing.Point(590, 60);
            this.addProposalExecutorLNameTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorLNameTxtbx.MaxLength = 100;
            this.addProposalExecutorLNameTxtbx.Name = "addProposalExecutorLNameTxtbx";
            this.addProposalExecutorLNameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalExecutorLNameTxtbx.Size = new System.Drawing.Size(138, 25);
            this.addProposalExecutorLNameTxtbx.TabIndex = 3;
            // 
            // addProposalExecutorFNameLbl
            // 
            this.addProposalExecutorFNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorFNameLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorFNameLbl.Location = new System.Drawing.Point(736, 31);
            this.addProposalExecutorFNameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorFNameLbl.Name = "addProposalExecutorFNameLbl";
            this.addProposalExecutorFNameLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorFNameLbl.TabIndex = 34;
            this.addProposalExecutorFNameLbl.Text = "*نام";
            this.addProposalExecutorFNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorFNameLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalExecutorFNameTxtbx
            // 
            this.addProposalExecutorFNameTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalExecutorFNameTxtbx.Location = new System.Drawing.Point(590, 31);
            this.addProposalExecutorFNameTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorFNameTxtbx.MaxLength = 100;
            this.addProposalExecutorFNameTxtbx.Name = "addProposalExecutorFNameTxtbx";
            this.addProposalExecutorFNameTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalExecutorFNameTxtbx.Size = new System.Drawing.Size(138, 25);
            this.addProposalExecutorFNameTxtbx.TabIndex = 2;
            this.addProposalExecutorFNameTxtbx.Click += new System.EventHandler(this.addProposalExecutorFNameTxtbx_Click);
            this.addProposalExecutorFNameTxtbx.Enter += new System.EventHandler(this.addProposalExecutorFNameTxtbx_Enter);
            // 
            // addProposalValueTxtbx
            // 
            this.addProposalValueTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalValueTxtbx.Location = new System.Drawing.Point(69, 188);
            this.addProposalValueTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalValueTxtbx.MaxLength = 18;
            this.addProposalValueTxtbx.Name = "addProposalValueTxtbx";
            this.addProposalValueTxtbx.Size = new System.Drawing.Size(138, 25);
            this.addProposalValueTxtbx.TabIndex = 24;
            this.addProposalValueTxtbx.TextChanged += new System.EventHandler(this.addProposalValueTxtbx_TextChanged);
            this.addProposalValueTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addProposalExecutorNcodeTxtbx_KeyPress);
            // 
            // addProposalValueLbl
            // 
            this.addProposalValueLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalValueLbl.Location = new System.Drawing.Point(212, 188);
            this.addProposalValueLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalValueLbl.Name = "addProposalValueLbl";
            this.addProposalValueLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalValueLbl.TabIndex = 29;
            this.addProposalValueLbl.Text = "*مبلغ";
            this.addProposalValueLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalOrganizationLbl
            // 
            this.addProposalOrganizationLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalOrganizationLbl.Location = new System.Drawing.Point(212, 158);
            this.addProposalOrganizationLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalOrganizationLbl.Name = "addProposalOrganizationLbl";
            this.addProposalOrganizationLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalOrganizationLbl.TabIndex = 27;
            this.addProposalOrganizationLbl.Text = "*سازمان کارفرما";
            this.addProposalOrganizationLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalStatusLbl
            // 
            this.addProposalStatusLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalStatusLbl.Location = new System.Drawing.Point(212, 218);
            this.addProposalStatusLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalStatusLbl.Name = "addProposalStatusLbl";
            this.addProposalStatusLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalStatusLbl.TabIndex = 25;
            this.addProposalStatusLbl.Text = "*وضعیت";
            this.addProposalStatusLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalTypeLbl
            // 
            this.addProposalTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalTypeLbl.Location = new System.Drawing.Point(212, 129);
            this.addProposalTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalTypeLbl.Name = "addProposalTypeLbl";
            this.addProposalTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalTypeLbl.TabIndex = 23;
            this.addProposalTypeLbl.Text = "*نوع پروپوزال";
            this.addProposalTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalRegisterTypeLbl
            // 
            this.addProposalRegisterTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalRegisterTypeLbl.Location = new System.Drawing.Point(212, 97);
            this.addProposalRegisterTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalRegisterTypeLbl.Name = "addProposalRegisterTypeLbl";
            this.addProposalRegisterTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalRegisterTypeLbl.TabIndex = 21;
            this.addProposalRegisterTypeLbl.Text = "*نوع ثبت";
            this.addProposalRegisterTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalPropertyTypeLbl
            // 
            this.addProposalPropertyTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalPropertyTypeLbl.Location = new System.Drawing.Point(212, 63);
            this.addProposalPropertyTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalPropertyTypeLbl.Name = "addProposalPropertyTypeLbl";
            this.addProposalPropertyTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalPropertyTypeLbl.TabIndex = 19;
            this.addProposalPropertyTypeLbl.Text = "*خاصیت";
            this.addProposalPropertyTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalProcedureTypeLbl
            // 
            this.addProposalProcedureTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalProcedureTypeLbl.Location = new System.Drawing.Point(212, 29);
            this.addProposalProcedureTypeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalProcedureTypeLbl.Name = "addProposalProcedureTypeLbl";
            this.addProposalProcedureTypeLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalProcedureTypeLbl.TabIndex = 17;
            this.addProposalProcedureTypeLbl.Text = "*نوع کار";
            this.addProposalProcedureTypeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalDurationTxtbx
            // 
            this.addProposalDurationTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalDurationTxtbx.Location = new System.Drawing.Point(69, 1);
            this.addProposalDurationTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalDurationTxtbx.MaxLength = 9;
            this.addProposalDurationTxtbx.Name = "addProposalDurationTxtbx";
            this.addProposalDurationTxtbx.Size = new System.Drawing.Size(138, 25);
            this.addProposalDurationTxtbx.TabIndex = 17;
            this.addProposalDurationTxtbx.TextChanged += new System.EventHandler(this.addProposalDurationTxtbx_TextChanged);
            this.addProposalDurationTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addProposalExecutorNcodeTxtbx_KeyPress);
            // 
            // addProposalDurationLbl
            // 
            this.addProposalDurationLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalDurationLbl.Location = new System.Drawing.Point(212, 2);
            this.addProposalDurationLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalDurationLbl.Name = "addProposalDurationLbl";
            this.addProposalDurationLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalDurationLbl.TabIndex = 14;
            this.addProposalDurationLbl.Text = "*مدت زمان (ماه)";
            this.addProposalDurationLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalStartdateLbl
            // 
            this.addProposalStartdateLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalStartdateLbl.Location = new System.Drawing.Point(490, 202);
            this.addProposalStartdateLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalStartdateLbl.Name = "addProposalStartdateLbl";
            this.addProposalStartdateLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalStartdateLbl.TabIndex = 13;
            this.addProposalStartdateLbl.Text = "*تاریخ ارسال";
            this.addProposalStartdateLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalCoexecutorLbl
            // 
            this.addProposalCoexecutorLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalCoexecutorLbl.Location = new System.Drawing.Point(490, 162);
            this.addProposalCoexecutorLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalCoexecutorLbl.Name = "addProposalCoexecutorLbl";
            this.addProposalCoexecutorLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalCoexecutorLbl.TabIndex = 12;
            this.addProposalCoexecutorLbl.Text = "همکاران مجری";
            this.addProposalCoexecutorLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalCoexecutorTxtbx
            // 
            this.addProposalCoexecutorTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalCoexecutorTxtbx.Location = new System.Drawing.Point(346, 162);
            this.addProposalCoexecutorTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalCoexecutorTxtbx.Multiline = true;
            this.addProposalCoexecutorTxtbx.Name = "addProposalCoexecutorTxtbx";
            this.addProposalCoexecutorTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalCoexecutorTxtbx.Size = new System.Drawing.Size(138, 36);
            this.addProposalCoexecutorTxtbx.TabIndex = 15;
            // 
            // addProposalExecutor2Lbl
            // 
            this.addProposalExecutor2Lbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutor2Lbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutor2Lbl.Location = new System.Drawing.Point(492, 124);
            this.addProposalExecutor2Lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutor2Lbl.Name = "addProposalExecutor2Lbl";
            this.addProposalExecutor2Lbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutor2Lbl.TabIndex = 9;
            this.addProposalExecutor2Lbl.Text = "مجریان همکار";
            this.addProposalExecutor2Lbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalExecutorNcodeLbl
            // 
            this.addProposalExecutorNcodeLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalExecutorNcodeLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalExecutorNcodeLbl.Location = new System.Drawing.Point(736, 2);
            this.addProposalExecutorNcodeLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalExecutorNcodeLbl.Name = "addProposalExecutorNcodeLbl";
            this.addProposalExecutorNcodeLbl.Size = new System.Drawing.Size(73, 20);
            this.addProposalExecutorNcodeLbl.TabIndex = 8;
            this.addProposalExecutorNcodeLbl.Text = "*کدملی مجری";
            this.addProposalExecutorNcodeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.addProposalExecutorNcodeLbl.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // addProposalKeywordsLbl
            // 
            this.addProposalKeywordsLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalKeywordsLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalKeywordsLbl.Location = new System.Drawing.Point(489, 72);
            this.addProposalKeywordsLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalKeywordsLbl.Name = "addProposalKeywordsLbl";
            this.addProposalKeywordsLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalKeywordsLbl.TabIndex = 7;
            this.addProposalKeywordsLbl.Text = "*کلمات کلیدی";
            this.addProposalKeywordsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalEnglishTitleLbl
            // 
            this.addProposalEnglishTitleLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalEnglishTitleLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalEnglishTitleLbl.Location = new System.Drawing.Point(489, 43);
            this.addProposalEnglishTitleLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalEnglishTitleLbl.Name = "addProposalEnglishTitleLbl";
            this.addProposalEnglishTitleLbl.Size = new System.Drawing.Size(74, 20);
            this.addProposalEnglishTitleLbl.TabIndex = 6;
            this.addProposalEnglishTitleLbl.Text = "*عنوان لاتین";
            this.addProposalEnglishTitleLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalPersianTitleLbl
            // 
            this.addProposalPersianTitleLbl.BackColor = System.Drawing.Color.Transparent;
            this.addProposalPersianTitleLbl.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.addProposalPersianTitleLbl.Location = new System.Drawing.Point(489, 15);
            this.addProposalPersianTitleLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addProposalPersianTitleLbl.Name = "addProposalPersianTitleLbl";
            this.addProposalPersianTitleLbl.Size = new System.Drawing.Size(73, 22);
            this.addProposalPersianTitleLbl.TabIndex = 5;
            this.addProposalPersianTitleLbl.Text = "*عنوان فارسی";
            this.addProposalPersianTitleLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addProposalExecutor2Txtbx
            // 
            this.addProposalExecutor2Txtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalExecutor2Txtbx.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.addProposalExecutor2Txtbx.Location = new System.Drawing.Point(346, 124);
            this.addProposalExecutor2Txtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutor2Txtbx.Multiline = true;
            this.addProposalExecutor2Txtbx.Name = "addProposalExecutor2Txtbx";
            this.addProposalExecutor2Txtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalExecutor2Txtbx.Size = new System.Drawing.Size(138, 34);
            this.addProposalExecutor2Txtbx.TabIndex = 14;
            // 
            // addProposalExecutorNcodeTxtbx
            // 
            this.addProposalExecutorNcodeTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalExecutorNcodeTxtbx.Location = new System.Drawing.Point(640, 2);
            this.addProposalExecutorNcodeTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalExecutorNcodeTxtbx.MaxLength = 10;
            this.addProposalExecutorNcodeTxtbx.Name = "addProposalExecutorNcodeTxtbx";
            this.addProposalExecutorNcodeTxtbx.Size = new System.Drawing.Size(88, 25);
            this.addProposalExecutorNcodeTxtbx.TabIndex = 1;
            this.addProposalExecutorNcodeTxtbx.TextChanged += new System.EventHandler(this.addProposalExecutorNcodeTxtbx_TextChanged);
            this.addProposalExecutorNcodeTxtbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addProposalExecutorNcodeTxtbx_KeyPress);
            // 
            // addProposalKeywordsTxtbx
            // 
            this.addProposalKeywordsTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalKeywordsTxtbx.Location = new System.Drawing.Point(346, 72);
            this.addProposalKeywordsTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalKeywordsTxtbx.Multiline = true;
            this.addProposalKeywordsTxtbx.Name = "addProposalKeywordsTxtbx";
            this.addProposalKeywordsTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalKeywordsTxtbx.Size = new System.Drawing.Size(138, 44);
            this.addProposalKeywordsTxtbx.TabIndex = 13;
            // 
            // addProposalPersianTitleTxtbx
            // 
            this.addProposalPersianTitleTxtbx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.addProposalPersianTitleTxtbx.Location = new System.Drawing.Point(346, 14);
            this.addProposalPersianTitleTxtbx.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalPersianTitleTxtbx.Multiline = true;
            this.addProposalPersianTitleTxtbx.Name = "addProposalPersianTitleTxtbx";
            this.addProposalPersianTitleTxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addProposalPersianTitleTxtbx.Size = new System.Drawing.Size(138, 24);
            this.addProposalPersianTitleTxtbx.TabIndex = 11;
            // 
            // addProposalClearBtn
            // 
            this.addProposalClearBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addProposalClearBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addProposalClearBtn.Location = new System.Drawing.Point(191, 249);
            this.addProposalClearBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalClearBtn.Name = "addProposalClearBtn";
            this.addProposalClearBtn.Size = new System.Drawing.Size(94, 24);
            this.addProposalClearBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.addProposalClearBtn.TabIndex = 27;
            this.addProposalClearBtn.Text = "پاک کردن";
            this.addProposalClearBtn.Click += new System.EventHandler(this.addProposalClearBtn_Click);
            // 
            // addProposalRegisterBtn
            // 
            this.addProposalRegisterBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addProposalRegisterBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addProposalRegisterBtn.Location = new System.Drawing.Point(69, 249);
            this.addProposalRegisterBtn.Margin = new System.Windows.Forms.Padding(2);
            this.addProposalRegisterBtn.Name = "addProposalRegisterBtn";
            this.addProposalRegisterBtn.Size = new System.Drawing.Size(108, 24);
            this.addProposalRegisterBtn.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003;
            this.addProposalRegisterBtn.TabIndex = 28;
            this.addProposalRegisterBtn.Text = "ثبت اطلاعات";
            this.addProposalRegisterBtn.Click += new System.EventHandler(this.addProposalRegisterBtn_Click);
            // 
            // addProposalTab
            // 
            this.addProposalTab.AttachedControl = this.superTabControlPanel2;
            this.addProposalTab.GlobalItem = false;
            this.addProposalTab.Image = global::ProposalReportingSystem.Properties.Resources.file__1_;
            this.addProposalTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.addProposalTab.Name = "addProposalTab";
            this.addProposalTab.Text = "افزودن پروپوزال";
            this.addProposalTab.Click += new System.EventHandler(this.addProposalTab_Click);
            // 
            // superTabControlPanel1
            // 
            this.superTabControlPanel1.CanvasColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(231)))), ((int)(((byte)(255)))));
            this.superTabControlPanel1.Controls.Add(this.homePanel);
            this.superTabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel1.Name = "superTabControlPanel1";
            this.superTabControlPanel1.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel1.TabIndex = 1;
            this.superTabControlPanel1.TabItem = this.homeTab;
            // 
            // homePanel
            // 
            this.homePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.homePanel.Controls.Add(this.homeTimeDateGp);
            this.homePanel.Controls.Add(this.homeAapInfoGp);
            this.homePanel.Location = new System.Drawing.Point(2, 19);
            this.homePanel.Margin = new System.Windows.Forms.Padding(2);
            this.homePanel.Name = "homePanel";
            this.homePanel.Size = new System.Drawing.Size(860, 618);
            this.homePanel.TabIndex = 4;
            this.homePanel.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // homeTimeDateGp
            // 
            this.homeTimeDateGp.BackColor = System.Drawing.Color.Transparent;
            this.homeTimeDateGp.CanvasColor = System.Drawing.Color.Transparent;
            this.homeTimeDateGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.homeTimeDateGp.Controls.Add(this.monthCalendar1);
            this.homeTimeDateGp.Controls.Add(this.analogClockControl1);
            this.homeTimeDateGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.homeTimeDateGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.homeTimeDateGp.Location = new System.Drawing.Point(15, 263);
            this.homeTimeDateGp.Name = "homeTimeDateGp";
            this.homeTimeDateGp.Size = new System.Drawing.Size(852, 333);
            // 
            // 
            // 
            this.homeTimeDateGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.homeTimeDateGp.Style.BackColorGradientAngle = 90;
            this.homeTimeDateGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.homeTimeDateGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.homeTimeDateGp.Style.BorderBottomWidth = 5;
            this.homeTimeDateGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.homeTimeDateGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.homeTimeDateGp.Style.BorderLeftWidth = 5;
            this.homeTimeDateGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.homeTimeDateGp.Style.BorderRightWidth = 5;
            this.homeTimeDateGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.homeTimeDateGp.Style.BorderTopWidth = 5;
            this.homeTimeDateGp.Style.CornerDiameter = 15;
            this.homeTimeDateGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.homeTimeDateGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.homeTimeDateGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.homeTimeDateGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.homeTimeDateGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.homeTimeDateGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.homeTimeDateGp.TabIndex = 3;
            this.homeTimeDateGp.Text = "ساعت و تاریخ";
            this.homeTimeDateGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.AntiAliasTexts = true;
            this.monthCalendar1.BackColor = System.Drawing.Color.White;
            this.monthCalendar1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.monthCalendar1.DaysBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(199)))), ((int)(((byte)(186)))));
            this.monthCalendar1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(216)))));
            this.monthCalendar1.HeaderBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(240)))));
            this.monthCalendar1.HorizontalGridLines = true;
            this.monthCalendar1.Location = new System.Drawing.Point(363, 39);
            this.monthCalendar1.Margin = new System.Windows.Forms.Padding(2);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.NumbersColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.monthCalendar1.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(250)))));
            farsiDate1.Day = 14;
            farsiDate1.FarsiDateValue = "96/02/14";
            farsiDate1.GeoDate = new System.DateTime(2017, 5, 4, 0, 0, 0, 0);
            farsiDate1.Month = 2;
            farsiDate1.Year = 1396;
            this.monthCalendar1.SelectedFarsiValue = farsiDate1;
            this.monthCalendar1.SelectedGeoValue = new System.DateTime(2017, 5, 4, 0, 0, 0, 0);
            this.monthCalendar1.SelectedNumberColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(250)))));
            this.monthCalendar1.ShowSmallDayName = false;
            this.monthCalendar1.ShowToday = true;
            this.monthCalendar1.Size = new System.Drawing.Size(431, 228);
            this.monthCalendar1.TabIndex = 2;
            this.monthCalendar1.Text = "farsiCalendarControl1";
            this.monthCalendar1.TodayBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(200)))), ((int)(((byte)(150)))));
            this.monthCalendar1.TodayNumberColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.monthCalendar1.VerticalGridLines = true;
            // 
            // analogClockControl1
            // 
            this.analogClockControl1.AutomaticMode = true;
            this.analogClockControl1.BackColor = System.Drawing.Color.Transparent;
            this.analogClockControl1.ClockStyle = DevComponents.DotNetBar.Controls.eClockStyles.Custom;
            colorData1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            colorData1.BorderWidth = 0.01F;
            colorData1.BrushSBSScale = 1F;
            colorData1.BrushType = DevComponents.DotNetBar.Controls.eBrushTypes.Linear;
            colorData1.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            colorData1.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(152)))), ((int)(((byte)(152)))));
            clockStyleData1.BezelColor = colorData1;
            colorData2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            colorData2.BorderWidth = 0.01F;
            colorData2.BrushSBSScale = 1F;
            colorData2.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            colorData2.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            clockStyleData1.CapColor = colorData2;
            colorData3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(161)))));
            colorData3.BorderWidth = 0.01F;
            colorData3.BrushAngle = 45F;
            colorData3.BrushSBSScale = 1F;
            colorData3.BrushType = DevComponents.DotNetBar.Controls.eBrushTypes.Linear;
            colorData3.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(204)))), ((int)(((byte)(213)))));
            colorData3.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            clockStyleData1.FaceColor = colorData3;
            clockStyleData1.GlassAngle = -20;
            colorData4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            colorData4.BorderWidth = 0.01F;
            colorData4.BrushSBSScale = 1F;
            colorData4.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            colorData4.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            clockHandStyleData1.HandColor = colorData4;
            clockHandStyleData1.Length = 0.55F;
            clockHandStyleData1.Width = 0.015F;
            clockStyleData1.HourHandStyle = clockHandStyleData1;
            colorData5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            colorData5.BorderWidth = 0.01F;
            colorData5.BrushSBSScale = 1F;
            colorData5.BrushType = DevComponents.DotNetBar.Controls.eBrushTypes.Linear;
            colorData5.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(142)))), ((int)(((byte)(154)))));
            colorData5.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(142)))), ((int)(((byte)(154)))));
            clockStyleData1.LargeTickColor = colorData5;
            colorData6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            colorData6.BorderWidth = 0.01F;
            colorData6.BrushSBSScale = 1F;
            colorData6.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            colorData6.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            clockHandStyleData2.HandColor = colorData6;
            clockHandStyleData2.Length = 0.8F;
            clockHandStyleData2.Width = 0.01F;
            clockStyleData1.MinuteHandStyle = clockHandStyleData2;
            clockStyleData1.NumberFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            colorData7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            colorData7.BorderWidth = 0.01F;
            colorData7.BrushSBSScale = 1F;
            colorData7.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            colorData7.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(127)))), ((int)(((byte)(138)))));
            clockHandStyleData3.HandColor = colorData7;
            clockHandStyleData3.HandStyle = DevComponents.DotNetBar.Controls.eHandStyles.Style2;
            clockHandStyleData3.Length = 0.8F;
            clockHandStyleData3.Width = 0.005F;
            clockStyleData1.SecondHandStyle = clockHandStyleData3;
            colorData8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            colorData8.BorderWidth = 0.01F;
            colorData8.BrushSBSScale = 1F;
            colorData8.BrushType = DevComponents.DotNetBar.Controls.eBrushTypes.Linear;
            colorData8.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(142)))), ((int)(((byte)(154)))));
            colorData8.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(142)))), ((int)(((byte)(154)))));
            clockStyleData1.SmallTickColor = colorData8;
            clockStyleData1.Style = DevComponents.DotNetBar.Controls.eClockStyles.Custom;
            this.analogClockControl1.ClockStyleData = clockStyleData1;
            this.analogClockControl1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.analogClockControl1.Location = new System.Drawing.Point(75, 39);
            this.analogClockControl1.Name = "analogClockControl1";
            this.analogClockControl1.Size = new System.Drawing.Size(222, 222);
            this.analogClockControl1.TabIndex = 0;
            this.analogClockControl1.Text = "analogClockControl1";
            this.analogClockControl1.Value = new System.DateTime(2016, 11, 21, 11, 15, 59, 170);
            // 
            // homeAapInfoGp
            // 
            this.homeAapInfoGp.BackColor = System.Drawing.Color.Transparent;
            this.homeAapInfoGp.CanvasColor = System.Drawing.SystemColors.Control;
            this.homeAapInfoGp.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.homeAapInfoGp.Controls.Add(this.homeEBSLbl);
            this.homeAapInfoGp.Controls.Add(this.homeWelcomeLbl);
            this.homeAapInfoGp.Controls.Add(this.homeUserNameLbl);
            this.homeAapInfoGp.Controls.Add(this.homeUserProfileLbl);
            this.homeAapInfoGp.Controls.Add(this.homeAppNameLbl);
            this.homeAapInfoGp.DisabledBackColor = System.Drawing.Color.Empty;
            this.homeAapInfoGp.Font = new System.Drawing.Font("B Yekan+", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.homeAapInfoGp.Location = new System.Drawing.Point(112, 24);
            this.homeAapInfoGp.Name = "homeAapInfoGp";
            this.homeAapInfoGp.Size = new System.Drawing.Size(689, 233);
            // 
            // 
            // 
            this.homeAapInfoGp.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.homeAapInfoGp.Style.BackColorGradientAngle = 90;
            this.homeAapInfoGp.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.homeAapInfoGp.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.homeAapInfoGp.Style.BorderBottomWidth = 5;
            this.homeAapInfoGp.Style.BorderColor = System.Drawing.Color.Navy;
            this.homeAapInfoGp.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.homeAapInfoGp.Style.BorderLeftWidth = 5;
            this.homeAapInfoGp.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.homeAapInfoGp.Style.BorderRightWidth = 5;
            this.homeAapInfoGp.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.homeAapInfoGp.Style.BorderTopWidth = 5;
            this.homeAapInfoGp.Style.CornerDiameter = 15;
            this.homeAapInfoGp.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.homeAapInfoGp.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.homeAapInfoGp.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.homeAapInfoGp.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.homeAapInfoGp.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.homeAapInfoGp.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.homeAapInfoGp.TabIndex = 2;
            this.homeAapInfoGp.Text = "مشخصات برنامه و کاربر";
            this.homeAapInfoGp.Click += new System.EventHandler(this.homeAapInfoGp_Click);
            this.homeAapInfoGp.MouseEnter += new System.EventHandler(this.homePanel_MouseEnter);
            // 
            // homeEBSLbl
            // 
            this.homeEBSLbl.BackColor = System.Drawing.Color.Transparent;
            this.homeEBSLbl.Font = new System.Drawing.Font("B Sina", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.homeEBSLbl.Location = new System.Drawing.Point(56, 55);
            this.homeEBSLbl.Name = "homeEBSLbl";
            this.homeEBSLbl.Size = new System.Drawing.Size(573, 28);
            this.homeEBSLbl.TabIndex = 4;
            this.homeEBSLbl.Text = "(واحد ارتباط با صنعت)";
            this.homeEBSLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // homeWelcomeLbl
            // 
            this.homeWelcomeLbl.BackColor = System.Drawing.Color.Transparent;
            this.homeWelcomeLbl.Font = new System.Drawing.Font("B Nazanin", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.homeWelcomeLbl.Location = new System.Drawing.Point(253, 150);
            this.homeWelcomeLbl.Name = "homeWelcomeLbl";
            this.homeWelcomeLbl.Size = new System.Drawing.Size(185, 31);
            this.homeWelcomeLbl.TabIndex = 3;
            this.homeWelcomeLbl.Text = "خوش آمدید";
            this.homeWelcomeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // homeUserNameLbl
            // 
            this.homeUserNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.homeUserNameLbl.Font = new System.Drawing.Font("B Nazanin", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.homeUserNameLbl.Location = new System.Drawing.Point(256, 115);
            this.homeUserNameLbl.Name = "homeUserNameLbl";
            this.homeUserNameLbl.Size = new System.Drawing.Size(182, 34);
            this.homeUserNameLbl.TabIndex = 2;
            this.homeUserNameLbl.Text = "نام و  نام خانوادگی";
            this.homeUserNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // homeUserProfileLbl
            // 
            this.homeUserProfileLbl.BackColor = System.Drawing.Color.Transparent;
            this.homeUserProfileLbl.Image = ((System.Drawing.Image)(resources.GetObject("homeUserProfileLbl.Image")));
            this.homeUserProfileLbl.Location = new System.Drawing.Point(518, 83);
            this.homeUserProfileLbl.Name = "homeUserProfileLbl";
            this.homeUserProfileLbl.Size = new System.Drawing.Size(72, 67);
            this.homeUserProfileLbl.TabIndex = 1;
            this.homeUserProfileLbl.Visible = false;
            // 
            // homeAppNameLbl
            // 
            this.homeAppNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.homeAppNameLbl.Font = new System.Drawing.Font("B Sina", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.homeAppNameLbl.Location = new System.Drawing.Point(56, 14);
            this.homeAppNameLbl.Name = "homeAppNameLbl";
            this.homeAppNameLbl.Size = new System.Drawing.Size(573, 28);
            this.homeAppNameLbl.TabIndex = 0;
            this.homeAppNameLbl.Text = "سامانه مدیریت پروپوزال های دانشگاه شهید چمران اهواز";
            this.homeAppNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // homeTab
            // 
            this.homeTab.AttachedControl = this.superTabControlPanel1;
            this.homeTab.GlobalItem = false;
            this.homeTab.Image = global::ProposalReportingSystem.Properties.Resources.home;
            this.homeTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.homeTab.Name = "homeTab";
            this.homeTab.Text = "خانه";
            // 
            // superTabControlPanel13
            // 
            this.superTabControlPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel13.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel13.Margin = new System.Windows.Forms.Padding(2);
            this.superTabControlPanel13.Name = "superTabControlPanel13";
            this.superTabControlPanel13.Size = new System.Drawing.Size(839, 706);
            this.superTabControlPanel13.TabIndex = 0;
            this.superTabControlPanel13.TabItem = this.exitTab;
            // 
            // exitTab
            // 
            this.exitTab.AttachedControl = this.superTabControlPanel13;
            this.exitTab.GlobalItem = false;
            this.exitTab.Image = global::ProposalReportingSystem.Properties.Resources.sign_out_option_1_;
            this.exitTab.ImageAlignment = DevComponents.DotNetBar.ImageAlignment.MiddleRight;
            this.exitTab.Name = "exitTab";
            this.exitTab.Text = "خروج";
            this.exitTab.Click += new System.EventHandler(this.exitTab_Click);
            // 
            // log
            // 
            this.log.AttachedControl = this.superTabControlPanel8;
            this.log.GlobalItem = false;
            this.log.Name = "log";
            this.log.Text = "superTabItem2";
            // 
            // superTabControlPanel8
            // 
            this.superTabControlPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel8.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel8.Name = "superTabControlPanel8";
            this.superTabControlPanel8.Size = new System.Drawing.Size(1183, 820);
            this.superTabControlPanel8.TabIndex = 0;
            this.superTabControlPanel8.TabItem = this.log;
            // 
            // wait_timer
            // 
            this.wait_timer.Interval = 5;
            // 
            // waitBw
            // 
            this.waitBw.WorkerReportsProgress = true;
            this.waitBw.WorkerSupportsCancellation = true;
            this.waitBw.DoWork += new System.ComponentModel.DoWorkEventHandler(this.wait_bgw_DoWork);
            this.waitBw.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.wait_bgw_RunWorkerCompleted);
            // 
            // iconMenuPanel
            // 
            this.iconMenuPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.iconMenuPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.iconMenuPanel.Controls.Add(this.menuSlideRb);
            this.iconMenuPanel.Controls.Add(this.menuDetailRb);
            this.iconMenuPanel.Controls.Add(this.menuIconRb);
            this.iconMenuPanel.Controls.Add(this.menuExitBtn);
            this.iconMenuPanel.Controls.Add(this.menuSysLogBtn);
            this.iconMenuPanel.Controls.Add(this.menuAboutUsBtn);
            this.iconMenuPanel.Controls.Add(this.menuPersonalSettingBtn);
            this.iconMenuPanel.Controls.Add(this.menuAppSettingBtn);
            this.iconMenuPanel.Controls.Add(this.menuManageUserBtn);
            this.iconMenuPanel.Controls.Add(this.menuManageTeacherBtn);
            this.iconMenuPanel.Controls.Add(this.menuManageProposalBtn);
            this.iconMenuPanel.Controls.Add(this.menuSearchProposalBtn);
            this.iconMenuPanel.Controls.Add(this.menuAddProposalBtn);
            this.iconMenuPanel.Controls.Add(this.menuHomeBtn);
            this.iconMenuPanel.Location = new System.Drawing.Point(1028, 0);
            this.iconMenuPanel.Margin = new System.Windows.Forms.Padding(2);
            this.iconMenuPanel.Name = "iconMenuPanel";
            this.iconMenuPanel.Size = new System.Drawing.Size(50, 629);
            this.iconMenuPanel.TabIndex = 1;
            this.iconMenuPanel.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuSlideRb
            // 
            this.menuSlideRb.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menuSlideRb.Font = new System.Drawing.Font("B Yekan+", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuSlideRb.Location = new System.Drawing.Point(2, 602);
            this.menuSlideRb.Margin = new System.Windows.Forms.Padding(2);
            this.menuSlideRb.Name = "menuSlideRb";
            this.menuSlideRb.Size = new System.Drawing.Size(44, 17);
            this.menuSlideRb.TabIndex = 33;
            this.menuSlideRb.Text = "اسلاید";
            this.menuSlideRb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.menuSlideRb.UseVisualStyleBackColor = true;
            // 
            // menuDetailRb
            // 
            this.menuDetailRb.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menuDetailRb.Checked = true;
            this.menuDetailRb.Font = new System.Drawing.Font("B Yekan+", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuDetailRb.Location = new System.Drawing.Point(-3, 578);
            this.menuDetailRb.Margin = new System.Windows.Forms.Padding(2);
            this.menuDetailRb.Name = "menuDetailRb";
            this.menuDetailRb.Size = new System.Drawing.Size(50, 17);
            this.menuDetailRb.TabIndex = 32;
            this.menuDetailRb.TabStop = true;
            this.menuDetailRb.Text = "جزئیات";
            this.menuDetailRb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.menuDetailRb.UseVisualStyleBackColor = true;
            this.menuDetailRb.CheckedChanged += new System.EventHandler(this.menuDetailRb_CheckedChanged);
            // 
            // menuIconRb
            // 
            this.menuIconRb.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.menuIconRb.Font = new System.Drawing.Font("B Yekan+", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuIconRb.Location = new System.Drawing.Point(1, 554);
            this.menuIconRb.Margin = new System.Windows.Forms.Padding(2);
            this.menuIconRb.Name = "menuIconRb";
            this.menuIconRb.Size = new System.Drawing.Size(46, 20);
            this.menuIconRb.TabIndex = 31;
            this.menuIconRb.Text = "آیکون";
            this.menuIconRb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.menuIconRb.UseVisualStyleBackColor = true;
            this.menuIconRb.Click += new System.EventHandler(this.menuIconRb_Click);
            // 
            // menuExitBtn
            // 
            this.menuExitBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuExitBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuExitBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuExitBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuExitBtn.Image = global::ProposalReportingSystem.Properties.Resources.sign_out_option_1_;
            this.menuExitBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuExitBtn.Location = new System.Drawing.Point(5, 506);
            this.menuExitBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuExitBtn.Name = "menuExitBtn";
            this.menuExitBtn.PulseSpeed = 5;
            this.menuExitBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuExitBtn.Size = new System.Drawing.Size(44, 45);
            this.menuExitBtn.TabIndex = 30;
            this.menuExitBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuExitBtn.Click += new System.EventHandler(this.menuExitBtn_Click);
            this.menuExitBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuSysLogBtn
            // 
            this.menuSysLogBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuSysLogBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuSysLogBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuSysLogBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuSysLogBtn.Image = global::ProposalReportingSystem.Properties.Resources.tasks;
            this.menuSysLogBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuSysLogBtn.Location = new System.Drawing.Point(5, 451);
            this.menuSysLogBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuSysLogBtn.Name = "menuSysLogBtn";
            this.menuSysLogBtn.PulseSpeed = 5;
            this.menuSysLogBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuSysLogBtn.Size = new System.Drawing.Size(44, 45);
            this.menuSysLogBtn.TabIndex = 29;
            this.menuSysLogBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuSysLogBtn.Click += new System.EventHandler(this.menuSysLogBtn_Click);
            this.menuSysLogBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuAboutUsBtn
            // 
            this.menuAboutUsBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuAboutUsBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuAboutUsBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuAboutUsBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuAboutUsBtn.Image = global::ProposalReportingSystem.Properties.Resources.about_us;
            this.menuAboutUsBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuAboutUsBtn.Location = new System.Drawing.Point(5, 401);
            this.menuAboutUsBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuAboutUsBtn.Name = "menuAboutUsBtn";
            this.menuAboutUsBtn.PulseSpeed = 5;
            this.menuAboutUsBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuAboutUsBtn.Size = new System.Drawing.Size(44, 45);
            this.menuAboutUsBtn.TabIndex = 28;
            this.menuAboutUsBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuAboutUsBtn.Click += new System.EventHandler(this.menuAboutUsBtn_Click);
            this.menuAboutUsBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuPersonalSettingBtn
            // 
            this.menuPersonalSettingBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuPersonalSettingBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuPersonalSettingBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuPersonalSettingBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuPersonalSettingBtn.Image = global::ProposalReportingSystem.Properties.Resources.user__1_;
            this.menuPersonalSettingBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuPersonalSettingBtn.Location = new System.Drawing.Point(5, 352);
            this.menuPersonalSettingBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuPersonalSettingBtn.Name = "menuPersonalSettingBtn";
            this.menuPersonalSettingBtn.PulseSpeed = 5;
            this.menuPersonalSettingBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuPersonalSettingBtn.Size = new System.Drawing.Size(44, 45);
            this.menuPersonalSettingBtn.TabIndex = 27;
            this.menuPersonalSettingBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuPersonalSettingBtn.Click += new System.EventHandler(this.menuPersonalSettingBtn_Click);
            this.menuPersonalSettingBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuAppSettingBtn
            // 
            this.menuAppSettingBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuAppSettingBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuAppSettingBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuAppSettingBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuAppSettingBtn.Image = global::ProposalReportingSystem.Properties.Resources.settings;
            this.menuAppSettingBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuAppSettingBtn.Location = new System.Drawing.Point(2, 302);
            this.menuAppSettingBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuAppSettingBtn.Name = "menuAppSettingBtn";
            this.menuAppSettingBtn.PulseSpeed = 5;
            this.menuAppSettingBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuAppSettingBtn.Size = new System.Drawing.Size(44, 45);
            this.menuAppSettingBtn.TabIndex = 26;
            this.menuAppSettingBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuAppSettingBtn.Click += new System.EventHandler(this.menuAppSettingBtn_Click);
            this.menuAppSettingBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuManageUserBtn
            // 
            this.menuManageUserBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuManageUserBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuManageUserBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuManageUserBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuManageUserBtn.Image = global::ProposalReportingSystem.Properties.Resources.user;
            this.menuManageUserBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuManageUserBtn.Location = new System.Drawing.Point(2, 253);
            this.menuManageUserBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuManageUserBtn.Name = "menuManageUserBtn";
            this.menuManageUserBtn.PulseSpeed = 5;
            this.menuManageUserBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuManageUserBtn.Size = new System.Drawing.Size(44, 45);
            this.menuManageUserBtn.TabIndex = 25;
            this.menuManageUserBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuManageUserBtn.Click += new System.EventHandler(this.menuManageUserBtn_Click);
            this.menuManageUserBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuManageTeacherBtn
            // 
            this.menuManageTeacherBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuManageTeacherBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuManageTeacherBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuManageTeacherBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuManageTeacherBtn.Image = global::ProposalReportingSystem.Properties.Resources.teachers;
            this.menuManageTeacherBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuManageTeacherBtn.Location = new System.Drawing.Point(4, 204);
            this.menuManageTeacherBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuManageTeacherBtn.Name = "menuManageTeacherBtn";
            this.menuManageTeacherBtn.PulseSpeed = 5;
            this.menuManageTeacherBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuManageTeacherBtn.Size = new System.Drawing.Size(44, 45);
            this.menuManageTeacherBtn.TabIndex = 24;
            this.menuManageTeacherBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuManageTeacherBtn.Click += new System.EventHandler(this.menuManageTeacherBtn_Click);
            this.menuManageTeacherBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuManageProposalBtn
            // 
            this.menuManageProposalBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuManageProposalBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuManageProposalBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuManageProposalBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuManageProposalBtn.Image = global::ProposalReportingSystem.Properties.Resources.file;
            this.menuManageProposalBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuManageProposalBtn.Location = new System.Drawing.Point(4, 154);
            this.menuManageProposalBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuManageProposalBtn.Name = "menuManageProposalBtn";
            this.menuManageProposalBtn.PulseSpeed = 5;
            this.menuManageProposalBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuManageProposalBtn.Size = new System.Drawing.Size(44, 45);
            this.menuManageProposalBtn.TabIndex = 23;
            this.menuManageProposalBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuManageProposalBtn.Click += new System.EventHandler(this.menuManageProposalBtn_Click);
            this.menuManageProposalBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuSearchProposalBtn
            // 
            this.menuSearchProposalBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuSearchProposalBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuSearchProposalBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuSearchProposalBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuSearchProposalBtn.Image = global::ProposalReportingSystem.Properties.Resources.search;
            this.menuSearchProposalBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuSearchProposalBtn.Location = new System.Drawing.Point(4, 102);
            this.menuSearchProposalBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuSearchProposalBtn.Name = "menuSearchProposalBtn";
            this.menuSearchProposalBtn.PulseSpeed = 5;
            this.menuSearchProposalBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuSearchProposalBtn.Size = new System.Drawing.Size(44, 45);
            this.menuSearchProposalBtn.TabIndex = 22;
            this.menuSearchProposalBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuSearchProposalBtn.Click += new System.EventHandler(this.menuSearchProposalBtn_Click);
            this.menuSearchProposalBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuAddProposalBtn
            // 
            this.menuAddProposalBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuAddProposalBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuAddProposalBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuAddProposalBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuAddProposalBtn.Image = global::ProposalReportingSystem.Properties.Resources.file__1_;
            this.menuAddProposalBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuAddProposalBtn.Location = new System.Drawing.Point(3, 52);
            this.menuAddProposalBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuAddProposalBtn.Name = "menuAddProposalBtn";
            this.menuAddProposalBtn.PulseSpeed = 5;
            this.menuAddProposalBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuAddProposalBtn.Size = new System.Drawing.Size(44, 45);
            this.menuAddProposalBtn.TabIndex = 21;
            this.menuAddProposalBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuAddProposalBtn.Click += new System.EventHandler(this.menuAddProposalBtn_Click);
            this.menuAddProposalBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // menuHomeBtn
            // 
            this.menuHomeBtn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.menuHomeBtn.BackColor = System.Drawing.Color.Transparent;
            this.menuHomeBtn.Checked = true;
            this.menuHomeBtn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.menuHomeBtn.Font = new System.Drawing.Font("B Koodak", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.menuHomeBtn.Image = global::ProposalReportingSystem.Properties.Resources.home;
            this.menuHomeBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.menuHomeBtn.Location = new System.Drawing.Point(2, 2);
            this.menuHomeBtn.Margin = new System.Windows.Forms.Padding(2);
            this.menuHomeBtn.Name = "menuHomeBtn";
            this.menuHomeBtn.PulseSpeed = 5;
            this.menuHomeBtn.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2, 20, 40, 2);
            this.menuHomeBtn.Size = new System.Drawing.Size(44, 45);
            this.menuHomeBtn.TabIndex = 20;
            this.menuHomeBtn.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.menuHomeBtn.Click += new System.EventHandler(this.menuHomeBtn_Click);
            this.menuHomeBtn.MouseEnter += new System.EventHandler(this.iconMenuPanel_MouseEnter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(232)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(1022, 596);
            this.Controls.Add(this.iconMenuPanel);
            this.Controls.Add(this.mainPage);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed_1);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.superTabControlPanel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mainPage)).EndInit();
            this.mainPage.ResumeLayout(false);
            this.superTabControlPanel11.ResumeLayout(false);
            this.logPanel.ResumeLayout(false);
            this.logNavigationPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logDgv)).EndInit();
            this.superTabControlPanel10.ResumeLayout(false);
            this.aboutUsPanel.ResumeLayout(false);
            this.aboutUsGp.ResumeLayout(false);
            this.superTabControlPanel7.ResumeLayout(false);
            this.personalSettingPanel.ResumeLayout(false);
            this.personalSettingThemeGp.ResumeLayout(false);
            this.appSettingBackgroundChangeGp.ResumeLayout(false);
            this.personalSettingPasswordGp.ResumeLayout(false);
            this.personalSettingPasswordGp.PerformLayout();
            this.superTabControlPanel6.ResumeLayout(false);
            this.appSettingPanel.ResumeLayout(false);
            this.appSettingShowGp.ResumeLayout(false);
            this.appSettingNavigationPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.appSettingShowDv)).EndInit();
            this.appSettingGp.ResumeLayout(false);
            this.appSettingGp.PerformLayout();
            this.superTabControlPanel4.ResumeLayout(false);
            this.manageUserPanel.ResumeLayout(false);
            this.manageUserManageGp.ResumeLayout(false);
            this.menageUserAccessLevelGp.ResumeLayout(false);
            this.manageUserPersonalInfoGp.ResumeLayout(false);
            this.manageUserPersonalInfoGp.PerformLayout();
            this.manageUserShowGp.ResumeLayout(false);
            this.manageUserNavigationPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.manageUserShowDgv)).EndInit();
            this.superTabControlPanel12.ResumeLayout(false);
            this.manageTeacherPanel.ResumeLayout(false);
            this.teacherManageShowGp.ResumeLayout(false);
            this.manageTeacherNavigationPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.manageTeacherShowDgv)).EndInit();
            this.manageTeacherInfoGp.ResumeLayout(false);
            this.manageTeacherInfoGp.PerformLayout();
            this.superTabControlPanel5.ResumeLayout(false);
            this.editProposalPanel.ResumeLayout(false);
            this.editProposalEditGp.ResumeLayout(false);
            this.editProposalEditGp.PerformLayout();
            this.editProposalShowGp.ResumeLayout(false);
            this.manageProposalNavigationPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.editProposalShowDgv)).EndInit();
            this.superTabControlPanel3.ResumeLayout(false);
            this.searchProposalPanel.ResumeLayout(false);
            this.searchProposalShowGp.ResumeLayout(false);
            this.searchProposalNavigationPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.searchProposalShowDgv)).EndInit();
            this.searchProposalSearchGp.ResumeLayout(false);
            this.searchProposalSearchGp.PerformLayout();
            this.superTabControlPanel2.ResumeLayout(false);
            this.addProposalPanel.ResumeLayout(false);
            this.addProposalShowGp.ResumeLayout(false);
            this.addProposalNavigationPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.addProposalShowDgv)).EndInit();
            this.addProposalAddGp.ResumeLayout(false);
            this.addProposalAddGp.PerformLayout();
            this.superTabControlPanel1.ResumeLayout(false);
            this.homePanel.ResumeLayout(false);
            this.homeTimeDateGp.ResumeLayout(false);
            this.homeAapInfoGp.ResumeLayout(false);
            this.iconMenuPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.appSettingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addProposalBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.editProposalBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchProposalBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private DevComponents.DotNetBar.SuperTabItem home_tab;
        private DevComponents.DotNetBar.SuperTabItem superTabItem9;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel9;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.SuperTabControl mainPage;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel3;
        private DevComponents.DotNetBar.SuperTabItem searchProposalTab;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel2;
        private DevComponents.DotNetBar.SuperTabItem addProposalTab;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel1;
        private DevComponents.DotNetBar.SuperTabItem homeTab;
        private DevComponents.DotNetBar.SuperTabItem logTab;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel7;
        private DevComponents.DotNetBar.SuperTabItem personalSettingsTab;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel6;
        private DevComponents.DotNetBar.SuperTabItem appSettingsTab;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel5;
        private DevComponents.DotNetBar.SuperTabItem manageProposalTab;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel4;
        private DevComponents.DotNetBar.SuperTabItem manageUserTab;
        private System.Windows.Forms.Panel manageUserPanel;
        private DevComponents.DotNetBar.Controls.GroupPanel manageUserManageGp;
        private DevComponents.DotNetBar.Controls.GroupPanel manageUserPersonalInfoGp;
        private System.Windows.Forms.Label manageUserTellLb;
        private System.Windows.Forms.Label manageUserEmailLb;
        private System.Windows.Forms.Label manageUserPasswordLb;
        private System.Windows.Forms.Label manageUserNcodLb;
        private System.Windows.Forms.Label manageUserLnameLb;
        private System.Windows.Forms.Label manageUserFnameLb;
        private System.Windows.Forms.TextBox manageUserTelTxtbx;
        private System.Windows.Forms.TextBox manageUserEmailTxtbx;
        private System.Windows.Forms.TextBox manageUserPasswordTxtbx;
        private System.Windows.Forms.TextBox manageUserNcodeTxtbx;
        private System.Windows.Forms.TextBox manageUserLnameTxtbx;
        private System.Windows.Forms.TextBox manageUserFnameTxtbx;
        private DevComponents.DotNetBar.Controls.GroupPanel menageUserAccessLevelGp;
        private System.Windows.Forms.CheckBox manageUserDeleteUserCb;
        private System.Windows.Forms.CheckBox manageUserEditUserCb;
        private System.Windows.Forms.CheckBox manageUserAddUserCb;
        private System.Windows.Forms.CheckBox manageUserDeleteProCb;
        private System.Windows.Forms.CheckBox manageUserEditProCb;
        private System.Windows.Forms.CheckBox manageUserAddProCb;
        private DevComponents.DotNetBar.Controls.GroupPanel manageUserShowGp;
        private DevComponents.DotNetBar.ButtonX manageUserEditBtn;
        private DevComponents.DotNetBar.ButtonX manageUserAddBtn;
        private System.Windows.Forms.Panel personalSettingPanel;
        private DevComponents.DotNetBar.Controls.GroupPanel personalSettingPasswordGp;
        private System.Windows.Forms.Label confirmNewPasswordLbl;
        private System.Windows.Forms.Label newPasswordLbl;
        private System.Windows.Forms.Label currentPasswordLbl;
        private System.Windows.Forms.TextBox personalSettingRepeatPasswordTxtbx;
        private System.Windows.Forms.TextBox personalSettingNewPasswordTxtbx;
        private System.Windows.Forms.TextBox personalSettingOldPasswordTxtbx;
        private DevComponents.DotNetBar.ButtonX personalSettingRegisterBtn;
        private DevComponents.DotNetBar.ButtonX personalSettingClearBtn;
        private System.Windows.Forms.Panel appSettingPanel;
        private System.Windows.Forms.Panel addProposalPanel;
        private DevComponents.DotNetBar.Controls.GroupPanel addProposalShowGp;
        private DevComponents.DotNetBar.Controls.GroupPanel addProposalAddGp;
        private System.Windows.Forms.ComboBox addProposalExecutorEDegCb;
        private System.Windows.Forms.TextBox addProposalExecutorMobileTxtbx;
        private System.Windows.Forms.Label addProposalExecutorMobileLbl;
        private System.Windows.Forms.Label addProposalExecutorEmailLbl;
        private System.Windows.Forms.Label addProposalExecutorEDegLbl;
        private System.Windows.Forms.TextBox addProposalExecutorEmailTxtbx;
        private System.Windows.Forms.Label addProposalExecutorEGroupLbl;
        private System.Windows.Forms.Label addProposalExecutorFacultyLbl;
        private System.Windows.Forms.Label addProposalExecutorTel2Lbl;
        private System.Windows.Forms.TextBox addProposalExecutorTel2Txtbx;
        private System.Windows.Forms.Label addProposalExecutorTel1Lbl;
        private System.Windows.Forms.TextBox addProposalExecutorTel1Txtbx;
        private System.Windows.Forms.Label addProposalExecutorLNameLbl;
        private System.Windows.Forms.TextBox addProposalExecutorLNameTxtbx;
        private System.Windows.Forms.Label addProposalExecutorFNameLbl;
        private System.Windows.Forms.TextBox addProposalExecutorFNameTxtbx;
        private DevComponents.DotNetBar.ButtonX addProposalRegisterBtn;
        private DevComponents.DotNetBar.ButtonX addProposalClearBtn;
        private System.Windows.Forms.TextBox addProposalValueTxtbx;
        private System.Windows.Forms.Label addProposalValueLbl;
        private System.Windows.Forms.Label addProposalOrganizationLbl;
        private System.Windows.Forms.Label addProposalStatusLbl;
        private System.Windows.Forms.Label addProposalTypeLbl;
        private System.Windows.Forms.Label addProposalRegisterTypeLbl;
        private System.Windows.Forms.Label addProposalPropertyTypeLbl;
        private System.Windows.Forms.Label addProposalProcedureTypeLbl;
        private System.Windows.Forms.TextBox addProposalDurationTxtbx;
        private System.Windows.Forms.Label addProposalDurationLbl;
        private System.Windows.Forms.Label addProposalStartdateLbl;
        private System.Windows.Forms.Label addProposalCoexecutorLbl;
        private System.Windows.Forms.TextBox addProposalCoexecutorTxtbx;
        private System.Windows.Forms.Label addProposalExecutor2Lbl;
        private System.Windows.Forms.Label addProposalExecutorNcodeLbl;
        private System.Windows.Forms.Label addProposalKeywordsLbl;
        private System.Windows.Forms.Label addProposalEnglishTitleLbl;
        private System.Windows.Forms.Label addProposalPersianTitleLbl;
        private System.Windows.Forms.TextBox addProposalExecutor2Txtbx;
        private System.Windows.Forms.TextBox addProposalExecutorNcodeTxtbx;
        private System.Windows.Forms.TextBox addProposalKeywordsTxtbx;
        private System.Windows.Forms.TextBox addProposalEnglishTitleTxtbx;
        private System.Windows.Forms.TextBox addProposalPersianTitleTxtbx;
        private System.Windows.Forms.ComboBox addProposalPropertyTypeCb;
        private System.Windows.Forms.ComboBox addProposalProcedureTypeCb;
        private System.Windows.Forms.ComboBox addProposalRegisterTypeCb;
        private System.Windows.Forms.ComboBox addProposalOrganizationNameCb;
        private System.Windows.Forms.ComboBox addProposalProposalTypeCb;
        private System.Windows.Forms.ComboBox addProposalStatusCb;
        private System.Windows.Forms.Panel editProposalPanel;
        private System.Windows.Forms.ComboBox addProposalOrganizationNumberCb;
        private System.Windows.Forms.LinkLabel addProposalFileLinkLbl;
        private System.Windows.Forms.Label addProposalFileLbl;
        private DevComponents.DotNetBar.Controls.GroupPanel searchProposalShowGp;
        private DevComponents.DotNetBar.Controls.GroupPanel searchProposalSearchGp;
        private System.Windows.Forms.ComboBox searchProposalOrganizationNumberCb;
        private System.Windows.Forms.ComboBox searchProposalStatusCb;
        private System.Windows.Forms.ComboBox searchProposalOrganizationNameCb;
        private System.Windows.Forms.ComboBox searchProposalTypeCb;
        private System.Windows.Forms.ComboBox searchProposalRegisterTypeCb;
        private System.Windows.Forms.ComboBox searchProposalPropertyTypeCb;
        private System.Windows.Forms.ComboBox searchProposalProcedureTypeCb;
        private System.Windows.Forms.TextBox searchProposalExecutorMobileTxtbx;
        private System.Windows.Forms.Label searchProposalExecutorMobileLbl;
        private System.Windows.Forms.Label searchProposalExecutorEGroupLbl;
        private System.Windows.Forms.Label searchProposalExecutorFacultyLbl;
        private System.Windows.Forms.Label searchProposalExecutorLNameLbl;
        private System.Windows.Forms.TextBox searchProposalExecutorLNameTxtbx;
        private System.Windows.Forms.Label searchProposalExecutorFNameLbl;
        private System.Windows.Forms.TextBox searchProposalExecutorFNameTxtbx;
        private DevComponents.DotNetBar.ButtonX searchProposalSearchBtn;
        private DevComponents.DotNetBar.ButtonX searchProposalClearBtn;
        private System.Windows.Forms.TextBox searchProposalValueFromTxtbx;
        private System.Windows.Forms.Label searchProposalValueFromLbl;
        private System.Windows.Forms.Label searchProposalOrganizationLbl;
        private System.Windows.Forms.Label searchProposalStatusLbl;
        private System.Windows.Forms.Label searchProposalTypeLbl;
        private System.Windows.Forms.Label searchProposalRegisterTypeLbl;
        private System.Windows.Forms.Label searchProposalPropertyTypeLbl;
        private System.Windows.Forms.Label searchProposalProcedureTypeLbl;
        private System.Windows.Forms.Label searchProposalStartDateFromLbl;
        private System.Windows.Forms.Label searchProposalExecutorNCodeLbl;
        private System.Windows.Forms.Label searchProposalEnglishTitleLbl;
        private System.Windows.Forms.Label searchProposalPersianTitleLbl;
        private System.Windows.Forms.TextBox searchProposalExecutorNCodeTxtbx;
        private System.Windows.Forms.TextBox searchProposalEnglishTitleTxtbx;
        private System.Windows.Forms.TextBox searchProposalPersianTitleTxtbx;
        private System.Windows.Forms.Panel searchProposalPanel;
        private DevComponents.DotNetBar.Controls.GroupPanel appSettingShowGp;
        private DevComponents.DotNetBar.Controls.GroupPanel appSettingGp;
        private System.Windows.Forms.Label appSettingStatusLbl;
        private System.Windows.Forms.Label aapSettingCoLbl;
        private System.Windows.Forms.Label appSettingProTypeLbl;
        private System.Windows.Forms.Label appSettingRegTypeLbl;
        private System.Windows.Forms.Label appSettingPropertyLbl;
        private System.Windows.Forms.Label appSettingProcedureTypeLbl;
        private System.Windows.Forms.TextBox appSettingStatusTxtbx;
        private System.Windows.Forms.TextBox appSettingPropertyTxtbx;
        private System.Windows.Forms.RadioButton appSettingStatusRbtn;
        private System.Windows.Forms.TextBox appSettingProTypeTxtbx;
        private System.Windows.Forms.RadioButton appSettingPropertyRbtn;
        private System.Windows.Forms.TextBox appSettingCoTxtbx;
        private System.Windows.Forms.RadioButton appSettingProTypeRbtn;
        private System.Windows.Forms.TextBox appSettingRegTypeTxtbx;
        private System.Windows.Forms.RadioButton appSettingCoRbtn;
        private System.Windows.Forms.RadioButton appSettingProcedureTypeRbtn;
        private System.Windows.Forms.RadioButton appSettingRegTypeRbtn;
        private System.Windows.Forms.TextBox appSettingProcedureTypeTxtbx;
        private DevComponents.DotNetBar.ButtonX appSettingDeleteBtn;
        private DevComponents.DotNetBar.ButtonX appSettingEditBtn;
        private DevComponents.DotNetBar.ButtonX appSettingAddBtn;
        private DevComponents.DotNetBar.Controls.GroupPanel editProposalShowGp;
        private DevComponents.DotNetBar.Controls.GroupPanel editProposalEditGp;
        private System.Windows.Forms.ComboBox editProposalOrganizationNumberCb;
        private System.Windows.Forms.ComboBox editProposalStatusCb;
        private System.Windows.Forms.ComboBox editProposalOrganizationNameCb;
        private System.Windows.Forms.ComboBox editProposalTypeCb;
        private System.Windows.Forms.ComboBox editProposalRegisterTypeCb;
        private System.Windows.Forms.ComboBox editProposalPropertyTypeCb;
        private System.Windows.Forms.ComboBox editProposalProcedureTypeCb;
        private System.Windows.Forms.ComboBox editProposalExecutorEDegCb;
        private System.Windows.Forms.TextBox editProposalExecutorMobileTxtbx;
        private System.Windows.Forms.Label editProposalExecutorMobileLbl;
        private System.Windows.Forms.Label editProposalExecutorEmailLbl;
        private System.Windows.Forms.Label editProposalExecutorEDegLbl;
        private System.Windows.Forms.TextBox editProposalExecutorEmailTxtbx;
        private System.Windows.Forms.Label editProposalExecutorEGroupLbl;
        private System.Windows.Forms.Label editProposalExecutorFacultyLbl;
        private System.Windows.Forms.Label editProposalExecutorTel2Lbl;
        private System.Windows.Forms.TextBox editProposalExecutorTel2Txtbx;
        private System.Windows.Forms.Label editProposalExecutorTel1Lbl;
        private System.Windows.Forms.TextBox editProposalExecutorTel1Txtbx;
        private System.Windows.Forms.Label editProposalExecutorLNameLbl;
        private System.Windows.Forms.TextBox editProposalExecutorLNameTxtbx;
        private System.Windows.Forms.Label editProposalExecutorFNameLbl;
        private System.Windows.Forms.TextBox editProposalExecutorFNameTxtbx;
        private DevComponents.DotNetBar.ButtonX editProposalRegisterBtn;
        private DevComponents.DotNetBar.ButtonX editProposalClearBtn;
        private System.Windows.Forms.TextBox editProposalValueTxtbx;
        private System.Windows.Forms.Label editProposalValueLbl;
        private System.Windows.Forms.Label editProposalOrganizationLbl;
        private System.Windows.Forms.Label editProposalStatusLbl;
        private System.Windows.Forms.Label editProposalTypeLbl;
        private System.Windows.Forms.Label editProposalRegisterTypeLbl;
        private System.Windows.Forms.Label editProposalPropertyTypeLbl;
        private System.Windows.Forms.Label editProposalProcedureTypeLbl;
        private System.Windows.Forms.TextBox editProposalDurationTxtbx;
        private System.Windows.Forms.Label editProposalDurationLbl;
        private System.Windows.Forms.Label editProposalStartdateLbl;
        private System.Windows.Forms.Label editProposalCoexecutorLbl;
        private System.Windows.Forms.TextBox editProposalCoexecutorTxtbx;
        private System.Windows.Forms.Label editProposalExecutor2Lbl;
        private System.Windows.Forms.Label editProposalExecutorNcodeLbl;
        private System.Windows.Forms.Label editProposalKeywordsLbl;
        private System.Windows.Forms.Label editProposalEnglishTitleLbl;
        private System.Windows.Forms.Label editProposalPersianTitleLbl;
        private System.Windows.Forms.TextBox editProposalExecutor2Txtbx;
        private System.Windows.Forms.TextBox editProposalExecutorNcodeTxtbx;
        private System.Windows.Forms.TextBox editProposalKeywordsTxtbx;
        private System.Windows.Forms.TextBox editProposalEnglishTitleTxtbx;
        private System.Windows.Forms.TextBox editProposalPersianTitleTxtbx;
        private System.Windows.Forms.Label searchProposalStartDateToLbl;
        private DevComponents.DotNetBar.Controls.GroupPanel homeTimeDateGp;
        private DevComponents.DotNetBar.Controls.AnalogClockControl analogClockControl1;
        private DevComponents.DotNetBar.Controls.GroupPanel homeAapInfoGp;
        private System.Windows.Forms.Label homeWelcomeLbl;
        private System.Windows.Forms.Label homeUserNameLbl;
        private System.Windows.Forms.Label homeUserProfileLbl;
        private System.Windows.Forms.Label homeAppNameLbl;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel10;
        private DevComponents.DotNetBar.Controls.GroupPanel aboutUsGp;
        private System.Windows.Forms.Label aboutUsAlirezaLbl;
        private System.Windows.Forms.Label aboutUsNimaLbl;
        private System.Windows.Forms.Label aboutUsHoseinLbl;
        private System.Windows.Forms.Label aboutUsPeymanLbl;
        private System.Windows.Forms.Label AboutUsArshinLbl;
        private System.Windows.Forms.Label aboutUsTitleLbl;
        private DevComponents.DotNetBar.SuperTabItem aboutUsTab;
        private System.Windows.Forms.LinkLabel editProposalFileLinkLbl;
        private System.Windows.Forms.Label editProposalFileLbl;
        private System.Windows.Forms.TextBox searchProposalValueToTxtbx;
        private System.Windows.Forms.Label searchProposalValueToLbl;
        private FarsiCalendarComponent.FarsiDatePicker addProposalStartdateTimeInput;
        private FarsiCalendarComponent.FarsiDatePicker editProposalStartdateTimeInput;
        private FarsiCalendarComponent.FarsiDatePicker searchProposalStartDateFromTimeInput;
        private System.Windows.Forms.CheckBox searchProposalStartDateToChbx;
        private System.Windows.Forms.CheckBox searchProposalStartDateFromChbx;
        private DevComponents.DotNetBar.ButtonX manageUserClearBtn;
        private FarsiCalendarComponent.FarsiCalendarControl monthCalendar1;
        private System.Windows.Forms.Panel homePanel;
        private System.Windows.Forms.Panel aboutUsPanel;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel11;
        private System.Windows.Forms.Panel logPanel;
        private DevComponents.DotNetBar.SuperTabItem sysLogTab;
        private DevComponents.DotNetBar.SuperTabItem log;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel8;
        private System.Windows.Forms.ComboBox addProposalExecutorEGroupCb;
        private System.Windows.Forms.ComboBox addProposalExecutorFacultyCb;
        private System.Windows.Forms.ComboBox editProposalExecutorEGroupCb;
        private System.Windows.Forms.ComboBox editProposalExecutorFacultyCb;
        private System.Windows.Forms.ComboBox searchProposalExecutorEGroupCb;
        private System.Windows.Forms.ComboBox searchProposalExecutorFacultyCb;
        private DevComponents.DotNetBar.Controls.GroupPanel searchProposalExecutorInfoGp;
        private FarsiCalendarComponent.FarsiDatePicker searchProposalStartDateToTimeInput;
        private DevComponents.DotNetBar.Controls.GroupPanel searchProposalProposalInfoGp;
        private System.Windows.Forms.Label appSettingEgroupLbl;
        private System.Windows.Forms.Label appSettingFacultyLbl;
        private System.Windows.Forms.TextBox appSettingFacultyTxtbx;
        private System.Windows.Forms.TextBox appSettingEgroupTxtbx;
        private System.Windows.Forms.RadioButton appSettingFacultyRbtn;
        private System.Windows.Forms.RadioButton appSettingEgroupRbtn;
        private DevComponents.DotNetBar.ButtonX appSettingBackBtn;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel12;
        private DevComponents.DotNetBar.SuperTabItem manageTeacherTab;
        private System.Windows.Forms.Panel manageTeacherPanel;
        private DevComponents.DotNetBar.Controls.GroupPanel teacherManageShowGp;
        private DevComponents.DotNetBar.Controls.GroupPanel manageTeacherInfoGp;
        private System.Windows.Forms.TextBox manageTeacherLnameTxtbx;
        private System.Windows.Forms.TextBox manageTeacherExecutorNcodeTxtbx;
        private DevComponents.DotNetBar.ButtonX manageTeacherDeleteBtn;
        private System.Windows.Forms.Label manageTeacherExecutorNcodeLbl;
        private DevComponents.DotNetBar.ButtonX manageTeacherEditBtn;
        private System.Windows.Forms.TextBox manageTeacherFnameTxtbx;
        private DevComponents.DotNetBar.ButtonX manageTeacherAddBtn;
        private System.Windows.Forms.Label manageTeacherLnameLbl;
        private System.Windows.Forms.ComboBox manageTeacherExecutorEDegCb;
        private System.Windows.Forms.TextBox manageTeacherExecutorMobileTxtbx;
        private System.Windows.Forms.Label manageTeacherExecutorMobileLbl;
        private System.Windows.Forms.Label manageTeacherExecutorEmailLbl;
        private System.Windows.Forms.Label manageTeacherExecutorEDegLbl;
        private System.Windows.Forms.TextBox manageTeacherExecutorEmailTxtbx;
        private System.Windows.Forms.Label manageTeacherExecutorEGroupLbl;
        private System.Windows.Forms.Label manageTeacherExecutorFacultyLbl;
        private System.Windows.Forms.Label manageTeacherExecutorTelLbl;
        private System.Windows.Forms.TextBox manageTeacherExecutorTelTxtbx;
        private System.Windows.Forms.Label manageTeacherFnameLbl;
        private System.Windows.Forms.ComboBox manageTeacherExecutorFacultyCb;
        private DevComponents.DotNetBar.ButtonX manageUserDeleteBtn;
        private DevComponents.DotNetBar.ButtonX editProposalDeleteBtn;
        private System.Windows.Forms.BindingSource appSettingBindingSource;
        private DevComponents.DotNetBar.ButtonX manageTeacherClearBtn;
        private DevComponents.DotNetBar.Controls.GroupPanel personalSettingThemeGp;
        private System.Windows.Forms.Label appSettingBackgroundChangeLbl;
        private System.Windows.Forms.Label appSettingBackgroundColorLbl;
        private DevComponents.DotNetBar.Controls.GroupPanel appSettingBackgroundChangeGp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource logBindingSource;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private System.Windows.Forms.ComboBox manageTeacherExecutorEgroupCb;
        private System.Windows.Forms.TextBox manageTeacherExecutorTel2Txtbx;
        private System.Windows.Forms.Label manageTeacherExecutorTel2Lbl;
        private System.Windows.Forms.BindingSource teacherBindingSource;
        private DevComponents.DotNetBar.ButtonX manageUserShowAllBtn;
        private DevComponents.DotNetBar.ButtonX editProposalSearchBtn;
        private System.Windows.Forms.Timer wait_timer;
        private System.ComponentModel.BackgroundWorker waitBw;
        private DevComponents.DotNetBar.ButtonX addProposalShowAllBtn;
        private System.Windows.Forms.BindingSource addProposalBindingSource;
        private DevComponents.DotNetBar.ButtonX addProposalSearchBtn;
        private DevComponents.DotNetBar.ButtonX manageTeacherShowAllBtn;
        private System.Windows.Forms.BindingSource editProposalBindingSource;
        private System.Windows.Forms.CheckBox manageUserManageTypeCb;
        private System.Windows.Forms.CheckBox manageUserManageTeacherCb;
        private DevComponents.DotNetBar.ButtonX searchProposalShowAllBtn;
        private System.Windows.Forms.BindingSource searchProposalBindingSource;
        private DevComponents.DotNetBar.ButtonX editProposalShowAllBtn;
        private System.Windows.Forms.CheckBox personalSettingOldPasswordChb;
        private System.Windows.Forms.CheckBox personalSettingNewPasswordChb;
        private System.Windows.Forms.CheckBox personalSettingRepeatPasswordChb;
        private System.Windows.Forms.CheckBox manageUserShowPasswordChb;
        private System.Windows.Forms.Label homeEBSLbl;
        private DevComponents.DotNetBar.ButtonX manageTeacherSearchBtn;
        private System.Windows.Forms.Label appSettingEdegreeLbl;
        private System.Windows.Forms.TextBox appSettingEdegreeTxtbx;
        private System.Windows.Forms.RadioButton appSettingEdegreeRbtn;
        private System.Windows.Forms.DataGridView addProposalShowDgv;
        private System.Windows.Forms.DataGridView logDgv;
        private System.Windows.Forms.DataGridView manageTeacherShowDgv;
        private System.Windows.Forms.DataGridView appSettingShowDv;
        private System.Windows.Forms.DataGridView searchProposalShowDgv;
        private System.Windows.Forms.DataGridView manageUserShowDgv;
        private System.Windows.Forms.DataGridView editProposalShowDgv;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel13;
        private DevComponents.DotNetBar.SuperTabItem exitTab;
        private System.Windows.Forms.Panel iconMenuPanel;
        private DevComponents.DotNetBar.ButtonX menuHomeBtn;
        private DevComponents.DotNetBar.ButtonX menuExitBtn;
        private DevComponents.DotNetBar.ButtonX menuSysLogBtn;
        private DevComponents.DotNetBar.ButtonX menuAboutUsBtn;
        private DevComponents.DotNetBar.ButtonX menuPersonalSettingBtn;
        private DevComponents.DotNetBar.ButtonX menuAppSettingBtn;
        private DevComponents.DotNetBar.ButtonX menuManageUserBtn;
        private DevComponents.DotNetBar.ButtonX menuManageTeacherBtn;
        private DevComponents.DotNetBar.ButtonX menuManageProposalBtn;
        private DevComponents.DotNetBar.ButtonX menuSearchProposalBtn;
        private DevComponents.DotNetBar.ButtonX menuAddProposalBtn;
        private System.Windows.Forms.RadioButton menuSlideRb;
        private System.Windows.Forms.RadioButton menuDetailRb;
        private System.Windows.Forms.RadioButton menuIconRb;
        private System.Windows.Forms.Panel manageProposalNavigationPanel;
        private DevComponents.DotNetBar.Controls.TextBoxX manageProposalNavigationCurrentPageTxtbx;
        private DevComponents.DotNetBar.ButtonX manageProposalNavigationNextPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem6;
        private DevComponents.DotNetBar.ButtonX manageProposalNavigationLastPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem5;
        private DevComponents.DotNetBar.ButtonX buttonX4;
        private DevComponents.DotNetBar.SuperTabItem superTabItem4;
        private DevComponents.DotNetBar.ButtonX manageProposalNavigationPreviousPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem3;
        private DevComponents.DotNetBar.ButtonX manageProposalNavigationFirstPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem2;
        private DevComponents.DotNetBar.ButtonX manageProposalNavigationReturnBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem1;
        private System.Windows.Forms.Panel addProposalNavigationPanel;
        private DevComponents.DotNetBar.Controls.TextBoxX addProposalNavigationCurrentPageTxtbx;
        private DevComponents.DotNetBar.ButtonX addProposalNavigationNextPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem7;
        private DevComponents.DotNetBar.ButtonX addProposalNavigationLastPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem8;
        private DevComponents.DotNetBar.ButtonX addProposalNavigationPreviousPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem11;
        private DevComponents.DotNetBar.ButtonX addProposalNavigationFirstPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem12;
        private DevComponents.DotNetBar.ButtonX addProposalNavigationReturnBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem13;
        private System.Windows.Forms.Panel searchProposalNavigationPanel;
        private DevComponents.DotNetBar.Controls.TextBoxX searchProposalNavigationCurrentPageTxtbx;
        private DevComponents.DotNetBar.ButtonX searchProposalNavigationNextPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem14;
        private DevComponents.DotNetBar.ButtonX searchProposalNavigationLastPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem15;
        private DevComponents.DotNetBar.ButtonX searchProposalNavigationPreviousPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem17;
        private DevComponents.DotNetBar.ButtonX searchProposalNavigationFirstPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem18;
        private DevComponents.DotNetBar.ButtonX searchProposalNavigationReturnBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem19;
        private System.Windows.Forms.Panel manageTeacherNavigationPanel;
        private DevComponents.DotNetBar.Controls.TextBoxX manageTeacherNavigationCurrentPageTxtbx;
        private DevComponents.DotNetBar.ButtonX manageTeacherNavigationNextPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem20;
        private DevComponents.DotNetBar.ButtonX manageTeacherNavigationLastPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem21;
        private DevComponents.DotNetBar.ButtonX manageTeacherNavigationPreviousPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem23;
        private DevComponents.DotNetBar.ButtonX manageTeacherNavigationFirstPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem24;
        private DevComponents.DotNetBar.ButtonX manageTeacherNavigationReturnBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem25;
        private System.Windows.Forms.Panel appSettingNavigationPanel;
        private DevComponents.DotNetBar.Controls.TextBoxX appSettingNavigationCurrentPageTxtbx;
        private DevComponents.DotNetBar.ButtonX appSettingNavigationNextPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem32;
        private DevComponents.DotNetBar.ButtonX appSettingNavigationLastPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem33;
        private DevComponents.DotNetBar.ButtonX appSettingNavigationPreviousPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem35;
        private DevComponents.DotNetBar.ButtonX appSettingNavigationFirstPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem36;
        private DevComponents.DotNetBar.ButtonX appSettingNavigationReturnBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem37;
        private System.Windows.Forms.Panel manageUserNavigationPanel;
        private DevComponents.DotNetBar.Controls.TextBoxX manageUserNavigationCurrentPageTxtbx;
        private DevComponents.DotNetBar.ButtonX manageUserNavigationNextPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem26;
        private DevComponents.DotNetBar.ButtonX manageUserNavigationLastPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem27;
        private DevComponents.DotNetBar.ButtonX manageUserNavigationPreviousPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem29;
        private DevComponents.DotNetBar.ButtonX manageUserNavigationFirstPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem30;
        private DevComponents.DotNetBar.ButtonX manageUserNavigationReturnBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem31;
        private System.Windows.Forms.Panel logNavigationPanel;
        private DevComponents.DotNetBar.Controls.TextBoxX logNavigationCurrentPageTxtbx;
        private DevComponents.DotNetBar.ButtonX logNavigationNextPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem10;
        private DevComponents.DotNetBar.ButtonX logNavigationLastPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem16;
        private DevComponents.DotNetBar.ButtonX logNavigationPreviousPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem22;
        private DevComponents.DotNetBar.ButtonX logNavigationFirstPageBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem28;
        private DevComponents.DotNetBar.ButtonX logNavigationReturnBtn;
        private DevComponents.DotNetBar.SuperTabItem superTabItem34;
        private DevComponents.DotNetBar.BalloonTip balloonTip1;
    }
}

