﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProposalReportingSystem
{
    class Log
    {
        public long logNumber { get; set; }
        public long logUsername { get; set; }
        public string logDateTime { get; set; }
        public string logDescription { get; set; }
        public string logTableName { get; set; }
    }
}
