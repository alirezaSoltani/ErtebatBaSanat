﻿using System;

public class Global
{
    private String ConnectionString;
	public Global()
	{
	}
    public String getConnectionString() {
        return ConnectionString;
    }
}
